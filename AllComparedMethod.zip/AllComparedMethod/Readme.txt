Before using these codes, you need to add these folders to the path, especially the folder named "MyAdditionalfunction".

This floder contains Many useful MATLAB codes and all these codes are free for use.

When you use these codes, please pay attention to the copyright issue and mark the references if necessary.

