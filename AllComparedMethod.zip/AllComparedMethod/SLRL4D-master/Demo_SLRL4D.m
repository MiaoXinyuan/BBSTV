clc; clear;
addpath('SLRL4D');
addpath('BM4D_mex');
addpath('Dataset');
addpath('Quantitative Assessment');

%%

X = ENVIImgRead('HyperData');
Y = ENVIImgRead('NoiseyHyperData');


% Parameter Setting
% k_num=4;
% lambda=1;
% iterations = 100;
%
k_num=4;
lambda= 0.4;
iterations = 100;
tic
[Ys,~,~,mpsnr_i,mssim_i] =SLRL4D_fast(X,'LAMBDA_S',lambda,'SUBSPACE_DIM',k_num,'AL_ITERS',iterations,'TRUE_X',X);
toc

% [mpsnr,psnr] = MPSNR(X,Ys);
% [mssim,ssim] = MSSIM(X,Ys);
% [mfsim,fsim] = MFSIM(X,Ys);
% ergas = ErrRelGlobAdimSyn(X,Ys);
% msa = MSA(X, Ys);
% disp(['PSNR=' num2str(mpsnr)]);
% disp(['SSIM=' num2str(mssim)]);
% disp(['FSIM=' num2str(mfsim)]);
% disp(['ERGAS=' num2str(ergas)]);
% disp(['MSA=' num2str(msa)]);
%%
ENVIImgWrite(Ys,'RecoveryHyperDataSLRL4D')
