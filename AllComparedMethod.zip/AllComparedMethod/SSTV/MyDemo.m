
%% Load Image
clc; clear all;
%%
% [RecoveryHyperData] = ENVIImgRead('I:\��������&ר��\��������&ר��\Letter\MyAl\newCode\RecoveryNoiseData\RecoveryHyperData');
[HyperData] = ENVIImgRead('HyperData');
[NoiseyHyperData] = ENVIImgRead('NoiseyHyperData');

%% Normalize
% sizHS = size(NoiseyHyperData);
% shData = reshape(NoiseyHyperData,sizHS(1)*sizHS(2),sizHS(3));
% shData = shData';
% NorShData = mapminmax(shData,0,1);
% NorShData = NorShData';
% NoiseyHyperData = reshape(NorShData,sizHS(1),sizHS(2),sizHS(3));

%% Set parameters and call algorithm
  %parameter values can be adjusted according to image
  
 lambda=.1; mu=.2; nu=.2; iter=100; %wdc good psnr with funSSTV
%  lambda=.2; mu=.8; nu=.8; iter=100; %wdc good psnr with funSSTV

tic;
%%
RecoveryHyperDataSSTV = funSSTV(NoiseyHyperData,iter,lambda,mu,nu);
%%
toc;
ENVIImgWrite(RecoveryHyperDataSSTV,'RecoveryHyperDataSSTV')
%% calculate PSNR 

% [denoisedPSNR,~]=myPSNR(img,denoised,1);
% [noisyPSNR,~]=myPSNR(img,noisy,1);
% 
% fprintf('\n Noisy image have PSNR= %1.2f dB \n',noisyPSNR);
% fprintf('\n reconstructed image psnr= %f \n',denoisedPSNR);

%% Display images
% bands=10;
% h1=subplot(131);imshow(img(:,:,bands)); title('Original Image')
% h2=subplot(132);imshow(noisy(:,:,bands));  title('Noisy Image');
% h3=subplot(133);imshow(denoised(:,:,bands)); title('Denoised Image');
% set(h1,'position',[0.02 .11 .3134 .815]);
% set(h2,'position',[.35 .11 .3134 .815]);
% set(h3,'position',[.67 .11 .3134 .815]);


%% function for psnr value

function [cpsnr,psnr]=myPSNR(org,recon,skip)

org=org(skip+1:end-skip,skip+1:end-skip,:);
recon=recon(skip+1:end-skip,skip+1:end-skip,:);
  [m, n,~]=size(org);

if strcmp(class(org),class(recon))
    sse=squeeze(sum(sum((org-recon).^2))); %square sum of error  
    mse=sse./(m*n);  %mean square error of each band.
    maxval=squeeze(max(max(org)));
    psnr= 10*log10( (maxval.^2) ./mse);
    cpsnr=mean(psnr);
end
end
%%  function to add Gaussian noise of given snr

function [noisy,sigma]=addGaussianNoise(img,snr)
%This function will add Gaussian noise of given SNR.
%img is image in size 

noisy=zeros(size(img));
for i=1:size(img,3)
    band=img(:,:,i);
    varNoise= norm(band(:))^2/(length(band(:)) * (10^ (snr/10)));
    noisy(:,:,i)=band+sqrt(varNoise)*randn(size(band));
end
    sigma=sqrt(varNoise);

end
