Thank you for downloading our code for hyperspectral denoising.
--------------------------------------------------------
What this code do :

This code demonstrates Hyperspectral denoising algorithm to remove mixed noise. 

This code implements algorithm published in following papger:
Title   : Hyperspectral Image Denoising using Spatio-Spectral Total Variation 
Authors : Hemant Kumar Aggarwal, Angshul Majumdar
Journal : IEEE Geoscience and Remote Sensing Letters (LGRS), 2016

Noise can include: line strips, Gaussian noise and impulse noise.
It solves following optimization problem :

 min_{X,S}  || Y-X-S||_F  + lmabda || S||_1 + mu ||Dh*X*D||_1 + mu ||Dv*X*D||_1  

 X     : Hyperspectral image in matrix form (pixels x bands)
 S     : Sparse noise. It can be  mixture of impulse noise and line strips.
 Y     : Noisy Image.
 D     : One dimensional finite differencing operator. 
Dh, Dv : Two dimensional horizontal and vertical finite difference operators.

----------------------------------------------------------------------------------- 
How to Run this code :

Just run the "demo.m" file by keeping all three files (demo.m, funSSTV.m, WDCimage.mat)  in one folder. 
It will show original image, noisy image and denoised image in the output. 
It also gives resulting image PSNR value.

--------------------------------
File Description :

demo.m    : Simply run this file to see how the code works. It is demo file for funSSTV.
funSSTV.m : It is the main function which solves above problem using split-Bregman technique.
WDCimage.mat  : This is the portion of Washington DC mall image available for free download  from here:
                          link: https://engineering.purdue.edu/%7ebiehl/MultiSpec/hyperspectral.html 
--------------------------------------------------------------------
Contact Information:

This code is released just to promote reproducible research and is not very robust.
If you face difficulty in running this code then please feel free to contact us. 

Contact Name : Hemant Kumar Aggarwal
Email :  jnu.hemant@gmail.com   


