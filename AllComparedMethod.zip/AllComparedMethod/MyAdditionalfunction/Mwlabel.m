function [CCL, RegionProp]  = Mwlabel(Seg, varargin)
% [CCL, RegionProp]  = Mwlabel(Seg, varargin)
% multi-value connected component labeling
% the segmented image
% varargin: assign whether compute the region properties 
% CCL: connected component labeling image��each region corresponds to a value within 1~R, R is the region numbers
% RegionProp�� corresponds to the property of each region

[Row,Col,Band] = size(Seg);
Seg = reshape(Seg,Row*Col,Band);
[Segment,~,~] = unique(Seg,'rows');
CCL = zeros(Row,Col);
Count = 0;
Hbar = waitbar(0,'Labeling Regions');
if nargin < 2
    for j = 1:length(Segment)
        zz = zeros(Row*Col,1);
        zz(all(bsxfun(@eq,Seg,Segment(j,:)),2)) = 1;
        L = bwlabel(reshape(zz,Row,Col),8);
        cc = max(L(:));
        L = (L~=0).*(L+Count)+(L==0).*0;       
        Count = Count+cc;       
        CCL = CCL + L;
        waitbar( j/length(Segment) ); 
    end
else
    if length( varargin ) == 1
        for j = 1:length(Segment)
            zz = zeros(Row*Col,1);
            zz(all(bsxfun(@eq,Seg,Segment(j,:)),2)) = 1;
            L = bwlabel(reshape(zz,Row,Col),8);
            Regprop = regionprops(L,varargin{1});
            cc = max(L(:));
            L = (L~=0).*(L+Count)+(L==0).*0;
            Count = Count+cc;
            for k  = 1:length(Regprop)
                RegionProp( Count - cc + k ) = Regprop(k);
            end
            CCL = CCL + L;
            waitbar( j/length(Segment) ); 
        end
    else
        for j = 1:length(Segment)
            zz = zeros(Row*Col,1);
            zz(all(bsxfun(@eq,Seg,Segment(j,:)),2)) = 1;
            L = bwlabel(reshape(zz,Row,Col),8);
            Regprop = regionprops(L,varargin);
            cc = max(L(:));
            L = (L~=0).*(L+Count)+(L==0).*0;
            Count = Count+cc;
            for k  = 1:length(Regprop)
                RegionProp( Count - cc + k ) = Regprop(k);
            end
            CCL = CCL + L;
            waitbar( j/length(Segment) ); 
        end
    end
end
close(Hbar);




