function [Type, Name] = NodeType(Node)
% Type = NodeType(Node)
% return the type of this node: root, file or band?
% if type == file, Name = char(getName(Node));
% if type == band, Name = band number;
Node = Node(1);
Path = Node.getPath;
switch length(Path)
    case 1
        Type = 'root';
        Name = char(getName(Node));
    case 2
        Type = 'file';
        Name = char(getName(Node));
    case 3
        Type = 'band';
        Name = FindTreeId( Node.getParent, Node);
    otherwise
        Type = [];
        Name = [];
end

        