function Id = FindTreeId( ParentNode, Node)
% Id = FindTreeId( ParentNode, Node)
% Find the index of NodeValue in the parent node;
% ParentNode can be otained by node.getParent
Id = zeros(1,length(Node));
for k = 1:length(Node)
    Name = getName(Node(k));
    for j = 1:ParentNode.getChildCount
        names = getName(ParentNode.getChildAt(j-1));
        if isequal(Name,names)
            Id(k) = j;break;
        end
    end
end