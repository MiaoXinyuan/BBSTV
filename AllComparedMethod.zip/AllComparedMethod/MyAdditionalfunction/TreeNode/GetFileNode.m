function [FileNode, FileName] = GetFileNode(InNode)
InNode = InNode(1);

TreePath = InNode.getPath;
if length(TreePath) >= 3
    FileNode = TreePath(2);
else
    FileNode = InNode;    
end
FileName =  char(getName(FileNode));




