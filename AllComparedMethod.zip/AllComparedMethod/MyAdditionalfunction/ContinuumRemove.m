function [Baoluo,R] = ContinuumRemove(Sampr)
% [Baoluo,R] = ContinuumRemove(Sampr)
% Continuum removing for the spectrum of a sample
%   Sampr--Samples of spectral line; 
%   Return: 
%       Baoluo: Continuum
%       R:      normalized spectrum

Sampr = double(Sampr(:));
k = length(Sampr);
Baoluo = zeros(k,1);
[W,R,num] = Baoluoxian(Sampr,k);
Wnodes = W(1:num);  % number of node 
Baoluo(Wnodes) = R(1:num); 

for j = 1:num-1
    x1 = Wnodes(j);
    x2 = Wnodes(j+1);
    diff = (Sampr(x2)-Sampr(x1))/(x2-x1);
    if diff ~=0
        Baoluo(x1:x2) = Sampr(x1):diff:Sampr(x2);
    else
        Baoluo(x1:x2) = Sampr(x1);
    end
end

R = Sampr(1:k)./Baoluo(1:k);

function [W,R,num]=Baoluoxian(Sampr,k)
%Draw the continuum of given spectral line,
%[W,R]=Baoluoxian(Sampw,Sampr,k);
%Sampw,Sampr--Samples of spectral line;k--number of bands;R,W--nodes;
%num--number of nodes;
num = 1;
i = 1; 
R = Sampr;
W = 1:k;
while i~=k 
    j=i+1;
    while j~=k
        m=j+1;
        while m~=k
            if (Sampr(j)-Sampr(i))/(j-i)*(m-i)+Sampr(i) >= Sampr(m)
                m=m+1;
            else
                j=j+1;
                break;
            end
        end
        if m==k
            break;
        end
    end
    if j==k
        num=num+1;
        W(num)=j;
        R(num)=Sampr(j);
        break;
    end
    num=num+1;
    W(num)=j;
    R(num)=Sampr(j);
    i=j;       
end
R=R(1:num);
W=W(1:num);