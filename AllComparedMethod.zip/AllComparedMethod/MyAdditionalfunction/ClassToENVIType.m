function [ ENVItype, Bytes ] = ClassToENVIType(Class , IsReal)
% [ ENVItype, Bytes ] = ClassToENVIType(Class , IsReal)
% convert matlab class type into code of ENVI type.
% Bytes: return the number of bytes occupied by the type
% IsReal: 'Real'��'Complex'��default is 'Real'
if nargin < 2
    IsReal = 'real';
end
IsReal = lower(IsReal);
switch Class
    case 'uint8'
        Bytes = 1;
        ENVItype = '1';
    case 'int16'
        Bytes = 2;
        ENVItype = '2';
    case 'uint16'
        Bytes = 2;
        ENVItype = '12';
    case 'int32'
        Bytes = 4;
        ENVItype = '3';
    case 'uint32'
        Bytes = 4;
        ENVItype = '13';
    case 'single'
        if strcmp(IsReal,'real')
            Bytes = 4;
            ENVItype = '4';
        elseif strcmp(IsReal,'complex')
            Bytes = 8;
            ENVItype = '6';
        else
            error('IsReal must be "Real", or "Complex".');
        end
    case 'double'
        if strcmp(IsReal,'real')
            Bytes = 8;
            ENVItype = '5';
        elseif strcmp(IsReal,'complex')
            Bytes = 16;
            ENVItype = '9';
        else
            error('IsReal must be "Real", or "Complex".');
        end
    case 'int64'
        Bytes = 8;
        ENVItype = '14';
    case 'uint64'
        Bytes = 8;
        ENVItype = '15';
end