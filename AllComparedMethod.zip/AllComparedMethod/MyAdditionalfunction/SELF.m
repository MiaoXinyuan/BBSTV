function TSELF = SELF(P,Y,beta,metric,options)
%
% SELF: Semi-Supervised Local Fisher Discriminant Analysis
%       for Dimensionality Reduction
%
% Usage:
%       [T,Z]=SELF(P,Y,beta,metric,options)
%
% Input:
%    P:      d x n matrix of original samples
%            d --- dimensionality of original samples
%            n --- the number of samples 
%    Y:      n dimensional vertical vector of class labels
%            (each element takes an integer between 0 and c,
%            where c is the number of classes)
%            0:             unlabeled 
%            {1,2, ... ,c}: labeled
%    beta:   degree of semi-supervisedness (0 <= beta <= 1; default is 0.5 )
%            0: totally supervised (discard all unlabeled samples)
%            1: totally unsupervised (discard all label information)

%    metric: type of metric in the embedding space (default is 'weighted')
%            'weighted'        --- weighted eigenvectors 
%            'orthonormalized' --- orthonormalized
%            'plain'           --- raw eigenvectors

%
% Output:
%    T: d x r transformation matrix (Z=T'*P)
%    Z: r x n matrix of dimensionality reduced samples 
%
% (c) Masashi Sugiyama, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     sugi@cs.titech.ac.jp,     http://sugiyama-www.cs.titech.ac.jp/~sugi/software/SELF/
P=P';
if nargin<2
  error('Not enough input arguments.')
end
[d n]=size(P);

if nargin<3
  beta=0.5;
end


r=options.ReducedDim; ;


if nargin<4
  metric='weighted';
end


kNN=options.lk;


flag_label=(Y~=0);
nlabel=sum(flag_label);

X2=sum(P.^2,1);
dist2=repmat(X2(flag_label),n,1)+repmat(X2',1,nlabel)-2*P'*P(:,flag_label);
[sorted,index]=sort(dist2,1);
kNNdist2=max(sorted(kNN+1,:),0);
localscale=sqrt(kNNdist2);
LocalScale=localscale'*localscale;
flag=(LocalScale>0);
A=zeros(nlabel,nlabel);
dist2tmp=dist2(flag_label,:);
A(flag)=exp(-dist2tmp(flag)./LocalScale(flag));

Wlb=zeros(nlabel,nlabel);
Wlw=zeros(nlabel,nlabel);
Ylabel=Y(flag_label);
for class=1:max(Y)
  flag_class=(Ylabel==class);
  nclass=sum(flag_class);
  if nclass~=0
    tmp =flag_class*1;
    tmp2=(~flag_class)*1;
    Wlb=Wlb+A*(1/nlabel-1/nclass).*(tmp'*tmp)+(tmp'*tmp2)/nlabel;
    Wlw=Wlw+(A/nclass).*(tmp'*tmp);
  end
end

Slb=P(:,flag_label)*(diag(sum(Wlb,1))-Wlb)*P(:,flag_label)';
Slw=P(:,flag_label)*(diag(sum(Wlw,1))-Wlw)*P(:,flag_label)';

Srlb=(1-beta)*Slb+beta*cov(P',1);
Srlw=(1-beta)*Slw+beta*eye(d);

Srlb=(Srlb+Srlb')/2;
Srlw=(Srlw+Srlw')/2;

if r==d
  [eigvec,eigval_matrix]=eig(Srlb,Srlw);
else
  opts.disp = 0; 
  [eigvec,eigval_matrix]=eigs(Srlb,Srlw,r,'la',opts);
end
eigval=diag(eigval_matrix);
[sort_eigval,sort_eigval_index]=sort(eigval);
T0=eigvec(:,sort_eigval_index(end:-1:1));

switch metric %determine the metric in the embedding space
  case 'weighted'
   TSELF=T0.*repmat(sqrt(abs(sort_eigval(end:-1:1)))',[d,1]);
  case 'orthonormalized'
   [TSELF,dummy]=qr(T0,0);
  case 'plain'
   TSELF=T0;
end


