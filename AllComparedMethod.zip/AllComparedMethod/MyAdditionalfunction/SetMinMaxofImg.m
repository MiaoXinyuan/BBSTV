function OutPutImg = SetMinMaxofImg(InPutImg,MinMax)
%% set the min and max value of InPutImg
%% OutPutImg = SetMinMaxofImg(InPutImg,MinMax)
% MinMax is a two-column matrix;
%  MinMax(k,1) is the min value of band k; and MinMax(k,2) is the max value of band k
if length(MinMax) <= 2
    error('MinMax must be row vectors including two columns');
end
if size(InPutImg,3) >= 1 && size(MinMax,1) == 1
    MinMax = repmat(MinMax,size(InPutImg,3),1);
end
OutPutImg = InPutImg;
for k = 1 : size(InPutImg,3)
    OutPutImg(:,:,k) = ((InPutImg(:,:,k) <= MinMax(k,2))&...
        (InPutImg(:,:,k) >= MinMax(k,1))).*InPutImg(:,:,k) + ...
        (InPutImg(:,:,k) > MinMax(k,2))*MinMax(k,2) + ...
        (InPutImg(:,:,k) < MinMax(k,1))*MinMax(k,1);
end
    
