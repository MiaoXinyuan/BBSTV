function Dete = RXdetector(HSI)
% RX �쳣�������

[h,w,B] = size(HSI);
HSI = reshape(HSI,h*w,B)';
[~,N] = size(HSI);
mMean = mean(HSI,2);
HSI = bsxfun(@minus,HSI,mMean);

sigma = cov(HSI',1);
sigmaInv = sigma^(-1);
result = zeros(N,1);
for i = 1:N
    result(i,1) = HSI(:,i)'*sigmaInv*HSI(:,i);
end
result = reshape(result,h,w);
Dete =(result-min(result(:)))/(max(result(:))-min(result(:)));
