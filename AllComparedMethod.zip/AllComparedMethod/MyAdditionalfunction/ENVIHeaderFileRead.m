function ImgInfo = ENVIHeaderFileRead(FileName)
Fd = fopen(FileName,'rt+');
%% read all information in the head file
Info = fgets(Fd);
FileContent = Info;
while Info ~= -1
    Info = fgets(Fd);
    if any((int16(Info) ~= 10) & (Info ~= -1))    
        FileContent = char(FileContent,Info);
    end
end
fclose(Fd);
%% set ImgInfo
Line = 1;
while Line <= size(FileContent,1)
    Info = strtrim(FileContent(Line,:));
    if strfind(Info,'band names') & strfind(Info,'=')
        ImgInfo.Bandnames = ENVIHeaderStringRead(FileContent,Line,1);
    end
    if strfind(Info,'bands') & isempty(strfind(Info,'default'))
        ImgInfo.Imgband = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info,'byte order') & strfind(Info,'=')
        ImgInfo.Byteorder = cell2mat(regexp(Info,'\d', 'match'));
    end
    if strfind(Info,'class lookup') & strfind(Info,'=')
        ImgInfo.Classlookup = ENVIHeaderStringRead(FileContent,Line,0);
        ImgInfo.Classlookup = reshape(str2num(ImgInfo.Classlookup)',3,ImgInfo.Classes)';
        ImgInfo.Classlookup = ImgInfo.Classlookup./255;
    end
    if strfind(Info,'class names') & strfind(Info,'=')
        ImgInfo.Classnames = ENVIHeaderStringRead(FileContent,Line,1);
    end
    if strfind(Info,'classes') & strfind(Info,'=')
        ImgInfo.Classes = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info,'coordinate system string = {')
        ImgInfo.Coordinatesystemstring = ENVIHeaderStringRead(FileContent,Line,0);
    end
    if strfind(Info,'data type') & strfind(Info,'=')
        ImgInfo.Datatype = ENVITypeToClass( cell2mat(regexp(Info,'\d', 'match')) );
    end
    if strfind(Info,'default bands') & strfind(Info,'=')
        ImgInfo.Defaultbands = ENVIHeaderStringRead(FileContent,Line,1);
    end
    if strfind(Info,'description') & strfind(Info,'=')
        ImgInfo.Description = ENVIHeaderStringRead(FileContent,Line,0);
    end
    if strfind(Info,'file type') & strfind(Info,'=')
        ImgInfo.Filetype = strtrim(FileContent(Line,strfind(Info,'=')+1:end));
    end
    if strfind(Info,'header offset') & strfind(Info,'=')
        ImgInfo.Offset = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info, 'interleave') & strfind(Info,'=')
        ImgInfo.Interleave = strtrim(FileContent(Line,strfind(Info,'=')+1:end));
    end
    if strfind(Info,'lines') & strfind(Info,'=')
        ImgInfo.Imgheight = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info,'map info = {')
        ImgInfo.Mapinfo = ENVIHeaderStringRead(FileContent,Line,0);
        Sep = strfind(ImgInfo.Mapinfo,',');
        ImgInfo.Pixelsize{1,1} = str2num(ImgInfo.Mapinfo(Sep(5)+1:Sep(6)));
        ImgInfo.Pixelsize{2,1} = str2num(ImgInfo.Mapinfo(Sep(6)+1:Sep(7)));
        Sep = strfind(lower(ImgInfo.Mapinfo),'=');
        ImgInfo.Pixelsize{3,1} = ImgInfo.Mapinfo(Sep+1:end);
    end
    if strfind(Info,'pixel size = {')
        ImgInfo.Pixelsize = ENVIHeaderStringRead(FileContent,Line,1);
        ImgInfo.Pixelsize{1,1} = str2num(ImgInfo.Pixelsize{1});
        ImgInfo.Pixelsize{2,1} = str2num(ImgInfo.Pixelsize{2});
        if length(ImgInfo.Pixelsize)>2
            Sep = strfind(lower(ImgInfo.Pixelsize{3,1}),'=');
            ImgInfo.Pixelsize{3,1} = ImgInfo.Pixelsize{3,1}(Sep+1:end);
        end
    end
    if strfind(Info,'samples') & strfind(Info,'=')
        ImgInfo.Imgwidth = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info,'sensor type') & strfind(Info,'=')
        ImgInfo.Sensortype = strtrim(FileContent(Line,strfind(Info,'=')+1:end));
    end
    if strfind(Info,'wavelength = ')
        ImgInfo.Wavelength = ENVIHeaderStringRead(FileContent,Line,1);
    end
    if strfind(Info,'wavelength units') & strfind(Info,'=')
        ImgInfo.Wavelengthunits = strtrim(FileContent(Line,strfind(Info,'=')+1:end));
    end
    if strfind(Info,'x start') & strfind(Info,'=')
        ImgInfo.X_start = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info,'y start') & strfind(Info,'=')
        ImgInfo.Y_start = str2double(cell2mat(regexp(Info,'\d', 'match')));
    end
    if strfind(Info, 'data gain values = {')
        ImgInfo.Datagain = ENVIHeaderStringRead(FileContent,Line,1);
    end
    if strfind(Info, 'data offset values = {')
        ImgInfo.Dataoffset = ENVIHeaderStringRead(FileContent,Line,1);
    end
      
    Line = Line+1;
end

function StringData = ENVIHeaderStringRead(FileContent,Line,Separate)
%% read strings between '{' and '}'
Info = strtrim(FileContent(Line,:));
temp = Info( strfind(Info,'{')+1:end  );
temp2 = strfind(Info,'}');
while isempty(temp2)
    Line = Line + 1;
    Info = strtrim(FileContent(Line,:));
    temp2 = strfind(Info,'}');
    temp = [temp,strtrim(FileContent(Line,:))];
end
if Separate == 1
    temp(end) = ',';
    SeparateSign = [0,strfind(temp,',')];
    for j = 1:length(SeparateSign)-1
        StringData{j,1} = strtrim(temp(SeparateSign(j)+1:SeparateSign(j+1)-1));
    end
else
    StringData = temp(1:end-1);
end

