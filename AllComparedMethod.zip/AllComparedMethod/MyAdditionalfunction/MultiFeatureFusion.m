function [Classified_Result,Classifiedmap] = MultiFeatureFusion(Features,sampleindex,Groundtruth,method,param,FE)
% Multiple Features fusion
% 	[Classified_Result,Classifiedmap] = MultiFeatureFusion(Features,sampleindex,Groundtruth,method,param,testorimage)
%
% Input:
%   Features:       a cell including several kinds of features, the form of classifier is shown below.
%               each line denotes the features of a pixel, each column corresponds to a single feature
%               Note: the Features{1} must be spectral features
%   sampleindex:    {trainindex,validindex,testidex}
%   Groundtruth:    the groundtruth map
%   methods:        algorithm of feature fusion
%   weightparam:	weight parameters for each feature
%   FE:             {Method,ReducedDim,Samples,SVMcgtable};
% Output:
%   Classified_Result: the result
%   Classifiedmap:  The classification map, 
%               if FE.Samples == 0, Classifiedmap is the prediction label of testing samples.
%   Classified_Result: confusion result.
%       Classifiers
%   {1}    {2}    {3} ...
%   ---    ---    ---         ---
%  |   |  |   |  |   |       /  /|
%  |   |  |   |  |   |...    --- |
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   |/
%   ---    ---    ---        ---

nfeatures = length(Features);
[imgpixel,~]=size(Features{1});
for j = 1:nfeatures
    Features{j} = (Features{j}-min(Features{j}(:)))./(max(Features{j}(:))-min(Features{j}(:)));
end

switch method
    case 'MFC'
        MultipleFeatures = horzcat(Features{:});
        inddd = randsample(imgpixel,2000);
        for j = 1:nfeatures
            X{j} = Features{j}(inddd,:);
        end
        if ~exist('param','var')
            param.d = 30;
            param.k = 15;
        end
        [t,r] = GetMFCtr(X, MultipleFeatures(sampleindex.trainindex,:),Groundtruth(sampleindex.trainindex),...
            MultipleFeatures(sampleindex.validindex,:),Groundtruth(sampleindex.validindex),param.d, param.k);
        U = MFC(X,r,t,param.d,param.k);
        finalfeature = MultipleFeatures * U;
        
        [Classifiedmap,~,Classified_Result] = HyperFESVM(finalfeature,Groundtruth,sampleindex,FE);
           
    case 'MKL'
        SPA = [];
        for j = 2:nfeatures
            SPA = horzcat(SPA,Features{j});
        end
        if ~exist('param','var')
            [param.kerneltt,param.sigma,param.c,param.epsilon] = deal('gaussian',2,10000,1e-7);
        end
        
        [TrainsampleSPE,TrainsampleSPA] = deal(Features{1}(sampleindex.trainindex,:),SPA(sampleindex.trainindex,:));
        u_best = MultikernelUcrossvalid(TrainsampleSPE,TrainsampleSPA,Groundtruth(sampleindex.trainindex),...
            param.kerneltt,param.sigma,param.c,param.epsilon);
        kerneloption_s.matrix  = (1-u_best)*svmkernel(TrainsampleSPE,param.kerneltt,param.sigma) + ...
            u_best*svmkernel(TrainsampleSPA,param.kerneltt,param.sigma);
        
        [~,w,b,nbsv,~,pos,~] = svmmulticlassoneagainstone([],Groundtruth(sampleindex.trainindex),...
            max(Groundtruth(:)),param.c,param.epsilon,'numerical',kerneloption_s);
        SPESv = TrainsampleSPE(pos,:);    SPASv  = TrainsampleSPA(pos,:);
        if FE.Samples == 0
            %�Բ����������з���
            [TestsampleSPE,TestsampleSPA] = deal(Features{1}(sampleindex.testindex,:),SPA(sampleindex.testindex,:));
            
            kerneloption_s.matrix = (1-u_best)*svmkernel(TestsampleSPE,param.kerneltt,param.sigma,SPESv) + ...
                u_best*svmkernel(TestsampleSPA,param.kerneltt,param.sigma,SPASv);
            
            [Classified_Result,~,~] = svmmultivaloneagainstone([],[],w,b,nbsv,'numerical',kerneloption_s,Groundtruth(sampleindex.testindex));
            Classified_Result = Confusmat(Groundtruth(sampleindex.testindex),Classified_Result);
        else
            %����ͼ���з���
            Classified_Result = zeros(length(Groundtruth),1);
            gggg = floor(length(Groundtruth)/10000);
            for j =1:gggg
                addd = (j-1)*10000+1:j*10000;
                [ImgSPE,ImgSPA] = deal(Features{1}(addd,:),SPA(addd,:));
                kerneloption_s.matrix = (1-u_best)*svmkernel(ImgSPE,param.kerneltt,param.sigma,SPESv) + ...
                    u_best*svmkernel(ImgSPA,param.kerneltt,param.sigma,SPASv);
                [Classified_Result(addd),~,~]=svmmultivaloneagainstone([],[],w,b,nbsv,'numerical',kerneloption_s,zeros(10000,1));
            end
            addd = gggg*10000+1:length(Groundtruth);
            [ImgSPE,ImgSPA] = deal(Features{1}(addd,:),SPA(addd,:));
            kerneloption_s.matrix = (1-u_best)*svmkernel(ImgSPE,param.kerneltt,param.sigma,SPESv) + ...
                u_best*svmkernel(ImgSPA,param.kerneltt,param.sigma,SPASv);
            [Classified_Result(addd),~,~]=svmmultivaloneagainstone([],[],w,b,nbsv,'numerical',kerneloption_s,zeros(length(addd),1));
            Classified_Result = Confusmat(Groundtruth(sampleindex.testindex),Classified_Result(sampleindex.testindex));
        end
    otherwise
        disp('Unrecognized method');
end

