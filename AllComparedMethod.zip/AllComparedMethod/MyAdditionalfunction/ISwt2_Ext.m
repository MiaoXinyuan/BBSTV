function Img = ISwt2_Ext(A, H, V, D ,wname)
%% function [ A, H, V, D ] = Swt2_Ext(Img)
%  extension function of swt2
%  extend the size of Img into the least power of 2 for swt2
[ Row,Col, ~ ] = size(A);

nR = 2^(ceil(log2(Row)));
nC = 2^(ceil(log2(Col)));

[ ExtR, ExtC ] = deal( (nR-Row)/2, (nC-Col)/2);
if ExtR ~= fix(ExtR)
    [ ExtR1, ExtR2 ] = deal(floor(ExtR),ceil(ExtR));  
else
    [ ExtR1, ExtR2 ] = deal(ExtR);  
end
if ExtC ~= fix(ExtC)
    [ ExtC1, ExtC2 ] = deal(floor(ExtC),ceil(ExtC)); 
else
    [ ExtC1, ExtC2 ] = deal(ExtC);
end

AExt = Extens(A,[ExtR1,ExtC1,ExtR2,ExtC2],'per');
HExt = Extens(H,[ExtR1,ExtC1,ExtR2,ExtC2],'per');
VExt = Extens(V,[ExtR1,ExtC1,ExtR2,ExtC2],'per');
DExt = Extens(D,[ExtR1,ExtC1,ExtR2,ExtC2],'per');
ImgExt = iswt2(AExt, HExt, VExt, DExt, wname);
Img = ImgExt( ExtR1+1 : ExtR1+Row, ExtC1+1 : ExtC1+Col, :);

