function [SAM,V] = SpecAngleMatch(A,re)
% [SAM,V] = SpecAngleMatch(A,re)
% spectral angle mapping

%   A:  hyperspectral image
%   re: target spectrum
%   return : 
%   SAM: spectral angle mapping
%   V: angle of each pixel�� [0,pi/2]

[row,col,band] = size(A);
if band > 1
    A = double(reshape(A,row*col,band));
end
re = re(:);
RT = A*re(:);
R = (sum(A.^2,2)).^0.5;
T = (sum(re.^2))^0.5;
SAM = RT./(R.*T);
V = acos(SAM);
if band > 1
    SAM = reshape(SAM,row,col);
    V = reshape(V,row,col);
end

            