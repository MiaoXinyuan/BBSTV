function [M,S,MS,f] = NMF_Euclid(R,p,nmfmode,M0,S0,iterparam,param)
% ����ŷ�Ͼ���ķǸ�����ֽ�NMF
% [M,S,MS] = NMF_Euclid(R,p,mode,M0,S0,param)
% Input��   R: ԭʼ���ݾ���
%           p: ��Ԫ����
%           nmfmode: type of NMF,which can be 'NMF','CNMF','nsNMF';
% Optional input params:
%           M0: ��ʼ��Ԫ�������գ���Ϊ���ָ��
%           S0: ��ʼ��Ⱦ������գ���Ϊ���ָ��
%           param: other params if need for different type of NMF
%           iterparam: params for iters
% Output:   M: ��Ԫ����
%           S: ��Ⱦ���
%           MS = M*S;
%           f = sum(||R-MS||.^2)
% R = MS; R��L��B��ΪB��Lά��������M��L��p����S��p��B��
[L,B] = size(R);   %��ȡV����ά��

if nargin <6
    if nargin < 5
        if nargin < 4
            if nargin < 3
                nmfmode = 'NMF';
            end
            M0 = rand(L,p); %��������Ǹ�����M
        end
        S0 = rand(p,B); %��������Ǹ�����S
    end
    iterparam.maxiter = 1000;
    iterparam.tol = 10^(-3);
else
    if ~isfield(iterparam,'maxiter')
        iterparam.maxiter = 1000;
    end
    if ~isfield(iterparam,'tol')
        iterparam.tol = 10^(-3);
    end
end

S0 = bsxfun(@rdivide,S0,sum(S0));
M = M0; S = S0;

switch nmfmode
    case 'NMF'
        f = sum(sum((R - M*S).^2))/(L*B);
        for iter = 1:iterparam.maxiter
            if f >  iterparam.tol
                M = M.*(R*S')./(M*S*S');
                S = S.*(M'*R)./(M'*M*S);
                
                S = bsxfun(@rdivide,S,sum(S));
                f = sum(sum((R - M*S).^2))/(L*B);
                disp(f);
            else
                break;
            end
        end
        
    case 'CNMF'
        if ~exist('param','var')
            param.alpha = 0.01;
            param.belta = 0.5;
        else
            if ~isfield(param,'alpha')
                param.alpha = 0.01;
            end
            if ~isfield(param,'belta')
                param.belta = 0.5;
            end
        end
        f = (sum(sum((R - M*S).^2))+param.alpha*sum(M(:).^2)+param.belta*sum(S(:).^2))/(L*B);
        
        for iter = 1:iterparam.maxiter
            if f >  iterparam.tol
                M1 = M.*(R*S'-param.alpha.*M)./(M*S*S'+10^(-16));
                S1 = S.*(M1'*R-param.belta.*S)./(M1'*M1*S+10^(-16));
                M1(M1<0)=0;
                S1(S1<0)=0;
                S1 = bsxfun(@rdivide,S1,sum(S1));
                M = M1;
                S = S1;
                f = (sum(sum((R - M*S).^2))+param.alpha*sum(M(:).^2)+param.belta*sum(S(:).^2))/(L*B);
                disp(f);
            else
                break;
            end
        end
    case 'nsNMF'
        if ~exist('param','var')
            param.alpha = 0.01;
            param.belta = 0.5;
            param.theta = 0.8;
        else
            if ~isfield(param,'alpha')
                param.alpha = 0.01;
            end
            if ~isfield(param,'belta')
                param.belta = 0.5;
            end
            if ~isfield(param,'theta')
                param.theta = 0.8;
            end
        end
        C = (1-param.theta).*eye(p)+param.theta/p.*ones(p);
        f = (sum(sum((R - M*C*S).^2))+param.alpha*sum(M(:).^2)+param.belta*sum(S(:).^2))/(L*B);
        
        for iter = 1:iterparam.maxiter
            if f >  iterparam.tol
                M1 = M.*(R*S'-param.alpha.*M)./(M*S*S'+10^(-16));
                S1 = S.*((M1*C)'*R-param.belta.*S)./((M1*C)'*(M*C)*S+10^(-16));
                M1(M1<0)=0;
                S1(S1<0)=0;
                S1 = bsxfun(@rdivide,S1,sum(S1));
                M = M1;
                S = S1;
                f = (sum(sum((R - M*C*S).^2))+param.alpha*sum(M(:).^2)+param.belta*sum(S(:).^2))/(L*B);
                disp(f);
            else
                break;
            end
        end
end
MS = M*S;