function ImshowPercentage(Img,Para)
% ImshowPercentage(Img,Para)

% Linear 2% image displaying
if nargin < 2
    Para = 0.02;
end
Img = double(Img);
Img = mat2gray(Img)*2048;
if size(Img,3) == 1
    Histimg = Imhistogram(Img,'noracc');
    Low_per_ind = find(Histimg >= Para);
    High_per_ind = find(Histimg <= 1-Para);
    hshowaxes = imshow(Img,[Low_per_ind(1),High_per_ind(end)]);
elseif size(Img,3) == 3
    Histimg = Imhistogram(Img ,'noracc');
    Low_per_ind = find(Histimg >= Para);
    High_per_ind = find(Histimg <= 1-Para);
    for j = 1:3 
        Img(:,:,j) = (Img(:,:,j) < Low_per_ind(1)).*Low_per_ind(1) + (Img(:,:,j) > High_per_ind(end)).*High_per_ind(end) +...
            ((Img(:,:,j) >= Low_per_ind(1))&(Img(:,:,j) <= High_per_ind(end))).*Img(:,:,j);
    end
    hshowaxes = imshow(mat2gray(Img));
end
set(hshowaxes,'ButtonDownFcn',@ShowImageCallback);

