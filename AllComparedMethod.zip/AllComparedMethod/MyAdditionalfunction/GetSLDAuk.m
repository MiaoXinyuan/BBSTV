function bestuk = GetSLDAuk(SampleTrain,TrainLabels,SampleValid,LabelsValid,UnlabelSample,options,parame)

if strcmp(parame.Classifier, 'SVM') && ~isfield(parame,'SVMcgtable')
    parame.SVMcgtable.c1 = [10^3,10^4,10^5];
    parame.SVMcgtable.g1 = [ 0.1,   1,  10];
end
if ~isfield(parame,'numofuk')
    parame.numofuk = [2 3 5 7];
end

OCA_ukSLDA=zeros(size(parame.numofuk));
for ti = 1:length(parame.numofuk)
    options.uk = parame.numofuk(ti);
    TSLDA = SLDA(SampleTrain,TrainLabels,UnlabelSample,options);
    STr_SLDA = SampleTrain * TSLDA;
    STv_SLDA = SampleValid * TSLDA;
    switch parame.Classifier
        case 'SVM'           
            ST = [STr_SLDA;STv_SLDA];
            STr_SLDA = (STr_SLDA-min(ST(:)))/(max(ST(:))-min(ST(:)));
            STv_SLDA = (STv_SLDA-min(ST(:)))/(max(ST(:))-min(ST(:)));
            [bestc,bestg] = GetSVMcg(STr_SLDA,TrainLabels,STv_SLDA,LabelsValid,parame.SVMcgtable);
            cmd = ['-c ',num2str(bestc),' -g ',num2str(bestg),' -q'];
            model = svmtrain(TrainLabels,STr_SLDA,cmd);
            [~,OCA,~] = svmpredict(LabelsValid,STv_SLDA,model);
        case 'MLC'
            [~,OCA] = MLC(STr_SLDA,TrainLabels,STv_SLDA,LabelsValid);
    end
    OCA_ukSLDA(ti) = OCA(1);
end
[~,ind] = max(OCA_ukSLDA);
bestuk = parame.numofuk(ind);