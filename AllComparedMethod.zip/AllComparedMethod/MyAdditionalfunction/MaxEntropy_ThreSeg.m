function MaxEnt_Threshold = MaxEntropy_ThreSeg( ImgDiff )
%% MaxEnt_Threshold = MaxEntropy_ThreSeg( ImgDiff )
%  computer the threshold of difference image by MaxEntropy

GrayLevel = Imhistogram(ImgDiff,'nor',0);
s1 = cumsum(GrayLevel); s1(end) = 1;
s2 = 1-s1;
L = length(GrayLevel);
Ent = zeros(1,L);
for j = 1:L-1
    Cp1 = GrayLevel(1:j);
    Cp2 = GrayLevel(j+1:end);   
    Cs1 = s1(1:j);  
    Cs2 = s2(j+1:end);  
    if Cs1(end) ~= 0 
        temp1 = Cp1./Cs1(end); 
    else 
        temp1 = zeros(1,j);
    end
    if Cs2(1) ~= 0
        temp2 = Cp2./Cs2(1);
    else
        temp2 = zeros(1,L-j);
    end
    Ent(j) = -sum(temp1(temp1~=0).*log(temp1(temp1~=0)))-sum(temp2(temp2~=0).*log(temp2(temp2~=0)));
end

[~, MaxEnt_Threshold] = max(Ent);
MaxEnt_Threshold = MaxEnt_Threshold - 1;