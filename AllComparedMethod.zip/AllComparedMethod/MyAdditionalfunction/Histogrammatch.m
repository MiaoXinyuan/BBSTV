function E = Histogrammatch(S,O,rul)
%DN belongs to 0��65536
%       E  =  Histmatch16(S,O)
%S:     Original image;
%O:     Objective image;
%rul:   Mapping rule, can be 'gml','sml','GML',SML';
%return:Histogram processed image;
if nargin<3
    rul = 'gml';
end
[ S, O ]= deal(round(S),round(O));
[Ohist1,~,Omax] = Imhistogram(O,'noracc',0); %normalized accumulated histgram
[Shist1,~,Smax] = Imhistogram(S,'noracc',0);
Shist = Imhistogram(S,'hist',0);
Pmax = max(Omax,Smax);
Ohist1 = [Ohist1,ones(1,Pmax-Omax)];
Shist1 = [Shist1,ones(1,Pmax-Smax)];
Shist = [Shist,zeros(1,Pmax-Smax)];
index = zeros(1,Pmax+1);
switch rul
    case 'GML'        %Group mapping rule
        graymarker  =  1;
        for k  =  1:(Pmax+1)
            if Ohist1(k)  ==  0;
                graymarker  =  graymarker + 1;
            else
                break;
            end
        end
        linit  =  graymarker;
        index(1)  =  linit;  indexcnt  =  2;        
        indis0  =  zeros(1,Pmax+1);      
        for l  =  linit:(Pmax+1)
            mappingL  =  zeros(1,(Pmax+1));
            if Ohist1(l)  ==  Ohist1(l - 1);
                continue;
            end
            for k  =  1:Pmax
                if Shist1(k) == Shist1(k + 1)
                    continue;
                end
                mappingL(k)  =  abs(Ohist1(l) - Shist1(k)); % GML rule
                if mappingL(k)  ==  0
                    indis0(k)  =  0;
                end
            end
            mappingL(Pmax+1)  =  abs(Ohist1(l) - Shist1(Pmax+1));
            indtemp1  =  find(mappingL == 0);
            indtemp2  =  find(indis0 == 1);
            mappingL(setdiff(indtemp1,indtemp2)) = inf;
            [~,minind]  =  min(mappingL);
            for pp  =  indexcnt:minind
                index(pp)  =  l; 
            end
            indexcnt  =  minind + 1;
        end
        index(Pmax+1) = Pmax+1;
        histm  =  zeros(1,(Pmax+1));
        for k  =  1:(Pmax+1)
            histm(index(k))  =  histm(index(k)) + Shist(k);
        end
        E(:,:) = index(S(:,:)+1)-1;
    case 'SML'
        %Single mapping rule
        for k = 1:(Pmax+1)
            mappingL  =  zeros(1,Pmax+1);
            for l  =  1:(Pmax+1)
                mappingL(l)  =  abs(Shist1(k) - Ohist1(l));
            end
            [~,index(k)]  =  min(mappingL);
        end
        histm  =  zeros(1,(Pmax+1));
        for k  =  1:(Pmax+1)
            histm(index(k))  =  histm(index(k)) + Shist(k);
        end
        E(:,:) = index(S(:,:)+1)-1;
    case 'gml'
        %group mapping rule
        lastStartY  =  1; lastEndY  =  1; startY  =  1;
        srcMin = zeros(Pmax+1);
        for y = 1:(Pmax+1)
            srcMin(:,y) = abs(Shist1(y)-Ohist1(:));
        end
        for x = 1:(Pmax+1)
            [~,endY] = min(srcMin(x,:));
            if (startY ~= lastStartY)||(endY ~= lastEndY)
                index(startY:endY) = x;
                lastStartY  =  startY;   
                lastEndY  =  endY;   
                startY  =  lastEndY + 1;
            end
        end
        E(:,:) = index(S(:,:)+1)-1;  
    case 'sml'
        %single mapping rule
        %look for the closest point of two histgrams
        for i = 1:(Pmax+1)                       
            [~,index(i)] = min(abs(Ohist1-Shist1(i)));
        end
        if min(O(:)) <= min(S(:))
            index(min(S(:))+1) = min(O(:));
        end
        %mapping new gray level by original image gray level
        E(:,:) = index(S(:,:)+1)-1;  
    otherwise
        disp('unrecognized mapping rule');
end
        

