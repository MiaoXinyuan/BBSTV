function Classcolor = ClassColTab(datasets)
% Classcolor = ClassColTab(datasets)
% color table for classification of datasets of CoP,UoP,DFC2013(houston),DFC2014(Quebec), Sandiego
% Input:    name of dataset;
% Output:   color table;
switch lower(datasets)
    case 'cop'
        Classcolor = [  0,  0,255;  %water
              0,128,  0;            %tree
              0,255,  0;            %meadow
            255,  0,  0;            %brick
            142, 71,  0;            %bare_soil
            192 192 192;            %asphalt
              0,255,255;            %bitumen
            255,110,  0;            %tile
            255,255,  0]/255;       %shadow
    case 'uop'
        Classcolor = [192,192,192;  %asphalt
              0,255,  0;            %meadow
              0,255,255;            %sand
              0,128,  0;            %tree
            255,  0,255;            %metal plate
            142, 71,  0;            %bare_soil
            181, 60,  0;            %bitumen
            255,  0,  0;            %brick
            255,255,  0]/255;       %shadow
    case {'dfc2013','houston'}
        Classcolor = [  0,205,  0;  %Green2
            127,255,  0;            %Chartreuse
             46,139, 87;            %Sea Green
              0,139,  0;            %Green3
            160, 82, 45;            %Sienna
              0,255,255;            %Cyan
            255,255,255;            %White
            216,191,216;            %Thistle
            255,  0,  0;            %Red
            139,  0,  0;            %Red3
              0,  0,255;            %blue
            255,255,  0;            %Yellow
            238,154,  0;            %Orange2
            85, 26,139;             %Purple3
            255,127, 80             %Coral
            ]/255;
    case {'dfc2014','quebec'}
        Classcolor = [255,  0,255;  % road [Magenta],
              0,255,  0;            % trees [Green],
            255,  0,  0;            % red roof [Red],
              0,255,255;            % grey roof [Cyan],
            160, 32,240;            % concrete roof [Purple],
             46,139, 87;            % vegetation [Sea Green],
            255,255,  0]/255;       % bare soil [Yellow],
    case {'sandiego','san diego'}
        Classcolor = [255,  0,  0;  % tarmac1 [red]
              0,255,  0;            % tarmac2 [green]
              0,  0,255;            % concrete roof [blue]
            255,255,  0;            % tree [yellow]
              0,255,255;            % brick [cyan]
            255,  0,255;            % bare soil [Magenta]
            176, 48, 96;            % butumen roof [dark red]
             46,139, 87]/255;       % tree [Sea Green]
    case 'indian'
        Classcolor =  [94.0000  203.0000  182.5000
  255.0000         0  255.0000
  217.0000  115.0000         0
  179.0000   30.0000         0
         0  128.5000  255.0000
   72.0000         0         0
  127.5000  255.0000  127.5000
  145.0000  132.0000  135.0000
         0  255.0000  172.0000
  255.0000  197.0000   80.0000
   60.0000  201.0000   25.5000
   11.0000   88.5000  124.0000
         0         0  255.0000
   11.0000  219.0000  243.0000
  164.0000   89.0000  153.0000
  121.0000   17.0000  237.0000]/255;
    otherwise
        disp('Wrong parameters of datasets');
end
