function [MNF,TR]=Mnftransform(X,Noise)
%MNF transform
%       [MNF,F,LAMDA]=Mnftransform(X,Noise)
%MNF:   Result of MNF transform;
%TR:    MNF transform matrix;
%LAMDA: Eigens vector;
%X:     Input image;
%Noise: Noise model image of X if exist;
msize=size(X);
Xs=reshape(X,msize(1)*msize(2),msize(3));
if nargin == 1 || isempty(Noise)
%     h=ones(3).*(-1); h(2,2)=8; 
%     %construct the noise model;
%     for b=1:msize(3)
%         Noise(:,:,b)=filter2(h,X(:,:,b));
%     end
      for b=1:msize(3)
          Noise(:,:,b)=X(:,:,b)-medfilt2(X(:,:,b));
      end
end
%compute eigen vectors and eigen values of noise model covariance;
Cn=cov(reshape(Noise,msize(1)*msize(2),msize(3)));
[En,Lamdan]=eig(Cn);
% En=fliplr(En);Lamdan=rot90(Lamdan,2);
Fn=En*inv(Lamdan.^0.5);
%standard PCA transform
%compute image covariance with unit noise covariance matrix
Cx=cov(Xs);
Cdadj=Fn'*Cx*Fn;
[V,~]=eig(Cdadj);
V=fliplr(V);
TR=Fn*V;
MNF=reshape((TR'*Xs')',msize(1),msize(2),msize(3));