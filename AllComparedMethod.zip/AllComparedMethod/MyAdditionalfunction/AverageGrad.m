function Avg = AverageGrad(Img,Para)
% Avg = AverageGrad(Img,Para)
% Compute the average gradient or the total variation of Img
% Img: the original image
% Para: can be TV (total variation) or AVG (average gradient), default is AVG
[ Gx , Gy ] = gradient(double(Img));

Gx = (Gx.^2 + Gy.^2);
if nargin  == 1
    Para = 'AVG';
end


switch Para
    case 'TV'
        Avg = sum(sqrt(Gx(:)));
    case 'AVG'
        Avg = sum(sqrt(Gx(:)))/(size(Img,1)*size(Img,2));
end
