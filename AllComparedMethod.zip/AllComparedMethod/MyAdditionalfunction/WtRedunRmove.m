function [A0, H0, V0, D0, ReImg, RMSE] = WtRedunRmove(A, H, V, D, WaveName, Img)
%% function [] = WtRedunRmove(A, H, V, D, Img, WaveName)
%  Remove the redundancy of wavelet decomposited coefficients
% Since the sum of low-pass filters coefficients of wavelet is 2, the
% decomposited plane of wavelet will increase by a time of 2.
% it is the redundancy that should be removed
% [A, H, V, D] are the decomposited planes of 'Img' by 'swt';
% 'Img' is the original image, if exist, the function will compute the reconstructed RMSE.

[ A0, H0, V0, D0 ] = deal(A, H, V, D);
temp = zeros(size(A));
N = size(A,3);

if ischar(WaveName)   
    for j = 1:N
        A0(:,:,j) = iswt2(A(:,:,1:j),temp(:,:,1:j),temp(:,:,1:j),temp(:,:,1:j),WaveName);
        
        Ztemp = temp;   Ztemp(:,:,j) = H(:,:,j);
        H0(:,:,j) = iswt2(temp,Ztemp,temp,temp,WaveName);
        
        Ztemp = temp;   Ztemp(:,:,j) = V(:,:,j);
        V0(:,:,j) = iswt2(temp,temp,Ztemp,temp,WaveName);
        
        Ztemp = temp;   Ztemp(:,:,j) = D(:,:,j);
        D0(:,:,j) = iswt2(temp,temp,temp,Ztemp,WaveName);
    end
else
    Lo_R = WaveName(1,:);
    Hi_R = WaveName(2,:);
    for j = 1:N
        A0(:,:,j) = iswt2(A(:,:,1:j),temp(:,:,1:j),temp(:,:,1:j),temp(:,:,1:j),Lo_R,Hi_R);
        
        Ztemp = temp;   Ztemp(:,:,j) = H(:,:,j);
        H0(:,:,j) = iswt2(temp,Ztemp,temp,temp,Lo_R,Hi_R);
        
        Ztemp = temp;   Ztemp(:,:,j) = V(:,:,j);
        V0(:,:,j) = iswt2(temp,temp,Ztemp,temp,Lo_R,Hi_R);
        
        Ztemp = temp;   Ztemp(:,:,j)= D(:,:,j);
        D0(:,:,j) = iswt2(temp,temp,temp,Ztemp,Lo_R,Hi_R);
    end
end

ReImg = A0(:,:,N) + sum(H0,3)+sum(V0,3)+sum(D0,3);
if nargin > 5
    RMSE = sqrt(sum(sum((ReImg-Img).^2))/(size(Img,1)*size(Img,2)));
end
