clear;clc;
s = 3;     % ͼ��ֱ���֮��
HSI = double(ENVIImgRead('E:\Workspace\Datasets\UofPavia\University of Pavia')); 
HSI = Extens(HSI,1,'sym');    
% HSI = double(ENVIImgRead('Datasets\Sandiego\Sandiego')); 
SioH = size(HSI);
MSI = cat(3, HSI(:,:,53), HSI(:,:,31), HSI(:,:,8) );                    % high resolution color image 
SEG = double(ENVIImgRead('E:\Workspace\Datasets\UofPavia\Upan3060\UoP_pan_attributes.dat')); 
SEG = Mwlabel(SEG);SEG = Extens(SEG,1,'sym'); 

Groundtruth = double(ENVIImgRead('E:\Workspace\Datasets\UofPavia\UPgroundtruth'));   % ground truth image
Groundtruth = Extens(Groundtruth,1,'sym');
% Groundtruth = double(ENVIImgRead('Datasets\Sandiego\sanmap'));
HSI = imresize(HSI,1/s,'nearest');                    % simulated low resolution HSI 

HSI_Resample = imresize(HSI,s,'nearest');                              % upsampled HSI
HSI_Resample = (HSI_Resample-min(HSI_Resample(:)))/(max(HSI_Resample(:))-min(HSI_Resample(:)));
HSI_Resample = reshape(HSI_Resample,prod(SioH(1:2)),SioH(3));

%% HSI image classification
[ Pre_OA, CSM_OA, AMAP_OA, Edge_OA ] = deal(0);
for kk  = 1:1
    Sampleindex.SelectedSamples = 10;
    [Sampleindex.Trainindex,Validindex,Testindex] = SampleSelect(Groundtruth,Sampleindex.SelectedSamples); 
    Trainlabel =  Groundtruth(Sampleindex.Trainindex);
    %% SVM hard classification
    [bestc,bestg] = GetSVMcg( HSI_Resample(Sampleindex.Trainindex,:), Trainlabel, HSI_Resample(Validindex,:), Groundtruth(Validindex));
    model = svmtrain( Trainlabel, HSI_Resample(Sampleindex.Trainindex,:),['-c ',num2str(bestc),' -g ',num2str(bestg),' -b 1 -q']);
    [SVMtest_prelabel,~,~] = svmpredict( Groundtruth(:), HSI_Resample, model,'-b 1');
    RESULTS = Confusmat( Groundtruth(Testindex), SVMtest_prelabel(Testindex) );
    Pre_OA = Pre_OA + RESULTS.OA;
    %% obtain the low-resolution map
    subtest_prelabel = imresize(reshape(SVMtest_prelabel,SioH(1),SioH(2)),1/s,'nearest');
    
    %% context-based mapping
    CSM_Map = ContextSubpixelMapping( HSI, MSI, subtest_prelabel, Groundtruth, Sampleindex);
    RESULTS = Confusmat(Groundtruth(Testindex),CSM_Map(Testindex) );
    CSM_OA  = CSM_OA + RESULTS.OA;
%     %% adaptive MAP-based mapping
%     AMAP_Map = AdaptiveMAPSubpixelMapping( HSI, subtest_prelabel, Groundtruth, Sampleindex);
%     RESULTS = Confusmat(Groundtruth(Testindex),AMAP_Map(Testindex) );
%     AMAP_OA  = AMAP_OA+ RESULTS.OA;
    %% EdgeSubpixelMapping
    Edge_MAP = EdgeSubpixelMapping(HSI, MSI, subtest_prelabel, Groundtruth, Sampleindex);
    RESULTS = Confusmat(Groundtruth(Testindex),Edge_MAP(Testindex) );
    Edge_OA  = Edge_OA + RESULTS.OA;
end
disp(Pre_OA/kk);    disp(CSM_OA/kk);      disp(Edge_OA/kk);
% figure;Showmap(reshape(SVMtest_prelabel,SioH(1),SioH(2)),'UoP');
figure;Showmap(CSM_Map,'UoP');
figure;Showmap(Edge_MAP,'UoP');