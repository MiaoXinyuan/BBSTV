function CAbundance = ClassAbundanceCompute(HSI, Trainindex, Trainlabel, HSI_Classification, EndmemNum)
% CAbundance = ClassAbundanceCompute(HSI, Trainindex, Trainlabel, HSI_Classification, EndmemNum)
% Class abundance computation based on the training samples

% Zahid Mahmood. "Contextual Subpixel Mapping of Hyperspectral Images Making Use of a High
% Resolution Color Image" , JSTARS, VOL. 6, NO. 2, APRIL 2013 
%% Initialization 
C = max(Trainlabel(:));
SioL = size(HSI);
HSI = reshape(HSI,prod(SioL(1:2)),SioL(3));
[SubPixelSub(:,1),SubPixelSub(:,2)] = ind2sub(SioL,1:prod(SioL(1:2)));  % coordinate of each pixel
[tempTrainSub(:,1),tempTrainSub(:,2)] = ind2sub(SioL,Trainindex);        % coordinate of each training pixel
CAbundance = zeros(C, prod(SioL(1:2)));

for Pixel = 1:prod(SioL(1:2))
    DistofTrain = sum( (bsxfun(@minus, tempTrainSub, SubPixelSub(Pixel,:))).^2 , 2); % distance between each training pixel to current pixel
    [~,DistInd] = sort(DistofTrain);                                                    % sort distance with ascend style
    
    SameInd = find( Trainlabel(DistInd) == HSI_Classification(Pixel) );                 
    if length(SameInd) < 5                                                              % select the training pixels with same label 
        SameClassIndex = DistInd(SameInd);
        DistInd(SameInd) = [];  
    else
        SameClassIndex = DistInd(SameInd(1:5)); 
        DistInd(SameInd(1:5)) = [];  
    end
 
    DiffClassIndex = DistInd(1:EndmemNum-length(SameClassIndex));                           % select the training pixels with different label 
      
    Endmember = HSI(Trainindex( [SameClassIndex(:);DiffClassIndex(:)] ),:);      % end members corresponding to current pixel
    Abund = FCLS_single_pixel( Endmember' ,HSI(Pixel,:)');                 % the abundance of each end member corresponding to current pixel
    %% transform the end member abundance into the class abundance 
    EndmemberClass = Trainlabel( [SameClassIndex(:);DiffClassIndex(:)] );  % the label of each end member corresponding to current pixel
    for c = 1:C
        CAbundance(c,Pixel) = sum(Abund(EndmemberClass == c));
    end   
end