%% Contextual Subpixel Mapping using a high-resolution image
% ContextSubpixelMapping( HSI, MSI, HSI_Classification, Groundtruth, Sampleindex):
% Subpixel mapping based on context information provided by a high-resolution image
% sampleindex: a struct including training, valid, testing samples indices

% Zahid Mahmood. "Contextual Subpixel Mapping of Hyperspectral Images Making Use of a High
% Resolution Color Image" , JSTARS, VOL. 6, NO. 2, APRIL 2013 

function  SubPixelMap = ContextSubpixelMapping( HSI, MSI, HSI_Classification, Groundtruth, Sampleindex)

[SioL , SioH] = deal(size(HSI),size(MSI)) ;   if length(SioH) == 2, SioH(3) = 1; end
s = SioH(1)/SioL(1);    % ratio of resolution
EndMemberNum = 10;

MSI = reshape(MSI,prod(SioH(1:2)),SioH(3));
Groundtruth = Groundtruth(:);

SubTrainindex = CoorMap_DiffResolution(SioH,SioL, Sampleindex.Trainindex);
TrainNum = Sampleindex.SelectedSamples;
Trainlabel =  Groundtruth(Sampleindex.Trainindex);

%% high-resolution image k-means clustering
C = max(Groundtruth);
InitCen = zeros(C,3);
for j = 1:C
    InitCen(j,:) = mean( MSI(SubTrainindex(1+TrainNum*(j-1):TrainNum*j),:) );
end
Seg = kmeans(MSI,C,'start',InitCen);
Seg = reshape(Seg, SioH(1),SioH(2));

%% Connected Components Labeling
Fz = Mwlabel(Seg);

%% Class Abundance Computing
[tempSubTrainIndex, ic,~] = unique(SubTrainindex,'rows','stable');  
tempTrainlabel = Trainlabel(ic);
CAbundance = ClassAbundanceCompute(HSI, tempSubTrainIndex, tempTrainlabel, HSI_Classification, EndMemberNum);
%% Subpixel/Pixel Spatial Attraction Model (SPSAM)
SubPixelMap = SPSAM_Mapping( reshape(CAbundance',SioL(1),SioL(2),C), s );

%% Contextual Subpixel Mapping
%% rule 1 
for Pixel = 1:length(SubTrainindex)
    [Row,Col] = ind2sub(SioL,SubTrainindex);
    SubPixelMap( Row*s-s+1:Row*s, Col*s-s+1:Col*s ) =  Groundtruth(Sampleindex.Trainindex(Pixel));
end
%% rule 2
SubPixelMap = Regionpostprocess(SubPixelMap,Fz);
%% rule 3
for Pixel = 1:length(Sampleindex.Trainindex)
    SubPixelMap( Fz(:) == Fz(Sampleindex.Trainindex(Pixel)) ) = Groundtruth(Sampleindex.Trainindex(Pixel));
end

function SubPixelMap = SPSAM_Mapping(Class_Percentage,s)
%% sub-pixel mapping using Subpixel/Pixel Spatial Attraction Model (SPSAM) 
% Class_Percentage: Percentage of each class per pixel,     class �� pixel
% s: ratio of resolution ( number of sub-pixel in each pixel) , s �� s
% SioL: size of low-resolution classfication image, a two-element vector

% distance of each sub-pixel to the 8-neighbor pixels
% The neighbor pixels are traced as follows: (c is the current center pixel)
%	1   4   6
%   2   c   7
%   3   5   8
SioL = size(Class_Percentage);
C = size(Class_Percentage,3);

%% convert the class precentage into pixel numbers for each class
Class_Percentage(Class_Percentage<0) = 0;
CSubpixelnum = reshape( round(Class_Percentage.*s^2), prod(SioL(1:2)), C);
temp = sum(CSubpixelnum,2);
while any(temp ~= s^2)
    for Pixel = 1:prod(SioL(1:2))
        if temp(Pixel) > s^2
            temp1 = find(CSubpixelnum(Pixel,:),1,'last');
            CSubpixelnum(Pixel,temp1) = CSubpixelnum(Pixel,temp1) - 1;
        elseif temp(Pixel) < s^2
            temp1 = find(CSubpixelnum(Pixel,:),1,'last');
            CSubpixelnum(Pixel,temp1) = CSubpixelnum(Pixel,temp1) + 1;
        end
    end           
    temp = sum(CSubpixelnum,2);
end
CSubpixelnum = reshape(CSubpixelnum,SioL(1),SioL(2),C);

%% compute distance
d = zeros(s,s,8);
neibor_pixel_coor = ([-1,-1;1,-1;3,-1;  -1,1;3,1;  -1,3;1,3;3,3])*s/2;
for i = 1:s
    for j = 1:s
        for n = 1:8     
            d(i,j,n) = sqrt(sum(( [i-0.5,j-0.5] - neibor_pixel_coor(n,:)).^2));
        end
    end
end
d = reshape(d,s*s,8)';
%% attraction model
AttractionValue = zeros(s,s,C);
ClassAbundanceExt = Extens(Class_Percentage,1,'sym'); % ��ClassAbundance���б߽�����
SubPixelMap = zeros(SioL(1)*s,SioL(2)*s);
hWait = waitbar(0,'Processing ');
for Col = 1:SioL(2)
    for Row = 1:SioL(1)
        temp =  reshape( ClassAbundanceExt(Row:Row+2, Col:Col+2, :) ,9,C) ;   temp(5,:) = [];       
        for i = 1:s
            for j = 1:s
                for c = 1:C     % attraction value for each sub-pixel for each class
                    AttractionValue(i,j,c) = sum( temp(:,c)./d(:,i+(j-1)*s) );
                end
            end
        end
        %% find the highest value for each pixel    
        while any(CSubpixelnum(Row,Col,:)~=0)           
            temp = reshape(AttractionValue(1:s,1:s,:), s*s,C);
            [Ind,~] = find(temp == max(temp(:)),1,'first'); 
            [i,j] = ind2sub([s,s], Ind); 
            [~, cd] = max(temp(Ind,:));  
            if CSubpixelnum(Row,Col,cd) ~= 0
                SubPixelMap(Row*s-s+i,Col*s-s+j) = cd;
                CSubpixelnum(Row,Col,cd) = CSubpixelnum(Row,Col,cd) - 1;
                AttractionValue(i,j,:) = -1;
            else
                AttractionValue(i,j,cd) = -1;
            end
        end       
    end
    waitbar(Col/SioL(2),hWait,['Processing ',num2str(round(Col/SioL(2)*100)), '%']);
end
close(hWait);



