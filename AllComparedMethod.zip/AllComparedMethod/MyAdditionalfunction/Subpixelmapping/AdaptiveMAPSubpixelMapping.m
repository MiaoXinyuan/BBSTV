%% Adaptive Subpixel Mapping using a high-resolution image
% AdaptiveMAPSubpixelMapping( HSI, HSI_Classification, Groundtruth, Sampleindex)��
% Subpixel mapping based on adaptive MAP
% sampleindex: a struct including training, valid, testing samples indices

% Yanfei Zhong. "An Adaptive Subpixel Mapping Method Based on MAP Model and Class Determination Strategy
% for Hyperspectral Remote Sensing Imagery" , TGRS, VOL. 53, NO. 3, MARCH 2015 

function  [SubPixelMap, SubPixelProb] = AdaptiveMAPSubpixelMapping( HSI, HSI_Classification, Groundtruth, Sampleindex)

[SioL , SioH] = deal(size(HSI),size(Groundtruth) ) ;   
s = SioH(1)/SioL(1);    % ratio of resolution
EndMemberNum = 10;

Groundtruth = Groundtruth(:);
C = max(Groundtruth);
Trainlabel =  Groundtruth(Sampleindex.Trainindex);
%% compute the abundance for each mixed pixel-- at low resolution
SubTrainindex = CoorMap_DiffResolution(SioH,SioL, Sampleindex.Trainindex);     
[tempSubTrainIndex, ic,~] = unique(SubTrainindex,'rows','stable');    
tempTrainlabel = Trainlabel(ic);

CAbundance = ClassAbundanceCompute(HSI, tempSubTrainIndex, tempTrainlabel, HSI_Classification, EndMemberNum);
yc = reshape( CAbundance', SioL(1),SioL(2),C);
%% Adaptive MAP and Winner-Take-All Class Determination Strategy

Iterative_xc = imresize(yc,s,'bilinear');
for c = 1:C    % ��ÿ���xc���е���
    for iter = 1:5
        Ux = AverageGrad(Iterative_xc(:,:,c),'TV');   % TV model--comptute the total gradient
        [ Gx , Gy ] = gradient(Iterative_xc(:,:,c));        
        Gx = Gx./sqrt(Gx.^2+Gy.^2+(1e-10));
        Gy = Gy./sqrt(Gx.^2+Gy.^2+(1e-10));
        divUx = sum(sum(divergence(Gx,Gy)));    % compute the divergence 
        
        Dxc = zeros(SioL(1),SioL(2));           % D*x^c
        for k = 1:SioL(2)
            for j = 1:SioL(1)
                Dxc(j,k) = sum(sum(Iterative_xc((j-1)*s+1:j*s, (k-1)*s+1:k*s, c)))/(s^2);
            end
        end
        Err = sum(sum((yc(:,:,c)-Dxc).^2));     % D*x^c-y^c
        Lamda = log(0.01*Err/(Ux+(1e-10))+1);    
        deltaE = Lamda*divUx;
        Iterative_xc(:,:,c) = Iterative_xc(:,:,c)+2*imresize((Dxc-yc(:,:,c)), s, 'bilinear')/(s^2)+deltaE;  % update x^c
    end
end
[~,SubPixelMap] = max(Iterative_xc,[],3);

for c = 1:C 
    SubPixelProb(:,:,c) = Iterative_xc(:,:,c)./sum(Iterative_xc,3);
end
