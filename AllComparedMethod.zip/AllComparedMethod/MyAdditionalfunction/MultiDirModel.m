function elem=MultiDirModel(LengthL,orij)
%LengthL:   the length of L;  
%orij:      each angle(default is 6 degree);
if nargin==1
    orij=6;
end
j=0:(360/orij-1);
a=j*orij*pi/180;              %orient angle--ai
elem=zeros(LengthL+1);   %whole struct element
for j=1:(floor(45/orij)+1)
    x{j}=0:1:floor((LengthL-1)*cos(a(j))/2);
    y{j}=round(x{j}*tan(a(j)));
end
for j=(fix(45/orij)+1):(floor(90/orij)+1)
    y{j}=0:1:(LengthL-1)*sin(a(j))/2;
    x{j}=round(y{j}*cot(a(j)));
end
for j=1:(floor(90/orij)+1)
    for k=1:size(x{j},2)
        elem((LengthL/2+1)-y{j}(k),x{j}(k)+(LengthL/2+1))=1;
    end
end
elem=elem|(imrotate(elem,90))|(imrotate(elem,180))|(imrotate(elem,270));
    
    
    