function [bestt,bestr] = GetMFCtr(X,SampleTrain,LabelTrain,SampleValid,LabelValid,d,k)

t = [0.01,0.1,0.5,1,5,10,100];
r = [3,5,10,20,30];
for j = 1:length(t)
    for jj = 1:length(r)
        T = MFC(X,r(jj),t(j),d,k);
        ST = SampleTrain*T;
        SV = SampleValid*T;
        
        [bestc,bestg] = GetcgCrossvalidate(ST,LabelTrain,5);
        
        cmd = ['-c ',num2str(bestc),' -g ',num2str(bestg),' -q'];
        model = svmtrain(LabelTrain,ST,cmd);
        [~,OA,~] = svmpredict(LabelValid,SV,model);
        acc(j,jj) = OA(1);
    end
end
[j,jj] = find(acc == max(acc(:)));
bestt = t(j);
bestr = r(jj);
bestt=bestt(1);
bestr=bestr(1);