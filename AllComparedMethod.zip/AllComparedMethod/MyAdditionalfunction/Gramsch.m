function [Gs,h] = Gramsch(HSI,a1,method)
%Gram-Schmidt transform
%       [Gs,h] = Gramsch(HSI,a1)
%HSI:   multi/hyper spectral image;
%a1:    PAN image;
%GS:    transformed image;
%h:     transform matrix;
if nargin < 3
    method = 'm';
end
HSI = double(HSI);
msize = size(HSI);
A0 = reshape(HSI,msize(1)*msize(2),msize(3));
A0 = [a1(:),A0];
switch method
    case 'g'
        [Gs,h] = Gst(A0);
    case 'm'
        [Gs,h] = MGst(A0);
    otherwise
        disp('unrecognized gs method');
end
Gs = reshape(Gs,msize(1),msize(2),msize(3)+1);
%general Gram-Schmidt transform
function [v,h]  =  Gst(A)
[m,n] = size(A); 
v = zeros(m,n);
v(:,1) = A(:,1);
h = eye(n);
for j = 2:n
    sum = zeros(m,1); 
    for i = 1:(j-1)
        h(i,j) = A(:,j)'*v(:,i)/(v(:,i)'*v(:,i));
        sum  = sum+h(i,j)*v(:,i);
    end
    v(:,j) = A(:,j)-sum;
end
%modified Gram-Schmidt transform
function [Q,R] = MGst(A)
[m,n] = size(A); 
Q = zeros(m,n);
R = zeros(n);
for k = 1:n 
    R(k,k) = norm(A(:,k)); 
    Q(:,k) = A(:,k)/R(k,k); 
    for j = (k+1):n 
        R(k,j) = Q(:,k)'*A(:,j); 
        A(:,j) = A(:,j)-Q(:,k)*R(k,j); 
    end 
end 
