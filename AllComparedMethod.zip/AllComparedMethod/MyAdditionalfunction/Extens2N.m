function EXTE = Extens2N(IMG,mode)
%Extense Image to the least 2^N 
[m,n,~] = size(IMG);
N2N = 2.^(1:16);

Ind = find(m<=N2N);
WH(1) = ceil((N2N(Ind(1)) - m)/2);
WH(3) = floor((N2N(Ind(1)) - m)/2);

Ind = find(n<=N2N);
WH(2) = ceil((N2N(Ind(1)) - n)/2);
WH(4) = floor((N2N(Ind(1)) - n)/2);
EXTE = Extens(IMG,WH,mode);

