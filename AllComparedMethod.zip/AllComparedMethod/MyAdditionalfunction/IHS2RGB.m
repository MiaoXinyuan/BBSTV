function [R,G,B]=IHS2RGB(I,H,S)
[mm,nn]=size(I);
R=I;  G=I; B=I;
for m0=1:mm
    for n0=1:nn
        if(I(m0,n0)<=0.5)
            M=I(m0,n0)*(S(m0,n0)+1);
        else
            M=I(m0,n0)+S(m0,n0)-(I(m0,n0)*S(m0,n0));
        end
        m=(2*I(m0,n0))-M;
        h=H(m0,n0);
        R(m0,n0)=fff(m,M,h);
        h=H(m0,n0)-120;
        G(m0,n0)=fff(m,M,h);
        h=H(m0,n0)-240;
        B(m0,n0)=fff(m,M,h);
    end
end
end
function f0=fff(m,M,h)
if (h<0)
    h=h+360;
end
if((h>=0)&&(h<60))
    f0=m+(M-m)*h/60;
elseif ((h>=60)&&(h<180))
    f0=M;
elseif ((h>=180)&&(h<240))
    f0=m+(M-m)*(240-h)/60;
else
    f0=m;
end
end