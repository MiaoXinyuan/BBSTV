function Mhu = HuMoments(Pic)
% Mhu = HuMoments(Pic)
% computer the Hu unvariable moments

Pic =double(Pic);   Mhu = zeros(1,7);

y11 = Yitapq(Pic,1,1);
y20 = Yitapq(Pic,2,0);  y02 = Yitapq(Pic,0,2);
y30 = Yitapq(Pic,3,0);  y03 = Yitapq(Pic,0,3);
y21 = Yitapq(Pic,2,1);  y12 = Yitapq(Pic,1,2);

Mhu(1) = y20 + y02;
Mhu(2) = (y20 - y02)^2 + 4*y11^2;

Mhu(3) = (y30 - 3*y12)^2 + (3*y21 - y03)^2;
Mhu(4) = (y30 + y12)^2 + (y21 + y03)^2;

Mhu(5) = (y30 - 3*y12)*(y30 + y12)*((y30 + y12)^2 - 3*(y21 + y03)^2)+...
    (3*y21 - y03)*(y21 + y03)*(3*(y30 + y12)^2 - (y21 + y03)^2);
Mhu(6) = (y20-y02)*((y30+y12)^2-(y21+y03)^2)+4*y11*(y30+y12)*(y21+y03);

Mhu(7) = (3*y21-y03)*(y30+y12)*((y30+y12)^2-3*(y21+y03)^2)+...
    (3*y12-y30)*(y21+y03)*(3*(y30+y12)^2-(y21+y03)^2);


function yitapq = Yitapq(Pic,p,q)
gamma = (p+q)/2+1;
yitapq = CentralMoments(Pic,p,q)/(CentralMoments(Pic,0,0)^gamma);