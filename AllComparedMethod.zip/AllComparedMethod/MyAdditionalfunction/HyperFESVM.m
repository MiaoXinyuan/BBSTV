function [Prelabels,Preprobs,Confusion_Result] = HyperFESVM(Hyperdata,Groundtruth,Sampleindex,FE,options)
% [Prelabels,Preprobs] = HyperFEClassification(Hyperdata,Groundtruth,sampleindex,FE)
% Input:
%   Hyperdata:      Hyperspectral image data,arranged by numpixel * dimen;
%   Groundtruth:    Ground truth map;
%   Sampleindex:    a struct including trainindex,validindex,testindex;
%                       Sampleindex = struct{trainindex,validindex,testindex};
%   FE:             a struct including feature extraction method and reduced dimension
%                       FE=struct{Method,ReducedDim,Samples,SVMcgtable};
%                       FE.Samples=0 indicates only the test samples will be classified;
%                           else     the entire image will be classified
%   options:      parameters of feature extration
%                       if 'options' is not existed, it will use the default values,
%                       and FE.ReducedDim must be assigned
% Output:
%   Prelabels:      Predicted labels;
%   Preprobs:       Predicted probability
%   Confusion_Result:   The classification results derived from confusion matrix


if ~isfield(Sampleindex,'unlabelindex')
    Sampleindex.unlabelindex = randsample(length(Hyperdata),5000);
end

if ~isfield(FE,'SVMcgtable')
    FE.SVMcgtable.c1 = [10^2,10^3,10^4,10^5];
    FE.SVMcgtable.g1 = [ 0.1,   1,  10, 100];
end
if ~isfield(FE,'ReducedDim')
    FE.ReducedDim = 10;
end
if ~isfield(FE,'Method')
    FE.Method = 'Hyper';
end
if ~isfield(FE,'Samples')
    FE.Samples = '0';
end
Trainlabel = Groundtruth(Sampleindex.trainindex,:);
Validlabel = Groundtruth(Sampleindex.validindex,:);
Testlabel  = Groundtruth(Sampleindex.testindex,:);

if (~exist('options','var'))
    options.NeighborMode = 'KNN';               % parameters of feature extraction
    options.Regu = 1;
    options.bEigs = 1;
    options.lk = 7;
    options.ReducedDim = FE.ReducedDim;
end

Trainsample = Hyperdata(Sampleindex.trainindex,:);      %training and unlabeled samples
unlabelsample = Hyperdata(Sampleindex.unlabelindex,:);
switch FE.Method
    case 'Hyper'
        % ԭʼ������������
        Hyperdata_TRANS = Hyperdata;
    case 'LDA'
        [~, TLDA] = LDA(Trainsample,Trainlabel,max(Groundtruth)-1);
        Hyperdata_TRANS = Hyperdata * TLDA.M;
    case 'LFDA'
        [TLFDA,~] = LFDA(Trainsample,Trainlabel,options.ReducedDim,'weighted',options.lk);
        Hyperdata_TRANS = Hyperdata * TLFDA;
    case 'NPE'
        [TNPE,~,~] = NPE(options,unlabelsample);
        Hyperdata_TRANS = Hyperdata * TNPE;
    case 'SDA'
        P = [Trainsample;unlabelsample];
        LabelIdx = 1:length(Trainsample);
        UnlabelIdx = length(Trainsample)+1 : length(P);
        TSDA = SDA(Trainlabel,P,LabelIdx,UnlabelIdx,options);
        Hyperdata_TRANS = Hyperdata * TSDA;
    case 'SELF'
        P = [Trainsample;unlabelsample];
        Y = [Trainlabel;zeros(length(unlabelsample),1)];
        TSELF = SELF(P,Y,0.5,r, 'weighted',options.lk);
        Hyperdata_TRANS = Hyperdata * TSELF;
    case 'SELD'
        [~,M,~] = NPE(options,unlabelsample);
        TSELD = SELD(Trainsample,Trainlabel,unlabelsample,M,options);
        Hyperdata_TRANS = Hyperdata * TSELD;
    case 'SLDA'
        TSLDA = SLDA(Trainsample,Trainlabel,unlabelsample,options);
        Hyperdata_TRANS = Hyperdata * TSLDA;
end

% The features of samples in the low-dimensional feature space
Hyperdata_TRANS = (Hyperdata_TRANS-min(Hyperdata_TRANS(:)))/(max(Hyperdata_TRANS(:))-min(Hyperdata_TRANS(:)));
Trainsample = Hyperdata_TRANS(Sampleindex.trainindex,:);
Validsample = Hyperdata_TRANS(Sampleindex.validindex,:);
Testsample = Hyperdata_TRANS(Sampleindex.testindex,:);
% SVM training and classification
[bestc,bestg] = GetSVMcg(Trainsample,Trainlabel,Validsample,Validlabel);
model = svmtrain(Trainlabel,Trainsample,['-c ',num2str(bestc),' -g ',num2str(bestg),' -b 1 -q']);
if FE.Samples == 0
    [Prelabels,~,Preprobs] = svmpredict(Testlabel,Testsample,model,'-b 1');
    Confusion_Result = Confusmat(Testlabel,Prelabels);
else
    [Prelabels,~,Preprobs] = svmpredict(zeros(length(Hyperdata_TRANS),1),Hyperdata_TRANS,model,'-b 1');
    Confusion_Result = Confusmat(Testlabel,Prelabels(Sampleindex.testindex,:));
end

%disp([FE.Method,' OA: ',num2str(Confusion_Result.OA)]);