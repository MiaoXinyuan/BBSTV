function OutPut = CEMdetector(Img,d)
% Detection = CEMdetector(HSI,d)
% CEM detector;
% Img: original image
% d: target spectrum, a vector
[h,w,B] = size(Img);
d = double(d(:));

Img = reshape(Img,h*w,B);

R = Img'*Img/B;

wt = R^(-1)*d/(d'*R^(-1)*d);

OutPut = reshape(Img*wt,h,w);
OutPut = (OutPut-min(OutPut(:)))./(max(OutPut(:))-min(OutPut(:)));


