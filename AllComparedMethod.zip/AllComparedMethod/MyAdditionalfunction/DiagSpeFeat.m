function DiagoFeature = DiagSpeFeat(samplespef,n,mode,liminf)
% DiagoFeature = DiagSpeFeat(samplespef,n,mode,liminf)
%% Diagostical feature extraction
%   samplespef: the spectrum of a sample
%   n: the number of extracted absorption peaks, if n is larger than the total amount of the
%   absorption peaks, then return all of them
%   mode: determine whether the feature is normalized, if mode~=0, return the normalized features
%   liminf: optional parameter, ( < 1 , alleviate the neccesary condition of the absorption shoulder ),
%   DiagoFeature: a 1��n cell matrix, each cell includes a 1��5 vector, including absorption bands,
%   absorption depth, absorption width, absorption area, absorption symmetry
[~,R] = ContinuumRemove(samplespef);

R = R(:)';
if ~exist('liminf','var')
    liminf =1;
end
if ~exist('mode','var')
    mode = 0;
end

% Absorbshoulderindex: the band index of each absorption shoulder
% Absorbshoulderindex: the band index of each absorption valley

Absorbshoulderindex = find(R >= liminf);      
Absorbvalleyindex = zeros(1,length(Absorbshoulderindex)-1); 
for j = 1:length(Absorbshoulderindex)-1
    lamda1 = Absorbshoulderindex(j);
    lamda2 = Absorbshoulderindex(j+1);
    if lamda2 == lamda1 + 1
        continue;
    end
    [~,inde] = min(R(lamda1:lamda2));
    Absorbvalleyindex(j) = inde - 1 + lamda1;
end
Absorbvalleyindex = Absorbvalleyindex(Absorbvalleyindex~=0); 
AD = 1 - R(Absorbvalleyindex);              % the depth of each absorption
AWl = zeros(1,length(Absorbvalleyindex));   
AWr = zeros(1,length(Absorbvalleyindex));   
AA = zeros(1,length(Absorbvalleyindex));    % the area of each absorption 
Sym = zeros(1,length(Absorbvalleyindex));   % the symmetry of each absorption


for j = 1:length(Absorbvalleyindex)

    Shoulder(1) = max(Absorbshoulderindex(Absorbshoulderindex<Absorbvalleyindex(j)));
    Shoulder(2) = min(Absorbshoulderindex(Absorbshoulderindex>Absorbvalleyindex(j)));
    AWl(j) = Shoulder(1);
    AWr(j) = Shoulder(2);
    AA(j) = sum(1 - R(Shoulder(1):Shoulder(2)));
    leftpart = sum(1 - R(Shoulder(1):Absorbvalleyindex(j)));
    rightpart = sum(1 - R(Absorbvalleyindex(j):Shoulder(2)));
    Sym(j) = leftpart/rightpart;
end

if length(Absorbvalleyindex) <= n
    n = length(Absorbvalleyindex);
end
DiagoFeature = zeros(n,5);


[AD1,indd] = sort(AD,'descend');

if mode == 0
    for j = 1:n
        DiagoFeature(j,1) = Absorbvalleyindex(indd(j));    % Absorption index 
        DiagoFeature(j,2) = AD1(j);                        % Absorption depth
        DiagoFeature(j,3) = AWr(indd(j))-AWl(indd(j));     % Absorption width
        DiagoFeature(j,4) = AA(indd(j));                   % Absorption area
        DiagoFeature(j,5) = Sym(indd(j));                  % Absorption symmetry (left/right)
    end
else
    for j = 1:n
        DiagoFeature(j,1) = Absorbvalleyindex(indd(j))/length(R);     % Absorption index 
        DiagoFeature(j,2) = AD1(j);                                   % Absorption depth
        DiagoFeature(j,3) = (AWr(indd(j))-AWl(indd(j)))/length(R);    % Absorption width
        DiagoFeature(j,4) = AA(indd(j))/length(R);                    % Absorption area 
        DiagoFeature(j,5) = Sym(indd(j))/(Sym(indd(j))+1);            % Absorption area (left/(left+right))
    end
end