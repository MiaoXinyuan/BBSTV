function osp_results = OSPdetector(HSI, d, U)

HSI = double(HSI);
d = double(d(:));

[a,b,c] = size(HSI);
HSI = reshape(HSI,a*b,c);
if nargin<3
    [U,~,~] = pcacov(cov(HSI));
    U = U(:,1:10);
end

% Equation 3
P_U = eye(c) - U * (U'*U)^(-1)*U';

% For abundance estimation 
%w_osp = inv(target.'*P_U*target) * P_U * target;

osp_results = zeros(a*b, 1);
for k=1:a*b
    osp_results(k) = (d'*P_U*HSI(k,:)');
end
osp_results = (osp_results-min(osp_results(:)))./(max(osp_results(:))-min(osp_results(:)));
osp_results = reshape(osp_results,a,b);