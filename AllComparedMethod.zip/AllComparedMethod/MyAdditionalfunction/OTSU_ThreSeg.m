function OTSU_Threshold = OTSU_ThreSeg( ImgDiff )
%% OTSU_Threshold = OTSU_ThreSeg( ImgDiff )
%  computer the threshold of difference image by OTSU

GrayLevel = Imhistogram(ImgDiff,'nor',0);
Distance1 = zeros(size(GrayLevel));
for Th = 1:length(GrayLevel)
    p1 = sum(GrayLevel(1:Th));
    Aver1 = sum((0:Th-1).*GrayLevel(1:Th)./p1);
    Aver2 = sum((Th:length(GrayLevel)-1).*GrayLevel(Th+1:end)./(1-p1));
    Distance1(Th) = p1*(1-p1)*(Aver1-Aver2)^2;
end

[~, OTSU_Threshold] = max(Distance1);
OTSU_Threshold = OTSU_Threshold - 1;