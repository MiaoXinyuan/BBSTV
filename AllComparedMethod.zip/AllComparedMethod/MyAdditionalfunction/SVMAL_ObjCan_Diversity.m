function [RESULT_CLA,iter] = SVMAL_ObjCan_Diversity(hyperdata,panseg,Groundtruth,sampleindex,ppara)
% [RESULT_CLA,iter] = SVMAL_ObjCan(hyperdata,pandata,Groundtruth,sampleindex,ppara)
% ����ѧϰ����֧������������
%Input:
%   hyperdata:          ��������
%   panseg :            ȫɫͼ��ָ���
%   DataTruth:          ��ֵͼ
%   sampleindex:
%       {trainindex,validindex,testindex} ѵ������֤��������������
%   ppara:
%       { a,b:          ͼ���С
%         select_per:   ÿ�δӺ�ѡ�������м���ı��������
%         Maxiter:      ����������
%         AL_method:    �Ӻ�ѡ�������м����������ķ���
%         alpha:        ���Ŷ���ֵ��0��1��
%         delat :       ������������ֵ���޳������ĸ�����
%       }
%Ouput:
%   RESULT_CLA{1:iter}: struct cells
%       { ConfusionMatrix, OA, Kappa, producercc, usercc;}
%   RESULT_CLA{iter+1}: ���յķ���ͼ
%   iter:   ʵ�ʵ�������
if ~isfield(ppara,'Maxiter'),   ppara.Maxiter = 20; end
if ~isfield(ppara,'delta'),     ppara.delta = 0;    end
if ~isfield(ppara,'DiversityRule'), ppara.DiversityRule = 'Norm'; end
if ~isfield(ppara,'StopCond'),      ppara.StopCond = 0;end
if ~isfield(ppara,'Mapping'),   ppara.Mapping = 0;  end
%% ѵ���������ڶ����ڲ��������ص���������ǩ
[objectindex, objectlabel] = deal([]);
for j = 1:length(sampleindex.trainindex)
    tmp = find( all(bsxfun(@eq, panseg, panseg(sampleindex.trainindex(j),:)),2) );
    objectindex = [objectindex;tmp];
    objectlabel = [objectlabel;ones(size(tmp))*Groundtruth(sampleindex.trainindex(j))];
end

% �������ѵ������λ��һ�������ڲ������������ڵĶ����ڵ�����ֻ���Ϊһ�Ρ�
objectindex = unique([objectindex,objectlabel],'rows','stable');
objectlabel = objectindex(:,2);
objectindex = objectindex(:,1);

%% ��ʼ��
nClass = length(unique(Groundtruth(:)))-1;
RESULT_CLA = cell(1,ppara.Maxiter+1);
[hyper_Prelabels,hyper_Preprobs] = deal(zeros(ppara.a, ppara.b,1),zeros(ppara.a * ppara.b,nClass));

% ������ֹ����
[Last2Sw,Last1Sw,ThisSw] = deal(zeros(1,size(hyperdata,2)));
%��ʼ�������
markedindex = sampleindex.trainindex;
markedlabel = Groundtruth(markedindex);

%% ��������ѧϰ����
for iter = 1:ppara.Maxiter
    if ~isfield(sampleindex,'validindex')
        [bestc,bestg] = GetcgCrossvalidate(hyperdata(markedindex,:),markedlabel,ppara.Nsets);
    else
        [bestc,bestg] = GetSVMcg(hyperdata(markedindex,:),markedlabel,...
            hyperdata(sampleindex.validindex,:),Groundtruth(sampleindex.validindex));
    end
    model = svmtrain(markedlabel,hyperdata(markedindex,:),['-c ',num2str(bestc),' -g ',num2str(bestg),' -b 1 -q']);
    % ������ྫ��
    [test_prelabel,~,~] = svmpredict(Groundtruth(sampleindex.testindex),hyperdata(sampleindex.testindex,:),model,'-b 1');
    RESULT_CLA{iter} = Confusmat(Groundtruth(sampleindex.testindex),test_prelabel);
    
    % �����ڲ��������ط���
    [object_Prelabels,~,object_Preprobs] = svmpredict(objectlabel,hyperdata(objectindex,:),model,'-b 1');
    hyper_Preprobs(objectindex,:) = object_Preprobs;
    hyper_Prelabels(objectindex) = object_Prelabels;
    
    % ѡ������ǩ������ǩһ�µ�����
    candidateindex0 = objectindex(objectlabel==object_Prelabels);
    % ��ѡ���������޳��ѱ�ǵ�����,���º�ѡ����
    candidateindex0 = setdiff(candidateindex0,markedindex);
    candidatelabel0 = hyper_Prelabels(candidateindex0);
    
    %% ���ö�����׼���Ż���ѡ������
    Selclass = round(ppara.select_per/nClass);
    [newmarkindex, newmarklabel] = deal([]);
    switch ppara.DiversityRule
        case 'SAM'
            %% ���׽Ƿ�
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method );
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    nSamples = MinSAMFind(hyperdata(classcandindex,:),Selclass,hyper_Preprobs(classcandindex,iClass));
                    newmarkindex = [newmarkindex;classcandindex(nSamples)];
                    newmarklabel = [newmarklabel;iClass*ones(Selclass,1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        case 'K-SAM'
            %% �����ҽǷ�
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method );
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    nSamples = MaxDistFind(hyperdata(classcandindex,:),Selclass,hyper_Preprobs(classcandindex,iClass) );
                    newmarkindex = [newmarkindex;classcandindex(nSamples)];
                    newmarklabel = [newmarklabel;iClass*ones(Selclass,1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        case 'CLUSTER'
            %% k��ֵ���෨
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method);
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    clusterLabel = kmeans( hyperdata(classcandindex,:),Selclass);%,'Options',statset('MaxIter',500) 
                    for kCluster = 1:Selclass
                        clustercandindex = classcandindex(clusterLabel == kCluster);
                        [~,nSamples] = min(max( hyper_Preprobs(clustercandindex,:) ,[],2));
                        newmarkindex = [newmarkindex;clustercandindex(nSamples)];
                    end
                    newmarklabel = [newmarklabel;iClass*ones(length(unique(clusterLabel)),1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        case 'K-CLUSTER'
            %% ��k��ֵ���෨
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method);
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    clusterLabel = kernel_kmeans(hyperdata(classcandindex,:),Selclass,bestg);
                    for kCluster = 1:Selclass
                        clustercandindex = classcandindex(clusterLabel == kCluster);
                        [~,nSamples] = min(max( hyper_Preprobs(clustercandindex,:) ,[],2));
                        newmarkindex = [newmarkindex;clustercandindex(nSamples)];
                    end
                    newmarklabel = [newmarklabel;iClass*ones(length(unique(clusterLabel)),1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        case 'SPA'
            %% �ռ���뷨
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method );
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    [x,y] = ind2sub([ppara.a,ppara.b],classcandindex);
                    nSamples = MaxDistFind([x(:),y(:)],Selclass,hyper_Preprobs(classcandindex,iClass) ); 
                    newmarkindex = [newmarkindex;classcandindex(nSamples)];
                    newmarklabel = [newmarklabel;iClass*ones(Selclass,1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        case 'UNE'
            %% ����ط�
            [candidateindex,candidatelabel] = ALSelectfromCandidate(candidateindex0,candidatelabel0,...
                ppara.delta,hyper_Preprobs(candidateindex0,:),ppara.AL_method );
            for iClass = 1:nClass
                classcandindex = candidateindex(candidatelabel == iClass);
                if length(classcandindex) > Selclass
                    nSamples = MaxEntFind(hyperdata(classcandindex,:),Selclass,hyper_Preprobs(classcandindex,iClass));
                    newmarkindex = [newmarkindex;classcandindex(nSamples)];
                    newmarklabel = [newmarklabel;iClass*ones(Selclass,1)];
                else
                    newmarkindex = [newmarkindex;classcandindex;zeros(Selclass-length(classcandindex),1)];
                    newmarklabel = [newmarklabel;repmat(iClass,length(classcandindex),1);zeros(Selclass-length(classcandindex),1)];
                end
            end
        otherwise
%             if ppara.delta > 0
%               %% �����������ƶ��Ż���ѡ������
%                 candidatedatas0 = hyperdata(candidateindex0,:);
%                 TVlabel = Groundtruth(sampleindex.trainindex);
%                 TVsample = hyperdata(sampleindex.trainindex,:);
%                 dminSV = zeros(size(candidatelabel0));
%                 for j = 1:length(candidatelabel0)
%                     TVsamplej = TVsample(TVlabel == candidatelabel0(j),:);
%                     distan = sum(bsxfun(@minus,TVsamplej,candidatedatas0(j,:)).^2,2);
%                     dminSV(j) = min(distan);
%                 end
%                 [~,inddd]= sort(dminSV);               
%                 % �޳���ѡ��������ǰppara.delta����͹������ƶȵ�����
%                 candidateindex0 = candidateindex0(inddd(1:uint32(length(dminSV)-ppara.delta/iter)));
%             end
           %% ���ò�ȷ����ѡ��������
            [newmarkindex,newmarklabel] = ALSelectfromCandidate(candidateindex0,hyper_Prelabels(candidateindex0),...
                ppara.select_per,hyper_Preprobs(candidateindex0,:),ppara.AL_method);
    end
    newmarkindex(newmarkindex == 0) = [];
    newmarklabel(newmarklabel == 0) = [];
    % ��ֹ����:���в������������ڷ�������ı�
    if iter>2
        ThisSw = SumofSW(hyperdata(sampleindex.testindex,:),test_prelabel);
        if norm(ThisSw - Last1Sw)<=ppara.StopCond && norm(Last1Sw - Last2Sw)<=ppara.StopCond
            break;
        end
    end
    Last2Sw = Last1Sw;   Last1Sw = ThisSw;
    % �±���������뵽ѵ����������
    markedindex = [markedindex;newmarkindex];
    markedlabel = [markedlabel;newmarklabel];
end
for j = iter+1:20
    RESULT_CLA{j} = RESULT_CLA{iter};
end
if ppara.Mapping~= 0
    %������ɺ��ͼ����з���
    [hyper_Prelabels,~,~] = svmpredict(zeros(size(Groundtruth)),hyperdata,model,'-b 1');
    RESULT_CLA{iter+1}.hyper_Prelabels = hyper_Prelabels;
end

function nSamples = MinSAMFind(x,n,y)
if n >= size(x,1)
    nSamples = 1:size(x,1);
    return;
end
[~,nSamples] = min(y);
Scat(1,:) = x(nSamples,:);
for j = 2:n
    d = zeros(size(x,1),1);
    for k = 1:size(x,1)
        d(k) = sum( SpecAngleMatch(Scat,x(k,:)) );
    end
    d(nSamples) = 1;
    [~,nSamples(j)] = min(d);
    Scat(j,:) = x(nSamples(j),:);
end

function nSamples = MaxDistFind(x,n,y)
if n >= size(x,1)
    nSamples = 1:size(x,1);
    return;
end
[~,nSamples] = min(y);
Scat(1,:) = x(nSamples,:);
for j = 2:n
    d = zeros(size(x,1),1);
    for k = 1:size(x,1)
        d(k) = sum(sum((bsxfun(@minus,Scat,x(k,:))).^2));
    end
    d(nSamples) = 0;
    [~,nSamples(j)] = max(d);
    Scat(j,:) = x(nSamples(j),:);
end

function nSamples = MaxEntFind(x,n,y)
if n >= size(x,1)
    nSamples = 1:size(x,1);
    return;
end
[~,nSamples] = min(y);
Scat(1,:) = x(nSamples,:);
for j = 2:n
    H = zeros(size(x,1),1);
    for k = 1:size(x,1)
        temp = bsxfun(@times,Scat,y(k,:));
        temp = temp.*log(temp);
        H(k) = sum(-1*sum(temp,2));
    end
    H(nSamples) = 0;
    [~,nSamples(j)] = max(H);
    Scat(j,:) = x(nSamples(j),:);
end
