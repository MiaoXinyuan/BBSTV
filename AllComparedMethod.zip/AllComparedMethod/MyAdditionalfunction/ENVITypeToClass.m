function [ Class, Bytes ] = ENVITypeToClass(ENVItype)
% [ Class, Bytes ] = ENVITypeToClass(ENVItype)
% convert code of ENVI type into matlab class type
% Bytes: return the number of bytes occupied by the type

switch ENVItype
    case '1'    
        Class = 'uint8';   
        Bytes = 1;
    case '2'    
        Bytes = 2;
        Class = 'int16';
    case '12'   
        Bytes = 2;
        Class = 'uint16';
    case '3'    
        Bytes = 4;
        Class = 'int32';
    case '13'   
        Bytes = 4;
        Class = 'uint32';
    case '4'    
        Class = 'single';
        Bytes = 4;
    case '6'    
        Class = 'single';
        Bytes = 8;
    case '5'    
        Class = 'double';
        Bytes = 8;
    case '9'    
        Class = 'double';
        Bytes = 16;
    case '14'   
        Bytes = 8;
        Class = 'int64';
    case '15'   
        Bytes = 8;
        Class = 'uint64';
end
