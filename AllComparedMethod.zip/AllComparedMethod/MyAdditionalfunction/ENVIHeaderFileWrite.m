function ENVIHeaderFileWrite(ImgInfo, FileName)
%% default fields
if ~isfield(ImgInfo,'Offset')
    ImgInfo.Offset = 0;
end
if ~isfield(ImgInfo,'ByteOrder')
    ImgInfo.Byteorder = '0';
end
if ~isfield(ImgInfo,'InterLeave')
    ImgInfo.Interleave = 'bsq';
end
if ~isfield(ImgInfo,'Description')
   ImgInfo.Description = ' File Imported into ENVI.';
end
if ~isfield(ImgInfo,'Filetype')
   ImgInfo.Filetype = 'ENVI Standard';
end
if ~isfield(ImgInfo,'sersor type')
   ImgInfo.Sensortype = 'Unknown';
end

%% head file content
WriteInfo = ['ENVI',char(13,10)',...
    'description = {',char(13,10)',ImgInfo.Description,'}',char(13,10)',...
    'samples = ',num2str(ImgInfo.Imgwidth),char(13,10)',...
    'lines   = ',num2str(ImgInfo.Imgheight),char(13,10)',...
    'bands   = ',num2str(ImgInfo.Imgband),char(13,10)',...
    'header offset = ',num2str(ImgInfo.Offset),char(13,10)',...
    'file type = ',ImgInfo.Filetype,char(13,10)',...
    'data type = ',ImgInfo.Datatype,char(13,10)',...
    'interleave = ',ImgInfo.Interleave,char(13,10)',...
    'sensor type = ',ImgInfo.Sensortype,char(13,10)',...
    'byte order = ',ImgInfo.Byteorder,char(13,10)'];  

%% other fields 
% ENVI classification
if strcmp(ImgInfo.Filetype,'ENVI classification' )
    ImgInfo.Classlookup(all(bsxfun(@eq,ImgInfo.Classlookup(1,:),zeros(1,3))),:) = [];
    ImgInfo.Classlookup = [0,0,0;255*ImgInfo.Classlookup];
    ImgInfo.Classes = size(ImgInfo.Classlookup,1);
    ImgInfo.Classlookup = ImgInfo.Classlookup';
    ImgInfo.Classlookup = ImgInfo.Classlookup(:);
    ImgInfo.Classlookup = [num2str(ImgInfo.Classlookup),repmat(',',size(ImgInfo.Classlookup(:),1),1)];
    ImgInfo.Classlookup = ImgInfo.Classlookup';
    ImgInfo.Classlookup = ImgInfo.Classlookup(:)';
    ImgInfo.Classlookup(end) = '}';

    if isfield(ImgInfo,'Classnames')
        ImgInfo.Classnames{1} = 'Unclassified';
        for j = 2:ImgInfo.Classes
            ImgInfo.Classnames{j} = [',', ImgInfo.Classnames{j}];
        end
    else
        ImgInfo.Classnames{1} = 'Unclassified';
        for j = 2:ImgInfo.Classes
            ImgInfo.Classnames{j} = ['Class ',num2str(j-1),','];
        end
    end
    ImgInfo.Classnames{ImgInfo.Classes} = [ImgInfo.Classnames{ImgInfo.Classes},'}'];
    ImgInfo.Classnames = horzcat(ImgInfo.Classnames{:});
end

if isfield(ImgInfo,'Classlookup')
    WriteInfo = [WriteInfo, 'classes = ',num2str( ImgInfo.Classes ),char(13,10)',...
        'class lookup = {',char(13,10)',ImgInfo.Classlookup,char(13,10)',...
        'class names = {',char(13,10)',ImgInfo.Classnames,char(13,10)'];
end

if isfield(ImgInfo,'X_start')
    WriteInfo = [WriteInfo,'x start = ', num2str(ImgInfo.X_start),char(13,10)'];
end
if isfield(ImgInfo,'Y_start')
    WriteInfo = [WriteInfo,'y start = ', num2str(ImgInfo.Y_start),char(13,10)'];
end
if isfield(ImgInfo,'Defaultbands')
    WriteInfo = [WriteInfo,'default bands = {', num2str(ImgInfo.Defaultbands{1}),','...
        num2str(ImgInfo.Defaultbands{2}),',',num2str(ImgInfo.Defaultbands{3}),'}',char(13,10)'];
end

if isfield(ImgInfo,'Mapinfo')
    WriteInfo = [WriteInfo,'map info = {', num2str(ImgInfo.Mapinfo),'}',char(13,10)'];
end
if isfield(ImgInfo,'Coordinatesystemstring')
    WriteInfo = [WriteInfo,'coordinate system string = {', num2str(ImgInfo.Coordinatesystemstring),'}',char(13,10)'];
end
if isfield(ImgInfo,'Wavelengthunits')
    WriteInfo = [WriteInfo,'wavelength units = ', ImgInfo.Wavelengthunits,char(13,10)'];
end

% Band Names
if isfield(ImgInfo,'Bandnames')   
    for j = 1:ImgInfo.Imgband-1
        ImgInfo.Bandnames{j} = [ImgInfo.Bandnames{j},','];
    end
    ImgInfo.Bandnames{ImgInfo.Imgband} = [ImgInfo.Bandnames{ImgInfo.Imgband},'}'];
    ImgInfo.Bandnames = horzcat(ImgInfo.Bandnames{:});
    WriteInfo = [WriteInfo, 'band names = {', char(13,10)',ImgInfo.Bandnames,char(13,10)'];
end

% Wavelength
if isfield(ImgInfo,'Wavelength')
    for j = 1:ImgInfo.Imgband-1
        ImgInfo.Wavelength{j} = [ImgInfo.Wavelength{j},','];
    end
    ImgInfo.Wavelength{ImgInfo.Imgband} = [ImgInfo.Wavelength{ImgInfo.Imgband},'}'];
    ImgInfo.Wavelength = horzcat(ImgInfo.Wavelength{:});
    WriteInfo = [WriteInfo, 'wavelength = {', char(13,10)',ImgInfo.Wavelength,char(13,10)'];
end
 
%% write information into the head file
Fd = fopen(FileName,'w+');
fprintf(Fd,WriteInfo);    
fclose(Fd);