function Lssi = Localssim(X,Y,RegionSize)
% Lssi = Localssim(X,Y,RegionSize,C1,C2)
% compute the local struct similarity of image X and Y
% RegionSize: the size of local window
if nargin < 3
    RegionSize = 3;
end
C1=1e-10;
C2=1e-10;
if length(RegionSize) == 1
    RegionSize = repmat(RegionSize,1,2);
end
ElementNum = prod(RegionSize);
MiuX = imfilter(X,ones(RegionSize)/ElementNum,'circular');
MiuY = imfilter(Y,ones(RegionSize)/ElementNum,'circular');

VarX = ElementNum/(ElementNum-1)*(imfilter(X.^2,ones(RegionSize)/ElementNum,'circular') - MiuX.^2);
VarY = ElementNum/(ElementNum-1)*(imfilter(Y.^2,ones(RegionSize)/ElementNum,'circular') - MiuY.^2);

CovXY = ElementNum/(ElementNum-1)*(imfilter(X.*Y,ones(RegionSize)/ElementNum,'circular') - MiuX.*MiuY);

Lssi = (2*MiuX.*MiuY + C1).*(2*CovXY + C2)./(MiuX.^2 + MiuY.^2 + C1)./(VarX + VarY + C2);

