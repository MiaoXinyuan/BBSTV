function u_best = MultikernelUcrossvalid(TrainsampleSPE,TrainsampleSPA,trainlabel,kernelt,sigma,c,epsilon,Nsets,crossvaindd,uj)

if ~exist('Nsets','var')
    Nsets = 2;
end
if ~exist('crossvaindd','var')
    crossvaindd = crossvalind('Kfold',length(trainlabel),Nsets);
end
for j=1:Nsets
    indTest{j} = find(crossvaindd==j);
    indTrain{j}= find(crossvaindd~=j);
end
if ~exist('uj','var')
    uj = 0:0.05:1;
end
nClass = double(max(trainlabel(:)));
%ѡ��k-fold����
acc = zeros(1,length(uj));
for k = 1:length(uj)
    for j = 1:Nsets
        TrainDataA = TrainsampleSPE(indTrain{j},:);
        TrainDataB = TrainsampleSPA(indTrain{j},:);
        kerneloption_s.matrix = (1-uj(k))*svmkernel(TrainDataA,kernelt,sigma) ...
            + uj(k)*svmkernel(TrainDataB,kernelt,sigma);
        TrainLabels = trainlabel(indTrain{j});
        [~,w,b,nbsv,~,pos,~]=svmmulticlassoneagainstone([],TrainLabels,nClass,c,epsilon,'numerical',kerneloption_s,0);
        
        TestDataA = TrainsampleSPE(indTest{j},:);
        TestDataB = TrainsampleSPA(indTest{j},:);
        ASv = TrainDataA(pos,:);
        BSv = TrainDataB(pos,:);
        kerneloption_s.matrix  = (1-uj(k))*svmkernel(TestDataA,kernelt,sigma,ASv) ...
            + uj(k)*svmkernel(TestDataB,kernelt,sigma,BSv);
        TestLabels = trainlabel(indTest{j});
        [~,~,ClassRate]=svmmultivaloneagainstone([],[],w,b,nbsv,'numerical',kerneloption_s,TestLabels);
        acc(k) = acc(k) + ClassRate;
    end
    disp(acc(k));
end
[~,index] = max(acc);
u_best = uj(index);
u_best = u_best(1);

