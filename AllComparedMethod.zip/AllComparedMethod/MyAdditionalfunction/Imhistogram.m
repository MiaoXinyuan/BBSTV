function [hist1,Amin,Amax]=Imhistogram(A,method,end1,end2)
% [hist1,Amin,Amax]=Imhistogram(A,method,end1,end2)
% The histogram of image A
% A:     Single band image
% method:Class of histogram,includes 'nor','acc','noracc' and default 'hist'.
% end1, end2 : define the start and end point of pixel value
A = round(double(A(:)));    AA = minmax(A');  [Amin,Amax] = deal(AA(1),AA(2));
if nargin == 1
    method = 'hist';
    [end1, end2] = deal( Amin, Amax );
elseif nargin == 2
    [end1, end2] = deal( Amin, Amax );
elseif nargin == 3
    end2 = Amax;
end
mn = numel(A);
[end1 , end2] = deal(double(end1),double(end2));

hist0 = hist(A,end1:end2);
switch method
    case 'nor'
        %normalized histgram
        hist1=hist0/mn;
    case 'acc'
        %accumulated histgram
        hist1 = zeros(1,length(hist0));
        for k = 1:length(hist0)
            hist1(k) = sum(hist0(1:k));
        end
    case 'noracc'
        %normalized accumulated histgram
        hist1 = zeros(1,length(hist0));
        for k = 1:length(hist0)
            hist1(k) = sum(hist0(1:k));
        end
        hist1 = hist1/mn;
    otherwise
        %histgram
        hist1 = hist0;
end
        
