function Mse = MSEMoments(Pic)
% Mse = MSEMoments(Pic)
%  compute the MSE moments
Pic =double(Pic);   Mse = zeros(1,3);

u00 = CentralMoments(Pic,0,0);  u11 = CentralMoments(Pic,1,1);
u20 = CentralMoments(Pic,2,0);  u02 = CentralMoments(Pic,0,2);
u30 = CentralMoments(Pic,3,0);  u03 = CentralMoments(Pic,0,3);
u21 = CentralMoments(Pic,2,1);  u12 = CentralMoments(Pic,1,2);

Mse(1) = (u20*u02 - u11^2)/(u00^4);
Mse(2) = (-u30^2*u03^2 + 6*u30*u21*u12*u03 -...
    4*u30*u12^3 - 4*u21^3*u03 + 3*u21^2*u21^2)/(u00^10);
Mse(3) = (u20*u21*u03 - u20*u12^2 -u11*u30*u03 + ...
    u11*u21*u12 + u02*u30*u12 - u02*u21^2)/(u00^7);

    

