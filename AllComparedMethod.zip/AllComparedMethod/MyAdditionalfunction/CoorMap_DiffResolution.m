function IndexNew = CoorMap_DiffResolution(varargin)
% IndexNew = CoorMap_DiffResolution(varargin)
%% Mapping the coordinates of samples under different resolutions
% [rowNew,ColNew] = CoorMap_DiffResolution([rowA,colA],[rowB,colB],rowS,ColS)

% indNew = CoorMap_DiffResolution([rowA,colA],[rowB,colB],indS)

% varargin{1} is a two-element vector contains the first two-dimension sizes of the original matrix;
% varargin{2} is a two-element vector contains the first two-dimension sizes of the new matrix;
% varargin{3},{4} is the coordinates (double columns) or the indices (single column) of the samples 
%             in the original matrix
% IndexNew is the coordinates or the indices of the samples in the new matrix
% if varargin{3} is the coordinates, IndexNew is the coordinates(double columns);
% if varargin{3} is the indices, IndexNew is the indices(single column);

DimofS = size(varargin,2);

SizeA = varargin{1};    
SizeB = varargin{2};

[rateRow,rateCol] = deal(SizeA(1)/SizeB(1),SizeA(2)/SizeB(2));

if DimofS == 3
    [Row,Col] = ind2sub(SizeA,varargin{3});
else
    [Row,Col] = deal(varargin{3},varargin{4});
end
[rowNew,colNew] = deal(ceil(Row./rateRow),ceil(Col./rateCol));

if DimofS == 3
    IndexNew = sub2ind(SizeB,rowNew,colNew);
else
    IndexNew = [rowNew,colNew];
end


