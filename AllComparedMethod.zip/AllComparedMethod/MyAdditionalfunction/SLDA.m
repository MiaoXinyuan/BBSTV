function TSLDA = SLDA(SampleTrain,TrainLabel,ULSample,options)
% SampleTrainΪ��֪ѵ�������� nSam*nFea
% TrainLabelΪ��Ӧ����ţ�Ϊ������
% ULSampleΪδ֪����,nSam * nFea

SampleTrain=SampleTrain'; 
TrainLabel=TrainLabel';

if nargin<2
  error('Not enough input arguments.')
end
if (~exist('options','var'))
   options = [];
end
if ~isfield(options,'uk') 
    options.uk = 5;
end
if ~isfield(options,'NeighborMode')
    options.NeighborMode = 'KNN';
end
kNN = options.uk;

%% LFDA
AA = [];
nc=zeros(1,length(unique(TrainLabel)));
for c=unique(TrainLabel)
    Xc=SampleTrain(:,TrainLabel==c);
    nc(c)=size(Xc,2);
    % Define classwise affinity matriX
    Xc2=sum(Xc.^2,1);
    distance2=repmat(Xc2,nc(c),1)+repmat(Xc2',1,nc(c))-2 * (Xc'* Xc);
    [sorted,~]=sort(distance2);
    kNNdist2=sorted(kNN+1,:);
    sigma=sqrt(kNNdist2);
    localscale=sigma'*sigma;
    flag=(localscale~=0);
    A=zeros(nc(c));
    A(flag)=exp(-distance2(flag)./localscale(flag));
    AA = mdiag(AA,A);
end

n = length(TrainLabel);
Dm = zeros(n);  Dw = zeros(n);
Wm = ones(n)/n; Ww = zeros(n);
for c = unique(TrainLabel)
    index = find(TrainLabel == c);
    ma = nchoosek(index,2);
    ma = [ma;fliplr(ma)];
    for j = 1:size(ma,1)
        Wm(ma(j,1),ma(j,2)) = AA(ma(j,1),ma(j,2))/n;
        Ww(ma(j,1),ma(j,2)) = AA(ma(j,1),ma(j,2))/nc(c);
    end
end
for i = 1:n
    Dm(i,i) = sum(Wm(i,:));
    Dw(i,i) = sum(Ww(i,:));
end
Lm = Dm - Wm;
Lw = Dw - Ww;
Lb = Lm - Lw;

%% NPE
[~,M,~] = NPE(options,ULSample);

P = [SampleTrain';ULSample];
P = P - repmat(mean(P),size(P,1),1);
lb = mdiag(Lb,eye(size(ULSample,1)));
G = mdiag(Lw,M);

[TSLDA, ~, ~] = LGE(lb,G,options,P);
% eigIdx = find(eigvalue < 1e-10);
% TSLDA(:,eigIdx) = [];
