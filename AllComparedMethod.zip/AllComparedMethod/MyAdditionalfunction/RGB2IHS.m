function [I,H,S]=RGB2IHS(R,G,B)
% RGBt(:,:,1)=R;  RGBt(:,:,2)=G;  RGBt(:,:,3)=B;
% Maxi=max(RGBt,[],3);
% Mini=min(RGBt,[],3);
% Midd=Maxi-Mini;
% Midd(Midd(:,:)==0)=1;
% H=(Maxi(:,:)==R(:,:)).*((G(:,:)-B(:,:))./Midd*pi/3)...
%     +(Maxi(:,:)~=R(:,:)&Maxi(:,:)==B(:,:)).*((B(:,:)-R(:,:))./Midd*pi/3+2*pi/3)...
%     +(Maxi(:,:)~=R(:,:)&Maxi(:,:)~=B(:,:)).*((R(:,:)-G(:,:))./Midd*pi/3+4*pi/3);
% H(H(:,:)<0)=H(:,:)+2*pi;
% I=0.5*(Maxi+Mini);
% S=(I(:,:)<=0.5).*((Maxi-Mini)./(Maxi+Mini))...
%     +(I(:,:)>0.5).*((Maxi-Mini)./(2-Maxi-Mini));



I=R;    H=R;    S=R;
[mm,nn]=size(R);
for m0=1:mm
    for n0=1:nn
        rgbindex(1)=R(m0,n0);
        rgbindex(2)=G(m0,n0);
        rgbindex(3)=B(m0,n0);
        M=max(rgbindex);
        m=min(rgbindex);

        I(m0,n0)=(M+m)/2;             %I����;
        if(M==m)
            S(m0,n0)=0;
        else
            if(I(m0,n0)<=0.5)         %S����;
                S(m0,n0)=(M-m)/(M+m);
            else
                S(m0,n0)=(M-m)/(2-M-m);
            end
        end
        if(S(m0,n0)==0)
            H(m0,n0)=0;
        else
            r=(M-rgbindex(1))/(M-m);
            g=(M-rgbindex(2))/(M-m);
            b=(M-rgbindex(3))/(M-m);
            if(M==rgbindex(1))        %H����;
                H(m0,n0)=60*(2+b-g);
            elseif(M==rgbindex(2));
                H(m0,n0)=60*(4+r-b);
            else
                H(m0,n0)=60*(6+g-r);
            end
        end
    end
end




        