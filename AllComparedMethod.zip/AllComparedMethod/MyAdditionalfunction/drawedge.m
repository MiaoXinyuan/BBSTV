function drawedge(im,phi1)
h1=phi1>0;
r1=~h1;
tmp1=bwperim(h1)|bwperim(r1);
im(tmp1)=0;
r=uint8(im);
g=r;
b=g;
r(tmp1)=255;
rgb=cat(3,r,g,b);
imshow(rgb,'InitialMagnification','fit');
