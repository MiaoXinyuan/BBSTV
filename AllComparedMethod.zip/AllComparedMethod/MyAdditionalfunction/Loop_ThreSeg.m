function Loop_Threshold = Loop_ThreSeg( ImgDiff )
%% Loop_Threshold = Loop_ThreSeg( ImgDiff )
%  computer the threshold of difference image by OTSU

GrayLevel = Imhistogram(ImgDiff,'hist',0);
T_old = 0;
T_new = floor((length(GrayLevel)-1)/2);
while abs( T_new - T_old ) > 0.1
        T_old = T_new;
        sums1 = sum((0:floor(T_new)).*GrayLevel(1:floor(T_new)+1))/sum(GrayLevel(1:floor(T_new)+1));
        sums2 = sum((floor(T_new)+1:length(GrayLevel)-1).*GrayLevel(floor(T_new)+2:end))/sum(GrayLevel(floor(T_new)+2:end));
        T_new = (sums1+sums2)/2;
end
   
Loop_Threshold = T_new - 1;