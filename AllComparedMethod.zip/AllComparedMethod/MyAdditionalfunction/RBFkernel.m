function  [K,scale] = RBFkernel( Trainsamples,sigma )
%RBFkernel: produce RBF kernel matrix using Trainsamples
%   [ K ] = RBFkernel( Trainsamples,sgma )
%Input:
%   Trainsamples:   each column is a sample
%   sigma:          parameter in the RBF kernel
%Ouput:
%   K:              the kernel matrix
%   scale:          mean(dist(:));
[X,Y] = meshgrid(sum(Trainsamples.^2));
dist = X+Y-Trainsamples'*Trainsamples*2;
scale = mean(dist(:)); 
% build design matrix (kernel); AND set first line to one
K = exp(-dist/2/scale/sigma^2);
