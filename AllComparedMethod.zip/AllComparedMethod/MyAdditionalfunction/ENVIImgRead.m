function [Img,ImgInfo] = ENVIImgRead(ImgName)
% ENVIImgRead: Read ENVI image file through ENVI head file.
%   If the head file is not exist, it will be created automatically.
%   [Img,ImgInfo] = ENVIImgRead(ImgName);
if ~exist(ImgName,'file')
    error(['File ',ImgName,' does not exist.']);
end

[Path,Name,~] = fileparts(ImgName);
HeaderFileName = [fullfile(Path,Name),'.hdr'];

if ~exist(HeaderFileName,'file')   % the head file does not exist
    fileSize = getfield(dir(ImgName),'bytes');
    RealSize = 1;
    while (RealSize ~= 0) || (RealSize ~= fileSize)  
        Answer = Compositeinputdlg({'Lines:','Columns:','Bands:','Offset:','Data Type:','Inter Leave:','Byte Order:'},...
            'Image Information',1,{'1000','1000','1','0',{'uint8','int16','uint16','int32','uint32','single','double',...
            'int64','uint64','complex single','complex double'},{'bsq','bip','bil'},{'ieee-le','ieee-be'}},'on',4);
        if isempty(Answer), error(['Can not recognize file ',ImgName]); end
        ImgInfo = struct('Imgheight',str2double(Answer{1}), ...
            'Imgwidth', str2double(Answer{2}), ...
            'Imgband', str2double(Answer{3}), ...
            'Offset', str2double(Answer{4}), ...
            'Datatype', Answer{5},...
            'Interleave', Answer{6},...
            'Byteorder', Answer{7});
        if strcmp(Answer{5}, 'complex single') || strcmp(Answer{5}, 'complex double')
            [ ENVIType, Bytes ] = ClassToENVIType(ImgInfo.Datatype, 'complex');
        else
            [ ENVIType, Bytes ] = ClassToENVIType(ImgInfo.Datatype);
        end
        RealSize = ImgInfo.Imgwidth * ImgInfo.Imgheight * ImgInfo.Imgband * Bytes + ImgInfo.Offset;
        if RealSize == fileSize, break;
        else
            errordlg('The size of the file is not matched.','File error','modal');
        end
    end
    
    if ~strcmp(ImgInfo.Byteorder,'ieee-le')
        ImgInfo.Byteorder = '1';
    else
        ImgInfo.Byteorder = '0';
    end
    %% write default paramters into the head file
    Imginfo = ['ENVI',char(13,10)',...
        'description = { File Imported into ENVI.}', char(13,10)',...
        'samples = ', num2str(ImgInfo.Imgwidth),  char(13,10)',...
        'lines   = ', num2str(ImgInfo.Imgheight), char(13,10)',...
        'bands   = ', num2str(ImgInfo.Imgband),   char(13,10)',...
        'header offset = ', num2str(ImgInfo.Offset), char(13,10)',...
        'file type = ENVI Standard', char(13,10)',...
        'data type = ', ENVIType, char(13,10)',...
        'interleave = ', ImgInfo.Interleave, char(13,10)',...
        'sersor type = Unknown', char(13,10)',...
        'byte order = ', ImgInfo.Byteorder, char(13,10)'];
    
    Fd = fopen([fullfile(Path,Name),'.hdr'],'rt+');
    fprintf(Fd,Imginfo);
    2
    fclose(Fd);
else
    ImgInfo = ENVIHeaderFileRead(HeaderFileName);   
end
%% read image data file
if strcmp(ImgInfo.Byteorder,'0')
    Img = multibandread(ImgName,[ImgInfo.Imgheight, ImgInfo.Imgwidth, ImgInfo.Imgband],...
        [ImgInfo.Datatype ' => ',ImgInfo.Datatype],ImgInfo.Offset,ImgInfo.Interleave,'ieee-le');
else
    Img = multibandread(ImgName,[ImgInfo.Imgheight, ImgInfo.Imgwidth, ImgInfo.Imgband],...
        [ImgInfo.Datatype ' => ',ImgInfo.Datatype],ImgInfo.Offset,ImgInfo.Interleave,'ieee-be');
end
