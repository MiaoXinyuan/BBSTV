function [Prelabels,Confusion_Result] = HyperFECL(Hyperdata,Groundtruth,Sampleindex,FE,options)
% [Prelabels,Preprobs] = HyperFEClassification(Hyperdata,Groundtruth,sampleindex,FE)
% Input:
%   Hyperdata:      Hyperspectral image data,arranged by numpixel * dimen;
%   Groundtruth:    Ground truth map;
%   Sampleindex:    a struct including trainindex,validindex,testindex;
%                       Sampleindex = struct{trainindex,validindex,testindex,unlabelindex};
%   FE:             a struct including feature extraction method and reduced dimension
%                       FE=struct{FEMethod,CLMethod,ReducedDim,Samples,SVMcgtable,Nsets};
%                       FE.Samples=0 indicates only the test samples will be classified;
%                           else     the entire image will be classified
%   options:      parameters of feature extration
%                       if 'options' is not existed, it will use the default values,
%                       and FE.ReducedDim must be assigned
% Output:
%   Prelabels:      Predicted labels;
%   Preprobs:       Predicted probability
%   Confusion_Result:   The classification results derived from confusion matrix


if ~isfield(Sampleindex,'unlabelindex')
    Sampleindex.unlabelindex = randsample(length(Hyperdata),5000);
end

if strcmp(FE.CLMethod, 'SVM') && ~isfield(FE,'SVMcgtable')
    FE.SVMcgtable.c1 = [10^2,10^3,10^4,10^5];
    FE.SVMcgtable.g1 = [ 0.1,   1,  10, 100];
end

if ~isfield(FE,'ReducedDim')
    FE.ReducedDim = 15;
end
if (~exist('options','var'))
    options.NeighborMode = 'KNN';               % parameters of feature extraction
    options.Regu = 1;
    options.bEigs = 1;
    options.lk = 7;
    options.uk = 5;
    options.ReducedDim = FE.ReducedDim;
end

Trainlabel = Groundtruth(Sampleindex.trainindex,:);%training and unlabeled samples
Trainsample = Hyperdata(Sampleindex.trainindex,:);
unlabelsample = Hyperdata(Sampleindex.unlabelindex,:);
switch FE.FEMethod
    case 'Hyper'
        % ԭʼ������������
        Hyperdata_TRANS = Hyperdata;
    case 'LDA'
        [~, TLDA] = LDA(Trainsample,Trainlabel,max(Groundtruth)-1);
        Hyperdata_TRANS = Hyperdata * TLDA.M;
    case 'LFDA'
        [TLFDA,~] = LFDA(Trainsample,Trainlabel,options.ReducedDim,'weighted',options.lk);
        Hyperdata_TRANS = Hyperdata * TLFDA;
    case 'NPE'
        [TNPE,~,~] = NPE(options,unlabelsample);
        Hyperdata_TRANS = Hyperdata * TNPE;
    case 'SDA'
        P = [Trainsample;unlabelsample];
        LabelIdx = 1:length(Trainsample);
        UnlabelIdx = length(Trainsample)+1 : length(P);
        TSDA = SDA(Trainlabel,P,LabelIdx,UnlabelIdx,options);
        Hyperdata_TRANS = Hyperdata * TSDA;
    case 'SELF'
        P = [Trainsample;unlabelsample];
        Y = [Trainlabel;zeros(length(unlabelsample),1)];
        TSELF = SELF(P,Y,0.5,r, 'weighted',options.lk);
        Hyperdata_TRANS = Hyperdata * TSELF;
    case 'SELD'
        [~,M,~] = NPE(options,unlabelsample);
        TSELD = SELD(Trainsample,Trainlabel,unlabelsample,M,options);
        Hyperdata_TRANS = Hyperdata * TSELD;
    case 'SLDA'
        TSLDA = SLDA(Trainsample,Trainlabel,unlabelsample,options);
        Hyperdata_TRANS = Hyperdata * TSLDA;
end

% The features of samples in the low-dimensional feature space

Hyperdata_TRANS = (Hyperdata_TRANS-min(Hyperdata_TRANS(:)))/(max(Hyperdata_TRANS(:))-min(Hyperdata_TRANS(:)));
% Hyperdata_TRANS = Hyperdata_TRANS * 100 + 100;

Trainsample = Hyperdata_TRANS(Sampleindex.trainindex,:);
Testsample = Hyperdata_TRANS(Sampleindex.testindex,:);
Testlabel  = Groundtruth(Sampleindex.testindex,:);
% SVM training and classification
switch FE.CLMethod
    case 'SVM'
        if ~isfield(Sampleindex,'validindex')
            if ~isfield(FE,'Nsets')
                FE.Nsets = 2;
            end
            [bestc,bestg] = GetcgCrossvalidate(Hyperdata_TRANS(Sampleindex.trainindex,:),Trainlabel);
        else
            Validlabel = Groundtruth(Sampleindex.validindex,:);
            Validsample = Hyperdata_TRANS(Sampleindex.validindex,:);
            
            [bestc,bestg] = GetSVMcg(Trainsample,Trainlabel,Validsample,Validlabel,FE.SVMcgtable);
        end
        model = svmtrain(Trainlabel,Trainsample,['-c ',num2str(bestc),' -g ',num2str(bestg),' -b 1 -q']);
        if FE.Samples == 0
            [Prelabels,~,~] = svmpredict(Testlabel,Testsample,model,'-b 1');
            Confusion_Result = Confusmat(Testlabel,Prelabels);
        else
            [Prelabels,~,~] = svmpredict(zeros(length(Hyperdata_TRANS),1),Hyperdata_TRANS,model,'-b 1');
            Confusion_Result = Confusmat(Testlabel,Prelabels(Sampleindex.testindex,:));
        end
    case 'MLC'
        if FE.Samples == 0
            [Prelabels,~,~] = MLC(Trainsample,Trainlabel,Testsample,Testlabel);
            Confusion_Result = Confusmat(Testlabel,Prelabels);
        else
            [Prelabels,~,~] = MLC(Trainsample,Trainlabel,Hyperdata_TRANS,zeros(length(Hyperdata_TRANS),1));
            Confusion_Result = Confusmat(Testlabel,Prelabels(Sampleindex.testindex,:));
        end
    case 'KNN'
        if FE.Samples == 0
            [Prelabels] = k_nn_classifier(Trainsample',Trainlabel',1,Testsample');
            Prelabels = Prelabels';
            Confusion_Result = Confusmat(Testlabel,Prelabels);
        else
            [Prelabels] = k_nn_classifier(Trainsample',Trainlabel',1,Hyperdata_TRANS');
            Prelabels = Prelabels';
            Confusion_Result = Confusmat(Testlabel,Prelabels(Sampleindex.testindex,:));
        end
        
end
disp([FE.FEMethod,' ',FE.CLMethod,'_OA: ',num2str(Confusion_Result.OA)]);