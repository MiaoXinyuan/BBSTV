function [result,acc,G] = MLC(SamplesTrain,LabelsTrain,SamplesTest,LabelsTest)
% [result,acc,G] = MLC(SamplesTrain,LabelsTrain,SamplesTest,LabelsTest)
% The maximum likehood classifier;

% SamplesTrain: the features of training samples
% LabelsTrain: the labels of training samples
% SamplesTest: the features of testing samples
% LabelsTest: the labels of testing samples
% return the classification result and accuracy
% G: -ln|��i|-(x-mi)'*inv(��i)*(x-mi);

%SamplesTrainΪѵ��������SamplesTestΪ��������
%resultΪ������,acc Ϊ���ྫ��
num = length(SamplesTest);
nClass = length(unique(LabelsTrain));
for j = 1:nClass
    idx = find(LabelsTrain == j);
    average{j} = mean(SamplesTrain(idx,:));
    convariance{j} = cov(SamplesTrain(idx,:));
    detvalue(j) = log(det(convariance{j}));
    inverse{j} = inv(convariance{j});
end

G=zeros(num,nClass);
for j=1:nClass
    temp=bsxfun(@minus,SamplesTest,average{j});
    for k=1:num
        G(k,j)=-temp(k,:)*inverse{j}*temp(k,:)';
    end
    G(:,j)=G(:,j)-detvalue(j);
end
[~,result] = max(G,[],2);

acc = length(find((result - LabelsTest) == 0)) / num;
        