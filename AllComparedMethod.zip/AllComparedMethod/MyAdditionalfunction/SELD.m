function T = SELD(X,Y,Z,M,options)
     X=X';
     Y=Y';
     Labels = unique(Y);
     nClass = size(Labels,2);
     N = size(Z,1);
     n = size(Y,2);
     m = size(X,2);
     
     X = X - repmat(mean(X,2),1,m);
     P = [];
     for i = 1:nClass
         Xc=X(:,Y==i);
         nc=size(Xc,2);
         
         Pc = ones(nc) / nc;
         P = mdiag(P,Pc);
     end
     
     Px = mdiag(P,eye(N));
     M = mdiag(eye(n)-P,M);
     X = [X'; Z];
     
     [T, eigvalue, elapse] = LGE(Px,M , options, X);
     eigIdx = find(eigvalue < 1e-10);
     eigvalue (eigIdx) = [];
     T(:,eigIdx) = [];
    