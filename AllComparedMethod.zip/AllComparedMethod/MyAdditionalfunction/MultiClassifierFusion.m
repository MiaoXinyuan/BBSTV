function Fusedmap=MultiClassifierFusion(Classifiers,methods,weightparam)
% Multiple classifiers decision fusion
% 	Fusedmap = MultiClassifierFusion(Classifiers,methods,weightparam)
%
% Input:
%   Classifers: A cell including several classified results, the form of classifier is shown below.
%       each line denotes the class membership of a pixel, each column corresponds to a single class
%   methods:    Algorithm of decision fusion
%   weightparam:weight parameters for each classifier(maybe the overall
%               accuracy or the producer accuracy
%               each row represents a classifier;
%               each column represents a class;
%           class   1  2  3 ...
%                  -----------
%  Classifiers{1} |  |  |  |  |
%                  -----------
%  Classifiers{2} |  |  |  |  |
%                  -----------
%    ......       |  ...  ... |
% Output:
%   Fusedmap:   A fused classification map;

%       Classifiers
%   {1}    {2}    {3} ... 
%   ---    ---    ---         ---
%  |   |  |   |  |   |       /  /|
%  |   |  |   |  |   |...    --- |
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   ||
%  |   |  |   |  |   |...   |   |/
%   ---    ---    ---        ---
nclassifiers= length(Classifiers);
[imgpixel,nclass]=size(Classifiers{1});
%varieties methods of fusion
switch methods
    
    case 'max'
        [~,Fusedmap(:,1)]=max(horzcat(Classifiers{:}),[],2);
        Fusedmap=mod(Fusedmap,nclass);
        Fusedmap(Fusedmap==0)=nclass;   % class=0 is equal to class=nclass;
        
    case 'Bornoli'
        Classifiers{1} = 1 - bsxfun(@times,Classifiers{1},weightparam(1,:));
        for j=2:nclassifiers
            Classifiers{j} = 1- bsxfun(@times,Classifiers{j},weightparam(j,:));
            Classifiers{1} = Classifiers{1}.*Classifiers{j};
        end
        [~,Fusedmap(:,1)]=max(1-Classifiers{1},[],2);
        
    case 'LOP'
        Classifiers{1} = bsxfun(@times,Classifiers{1},weightparam(1,:));
        for j=2:nclassifiers
            Classifiers{j} = bsxfun(@times,Classifiers{j},weightparam(j,:));
            Classifiers{1} = Classifiers{1}+Classifiers{j};
        end
        [~,Fusedmap(:,1)]=max(Classifiers{1},[],2);
        
    case 'IOP'
        Classifiers{1} = bsxfun(@power,Classifiers{1},weightparam(1,:));
        for j=2:nclassifiers
            Classifiers{j} = bsxfun(@power,Classifiers{j},weightparam(j,:));
            Classifiers{1}=Classifiers{1}+Classifiers{j};
        end
        [~,Fusedmap(:,1)]=max(Classifiers{1},[],2);
        
    case 'LGP'
        Classifiers{1} = bsxfun(@power,Classifiers{1},weightparam(1,:));
        for j=2:nclassifiers
            Classifiers{j} = bsxfun(@power,Classifiers{j},weightparam(j,:));
            Classifiers{1}=Classifiers{1}.*Classifiers{j};
        end
        [~,Fusedmap(:,1)]=max(Classifiers{1},[],2);
        
    case 'D-S'
        if nclassifiers==2
            Classifiers{1} = [Classifiers{1}*weightparam(1),repmat(1-weightparam(1),imgpixel,1)];
            Classifiers{2} = [Classifiers{2}*weightparam(2),repmat(1-weightparam(2),imgpixel,1)];
            R = sum(Classifiers{1}.*Classifiers{2},2);
            for j = 1:nclass
                R = R+Classifiers{1}(:,j).*Classifiers{2}(:,nclass+1)...
                    + Classifiers{2}(:,j).*Classifiers{1}(:,nclass+1);
            end
            Classifiers{1} = Classifiers{1}(:,1:nclass).*Classifiers{2}(:,1:nclass)...
                + bsxfun(@times,Classifiers{1}(:,1:nclass),Classifiers{2}(:,nclass+1))...
                + bsxfun(@times,Classifiers{2}(:,1:nclass),Classifiers{1}(:,nclass+1));
            Classifiers{1} = bsxfun(@rdivide,Classifiers{1},R);
        elseif nclassifiers==3
            dsclass = zeros(3,nclass+1);
            for j=1:imgpixel
                for k=1:nclassifiers
                    dsclass(k,:) = [Classifiers{k}(j,:)*weightparam(k),1-weightparam(k)];
                end
                R = sum(dsclass(1,:).*dsclass(2,:).*dsclass(3,:))...
                    + sum(dsclass(1,1:nclass).*dsclass(2,1:nclass)*dsclass(3,nclass+1)...
                    + dsclass(2,1:nclass).*dsclass(3,1:nclass)*dsclass(1,nclass+1)...
                    + dsclass(3,1:nclass).*dsclass(1,1:nclass)*dsclass(2,nclass+1)...
                    + dsclass(1,1:nclass)*dsclass(2,nclass+1)*dsclass(3,nclass+1)...
                    + dsclass(2,1:nclass)*dsclass(3,nclass+1)*dsclass(1,nclass+1)...
                    + dsclass(3,1:nclass)*dsclass(1,nclass+1)*dsclass(2,nclass+1));
                Classifiers{1}(j,:)=(dsclass(1,1:nclass).*dsclass(2,1:nclass).*dsclass(3,1:nclass)...
                    + dsclass(1,1:nclass).*dsclass(2,1:nclass)*dsclass(3,nclass+1)...
                    + dsclass(2,1:nclass).*dsclass(3,1:nclass)*dsclass(1,nclass+1)...
                    + dsclass(3,1:nclass).*dsclass(1,1:nclass)*dsclass(2,nclass+1)...
                    + dsclass(1,1:nclass)*dsclass(2,nclass+1)*dsclass(3,nclass+1)...
                    + dsclass(2,1:nclass)*dsclass(3,nclass+1)*dsclass(1,nclass+1)...
                    + dsclass(3,1:nclass)*dsclass(1,nclass+1)*dsclass(2,nclass+1))/R;
            end
        end
        [~,Fusedmap(:,1)]=max(Classifiers{1},[],2);
        
    case 'fuzzy'
%         g = zeros(nclassifiers,nclass);
        gA= zeros(nclassifiers,nclass);
        lamda=zeros(1,nclass);
        %calculating the fuzzy indensity function
        weightparam = bsxfun(@times,weightparam,sum(weightparam));
        g = weightparam*0.75;
        
        if nclassifiers==2
            %calculating the fuzzy measure
            gA(1,:) = g(2,:);
            gA(2,:) = 1;
            %calculating the fuzzy intergral
            ccl(:,:,1) = Classifiers{1};  ccl(:,:,2) = Classifiers{2};
            ccl = sort(ccl,3,'descend');
            Classifiers{1} = bsxfun(@times,ccl(:,:,1)-ccl(:,:,2),gA(1,:))...
                + bsxfun(@times,ccl(:,:,2),gA(2,:));
        elseif nclassifiers==3
            for j=1:nclass
                funcc=roots([g(1,j)*g(2,j)*g(3,j),g(1,j)*g(2,j)+g(1,j)*g(3,j)...
                    +g(2,j)*g(3,j),g(1,j)+g(2,j)+g(3,j)-1,0]);
                lamda(j)=funcc(nclassifiers+1);
            end
            %calculating the fuzzy measure
            qq=g(2,:);g(2,:)=g(1,:);g(1,:)=qq;
            gA(1,:)=g(1,:);
            gA(2,:)=g(2,:)+gA(1,:)+lamda(3)*g(2,:).*gA(1,:);
            gA(3,:)=g(3,:)+gA(2,:)+lamda(3)*g(3,:).*gA(2,:);
            %calculating the fuzzy intergral
            ccl(:,:,1)=Classifiers{1};  ccl(:,:,2)=Classifiers{2};  ccl(:,:,3)=Classifiers{3};
            ccl=sort(ccl,3,'descend');
            Classifiers{1} = bsxfun(@times,ccl(:,:,1)-ccl(:,:,2),gA(1,:))...
                + bsxfun(@times,ccl(:,:,2)-ccl(:,:,3),gA(2,:))...
                + bsxfun(@times,ccl(:,:,3),gA(3,:));
        end
        [~,Fusedmap(:,1)]=max(Classifiers{1},[],2);
end
Fusedmap=uint8(Fusedmap);

