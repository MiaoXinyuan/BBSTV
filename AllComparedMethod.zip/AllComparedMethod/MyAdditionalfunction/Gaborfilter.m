function [G,gabout] = Gaborfilter(I,v,u,umax)
% [G,gabout] = Gaborfilter(I,v,u,umax)
% use Gabor filter to extract texture features
% v: the direction number, a vector
% u: the scale number, a vector
I = double(I);
theta=sqrt(2)*pi;
kv=pi/(2^(v+1));
faiu=u*pi/umax;
k=[kv*cos(faiu);kv*sin(faiu)];
G=zeros(33);
for x=-16:16
    for y=-16:16
        G(x+17,y+17)=kv.^2/(theta.^2)*exp(-kv.^2/(theta.^2)/2*(x.^2+y.^2))*(exp(1i*dot(k,[x;y]))-exp(-theta^2/2));
    end;
end;
Imgabout = conv2(I,double(imag(G)),'same');
Regabout = conv2(I,double(real(G)),'same');

gabout = sqrt(Imgabout.*Imgabout + Regabout.*Regabout);
