function [Mupq,centx,centy] = CentralMoments(F,p,q)
% [Mupq,centx,centy] = CentralMoments(F,p,q)
% Computer the p+q central moments
% example:
%   F = imread('a.bmp');
%   [Mupq,centx,centy] = CentralMoments(F,1,1)
%   Mupq = 0;
F =double(F);
[M,N]= size(F);
centx = PQMoments(F,1,0)/PQMoments(F,0,0);
centy = PQMoments(F,0,1)/PQMoments(F,0,0);


[X,Y] = meshgrid(1:N, 1:M);
Mupq = F .* (X-centx).^p.* (Y-centy).^q;
Mupq = sum(Mupq(:));

