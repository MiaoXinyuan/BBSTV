function Dis = Euclidean(A,B)
% compute the Euclidean Distance between each vector of A and B
% A,B are matrices of row vectors, A and B have same column numbers
% return: Dis -- Dis(j,k) is the distance between vectors A(j,:) and B(k,:);
A = double(A);  B = double(B);
[Aa,Ab] = size(A);
[Ba,Bb] = size(B);
Dis = zeros(Aa,Ba);
if Ab ~= Bb
    disp('Error: A and B must have same column numbers');
else
    for k = 1:Ba
        Dis(:,k) = sqrt(sum(bsxfun(@minus,A,B(k,:)).^2,2));
    end
end
