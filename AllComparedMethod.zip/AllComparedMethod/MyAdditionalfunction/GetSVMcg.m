function [bestc,bestg] = GetSVMcg(SampleTrain,TrainLabel,SampleValid,ValidLabel,cgtable,t)


% cgtable.c1 = [10^2,10^3,10^4,10^5];
% cgtable.g1 = [ 0.1,   1,  10, 100];

if ~exist('t','var')
    cmd0 = [];
else
    cmd0 = ['-t ',num2str(t)];
end
acc=zeros(length(cgtable.c1),length(cgtable.g1));
for j = 1:length(cgtable.c1)
    for k = 1:length(cgtable.g1)
        cmd = [cmd0,' -c ',num2str(cgtable.c1(j)),' -g ',num2str(cgtable.g1(k)),' -q'];
        model = svmtrain(TrainLabel,SampleTrain,cmd);
        [~,accu,~] = svmpredict(ValidLabel,SampleValid,model);
        acc(j,k)=accu(1);
    end
end
[j,k]=find(acc==max(acc(:)));
bestc=cgtable.c1(j);
bestg=cgtable.g1(k);
bestc=bestc(1);
bestg=bestg(1);
