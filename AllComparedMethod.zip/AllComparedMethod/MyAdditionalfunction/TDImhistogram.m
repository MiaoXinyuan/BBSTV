function His = TDImhistogram(A)
% His = TDImhistogram(A)
% two dimensional histogram
A = round(double(A));
ma = max(A(:));
[m,n] = size(A);
   
h = ones(3)/8;    h(2,2) = 0;
C = filter2(h,Extens(A,1,'per'));
C = round(C(2:m+1,2:n+1));  % store the neighbor average of A
His = zeros(ma+1);
for j = 1:m
    for k = 1:n
        His(A(j,k)+1,C(j,k)+1) = His(A(j,k)+1,C(j,k)+1)+1;
    end
end





