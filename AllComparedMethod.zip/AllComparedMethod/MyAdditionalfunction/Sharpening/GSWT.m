function FUS=GSWT(MSI,PAN,wavelettype,fsrules)
%GS-WTContourlet-based Fusion:
%           FUS=GSWT(MSI,PAN,wavelettype,fsrules)
%MSI:       Multiband image;
%PAN:       High resolution image;
%wavelettype: {wavetype,wavename,wavenum,dirtype,dirfilter,dirnum};
    %wavetype: 'dwt'or 'swt'
    %wavename:  Wavelet name used by DWT or SWT;
    %wavenum:   Level of wavelet decomposition
    %dirtype:   'ct' or 'nsct'
    %dirfilter: Direction filter used by contourlet(see dfilters in contourlet_toolbox);
    %dirnum:    Direction numbers;
%fsrules:   {lowsel1,lowsel2,highsel1,highsel2};
    %lowsel1:   The major approximate coefficient selecting method;default is 'ssim';
    %lowsel2:   The minor approximate coefficient selecting method;default is 'select';
    %highsel1:  The major detail coefficient selecting method;default is 'abs';
    %highsel2:  The minor detail coefficient selecting method;default is 'select';
%Return :   Multiband high resolution image;
MSI = double(MSI);    PAN = double(PAN(:,:,1));
[msize,psize] = deal(size(MSI),size(PAN));
if ~exist('wavelettype','var')
    wavelettype = struct('wavetype','swt','wavename','db4',...
        'wavenum',4,'dirtype','ct','dirfilter','pkva','dirnum',0);
end
if ~exist('fsrules','var')
    fsrules = struct('lowsel1','low','lowsel2', 'select',...
        'highsel1','high','highsel2','select');
end

if ~isfield(wavelettype,'wavetype')
    wavelettype.wavetype = 'swt';
end
if ~isfield(wavelettype,'wavename')
    wavelettype.wavename = 'db4';
end
if ~isfield(wavelettype,'wavenum')
    wavelettype.wavenum = 4;
end
if ~isfield(wavelettype,'dirtype')
    wavelettype.dirtype = 'ct';
end
if ~isfield(wavelettype,'dirfilter')
    wavelettype.dirfilter = 'pkva';
end
if ~isfield(wavelettype,'dirnum')
    wavelettype.dirnum = 0;
end

if ~isfield(fsrules,'lowsel1')
    fsrules.lowsel1 = 'low';
end
if ~isfield(fsrules,'lowsel2')
    fsrules.lowsel2 = 'select';
end
if ~isfield(fsrules,'highsel1')
    fsrules.highsel1 = 'abs';
end
if ~isfield(fsrules,'highsel2')
    fsrules.highsel2 = 'select';
end

Fmsi = zeros(psize(1),psize(2),msize(3));
for k = 1:msize(3)
    Fmsi(:,:,k) = imresize(MSI(:,:,k),[psize(1),psize(2)],'bilinear');
end
%low-resolution panchromatic image simulation
a1 = mean(Fmsi,3);
% pan1 = imresize(filter2(ones(7)/49,PAN),[msize(1) msize(2)],'bilinear');
% a1 = imresize(pan1,[psize(1) psize(2)],'bilinear');
pan1 = double(Histogrammatch(PAN,a1,'sml'));
%GS transform
[GSt,h] = Gramsch(Fmsi,a1);
disp('GS transform finish');
pan1 = pan1/h(1,1);   %normalized 
%SWCT transform
if wavelettype.wavenum > 0
    GSt(:,:,1) = WCT(GSt(:,:,1),pan1,wavelettype,fsrules);
else
    GSt(:,:,1) = pan1;
end
%Inverse GS transform
fus = reshape((reshape(GSt,psize(1)*psize(2),msize(3)+1))*h,psize(1),psize(2),msize(3)+1);
disp('Inverse GS transform finish');
FUS = fus(:,:,2:(msize(3)+1));

FUS = SetMinMaxofImg(FUS, minmax((reshape(MSI,msize(1)*msize(2),msize(3)))'));
