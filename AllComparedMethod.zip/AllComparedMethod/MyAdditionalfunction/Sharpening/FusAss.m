function Evall=FusAss(FusImg,Fmsi0,Fpan,Fref,h,l,N)
% Assess Fused image
%       Evall=FusAss(FusImg,Fmsi0,Fpan,Fref,h,l,N)
%       Evall=FusAss(FusImg,Fpan,Fmsi)  --  if no reference image;
% FusImg:fused image
% Fmsi0��original multispectral image��resized into the same size as fused image)
% Fpan:  original panchromatic image
% Fref:  ideal reference image
% h:     high resolution PAN image resolution
% l:     low resolution MS image resolution
% N:     block size for Q4 computation
% return:    Evall 
%    each row represents a single band
%      1              2            3       4          5               6           7          
%   average    standarderror    entropy    AG    crossentropy    unitedentropy    CC  
%           8                  9            10     11      12      13      14    15
%   deviationdegree    averagedeviation    RMSE    SNR    PSNR    ERGAS    SAM   Q4
[FusImg,Fmsi0,Fpan] = deal(double(FusImg),double(Fmsi0),double(Fpan));
if (nargin >= 4)
    Fref = double(Fref);
end
[mm,nn,bb] = size(FusImg);  msize = mm*nn;
Evall = zeros(bb+1,15);

% assessment with single image;
for k = 1:bb              
    %mean
    Evall(k,1) = mean2(FusImg(:,:,k));
    %standard error
    Evall(k,2) = std2(FusImg(:,:,k));
    %entropy
    [hist1,~, graymax(1)] = Imhistogram(FusImg(:,:,k),'nor');    
    temp = hist1((hist1 ~= 0));
    Evall(k,3) = 0 - sum(temp.*log2(temp));    
    %average gradient
    [Fx,Fy] = gradient(FusImg(:,:,k));
    Evall(k,4) = sum(sum(sqrt(Fx.^2 + Fy.^2)))/msize;
    
    if nargin <= 3
        Fmsi = imresize(Fmsi0(:,:,k),[mm,nn],'bilinear');
        %assessment comparing with original multispectral image
        %cross entropy
        histm = Imhistogram(Fmsi,'nor');
        temp = intersect(find(hist1 ~= 0),find(histm ~= 0));
        Evall(k,5) = 0 - sum(histm(temp).*log2(histm(temp)./hist1(temp)));
        %united entropy
        histp = Imhistogram(Fpan,'nor');
        temp = intersect(find(hist1 ~= 0),find(histm ~= 0));
        temp = intersect(temp,find(histp ~= 0));
        Evall(k,6) = 0 - sum(hist1(temp).*histm(temp).*histp(temp).*log(hist1(temp).*histm(temp).*histp(temp)));        
        %correlation coefficient
        Evall(k,7) = corr2(FusImg(:,:,k),Fmsi);
        %deviation degree
        Fmsi = Fmsi+(Fmsi==0);
        Fx = (abs(FusImg(:,:,k)-Fmsi))./Fmsi;
        Evall(k,8) = sum(Fx(:))/msize;
    else
        %assessment with ideal reference image
        %average deviation 
        Evall(k,9) = sum(sum(abs(FusImg(:,:,k)-Fref(:,:,k))))/msize;
        %RMSE                 
        rmse = sum(sum((FusImg(:,:,k)-Fref(:,:,k)).^2));
        Evall(k,10) = sqrt(rmse/msize);
        %SNR
        Evall(k,11) = 10*log10(sum(sum(FusImg(:,:,k).^2))/rmse);
        %PSNR
        Evall(k,12) = 20*log10(double(graymax(1))/Evall(k,10));    
    end
    disp(['Band ',num2str(k),' finish ...']);
end
%mean of all bands
Evall(bb+1,:) = mean(Evall(1:bb,:));
if nargin == 6
    %ERGAS   
    ergas = (Evall(:,10)./Evall(:,1)).^2;
    Evall(bb+1,13) = 100*h/l*sqrt(sum(ergas(1:end))/bb);
    % SAM
    temp = sum(reshape(FusImg,msize,bb).*reshape(Fref,msize,bb),2);
    tempa = sqrt(sum(reshape(FusImg,msize,bb).^2,2));
    tempb = sqrt(sum(reshape(Fref,msize,bb).^2,2));
    temp = temp./(tempa.*tempb);    temp(tempa == 0|tempb == 0) = 0;    temp(temp>1) = 1;
    Evall(bb+1,14) = mean(acosd(temp));    
    
elseif nargin == 7   
    %Q4
    Q4 = 0;
    [ez1, ez2, ez1z2] = deal(zeros(N));
    for blo1 = 1:mm/N
        for blo2 = 1:nn/N
            FusImg1 = FusImg(((blo1-1)*N+1):(blo1*N),((blo2-1)*N+1):(blo2*N),:);
            Fref1 = Fref(((blo1-1)*N+1):(blo1*N),((blo2-1)*N+1):(blo2*N),:);
            for k = 1:bb            
                [z1(k,1), z2(k,1)] = deal(mean2(FusImg1(:,:,k)),mean2(Fref1(:,:,k)));
            end
            [zn1, zn2] = deal(norm(z1),norm(z2)); %compute |z1|,|z2|
            for x = 1:N
                for y = 1:N
                    [aaa(:),bbb(:)] = deal(FusImg1(x,y,:),Fref1(x,y,:));
                    [ez1(x,y),ez2(x,y)] = deal(norm(aaa).^2, norm(bbb).^2);
                    ez1z2(x,y) = aaa'*bbb;
                end
            end
            sigmaz1 = mean2(ez1)-zn1.^2;  sigmaz2 = mean2(ez2)-zn2.^2;
            sigmaz1z2 = mean2(ez1z2)-sum(z1.*z2);            %compute sigmaz1,sigmaz2,sigmaz1z2
            Q4 = Q4 + 4*sigmaz1z2*zn1*zn2/((sigmaz1+sigmaz2)*(zn1.^2+zn2.^2));
        end
    end
    Evall(bb+1,15) = Q4/(blo1*blo2);
end
           
