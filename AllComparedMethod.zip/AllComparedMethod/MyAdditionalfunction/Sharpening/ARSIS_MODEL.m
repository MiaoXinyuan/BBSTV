function [ Alpha, Beita ] = ARSIS_MODEL(MsiLow, PanLow, Model)
%% ARSIS_MODEL for each detailed plane
% [ Alpha, Beita ] = ARSIS_MODEL(MsiLow, PanLow, Model)
%  'Model': can be 'M1','M2','RWM'
%  if Model == 'RWM',  Alpha, Beita are matrics,
%    otherwise  Alpha, Beita are scalars

switch Model
    case 'M1'
        [ Alpha, Beita ] = deal(1,0);
        
    case 'M2'
        Alpha = std2(MsiLow)/std2(PanLow);
        Beita = mean2(MsiLow) - Alpha * mean2(PanLow);
        
    case 'CBD'
        StdMlocal = sqrt(49/48*(imfilter(MsiLow.^2,ones(7)/49)-imfilter(MsiLow,ones(7)/49).^2));
        StdPlocal = sqrt(49/48*(imfilter(PanLow.^2,ones(7)/49)-imfilter(PanLow,ones(7)/49).^2));
        CovMPlocal = 49/48*(imfilter(MsiLow.*PanLow,ones(7)/49)-imfilter(MsiLow,ones(7)/49).*imfilter(PanLow,ones(7)/49));
        RouMPlocal = CovMPlocal./(StdMlocal.*StdPlocal);
        Rouglobal = corrcoef(MsiLow(:),PanLow(:)); Rouglobal = Rouglobal(1,2);
        Alpha = (RouMPlocal >= (1-Rouglobal)).*min(StdMlocal./StdPlocal,2.5) + ...
            (RouMPlocal < (1-Rouglobal)) .* 0;
        Beita = 0;
    case 'RWM'
        [Theta1, Theta2 ] = deal(0.7,0.01);
        [emsil1, emsil2 ] = deal(10^(-5),10^(-2));
        [MiuF, MiuP] = deal(imfilter(MsiLow,ones(9)/81), imfilter(PanLow,ones(9)/81));
        SigmaF = sqrt(81/80*(imfilter(MsiLow.^2,ones(9)/81) - imfilter(MsiLow,ones(9)/81).^2));
        SigmaP = sqrt(81/80*(imfilter(PanLow.^2,ones(9)/81) - imfilter(PanLow,ones(9)/81).^2));
        CovarFP = 81/80*(imfilter(MsiLow.*PanLow,ones(9)/81) - MiuF.*MiuP);
        %% reshape each matrix to a vector
        RouFP = CovarFP./(SigmaF.*SigmaP);
        SignW1W2 = sign( MsiLow .* PanLow );
        Alpha0 = SignW1W2 .* SigmaF ./ SigmaP;
        
        Alpha = (abs(RouFP) < Theta2).*(SigmaP < emsil1).*Alpha0 +...    % case 1
            ((abs(RouFP) >= Theta2)&(abs(RouFP) <= Theta1)).* ((CovarFP < emsil2).*Alpha0 +...
            (CovarFP >= emsil2).*(Alpha0 + (((SigmaF.^2-SigmaP.^2)+sqrt((SigmaF.^2-SigmaP.^2).^2+...
            4*CovarFP.^2))./(2*CovarFP)-Alpha0).*(abs(RouFP)-Theta2)./(Theta1-Theta2)))+...    % case 2
            (abs(RouFP) > Theta1).*((CovarFP < emsil2).*Alpha0 + (CovarFP >= emsil2).*...
            ((((SigmaF.^2-SigmaP.^2)+sqrt((SigmaF.^2-SigmaP.^2).^2+4*CovarFP.^2))./(2*CovarFP))));  % case 3
        
        Alpha = reshape(Alpha,size(PanLow));
        Beita = reshape(MiuF - Alpha .* MiuP, size(PanLow));
        Alpha(isnan(Alpha)) = 0;
        Beita(isnan(Beita)) = 0;
    case 'M3'   % proposed
        for k = 1:size(MsiLow,3)
            StdF(k) = std2( MsiLow(:,:,k));
            MeaF(k) = mean2(MsiLow(:,:,k));
            StdP(k) = std2( PanLow(:,:,k));
            MeaP(k) = mean2(PanLow(:,:,k));
        end
        Alpha = prod(StdF)/prod(StdP);
        Beita = 0;
    case 'M4'
        psize = size(PanLow);           
        Blocksize = psize(1);  
        [ Alpha, Beita ] = deal(ones(psize(1),psize(2)),zeros(psize(1),psize(2)));
        for k = 1 : psize(1)/Blocksize
            for l = 1:psize(2)/Blocksize
                P = PanLow( (k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize, :);
                F = MsiLow( (k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize, :);  
                for Level = 1:psize(3)
                    StdP(Level) = std2(P(:,:,Level));
                    StdF(Level) = std2(F(:,:,Level));
                end            
                Alpha((k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize) = ones(Blocksize).*sum(StdF)./sum(StdP);
                Beita((k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize) = mean2(sum(F,3)) -...
                    Alpha((k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize) .* mean2(sum(P,3));         
            end
        end 
    case 'M5'
        psize = size(PanLow);  
        if length(psize) <= 3 
            psize(3) = 1;
        end
        Blocksize = psize(1);  
        [ Alpha, Beita ] = deal(ones(psize(1),psize(2)),zeros(psize(1),psize(2)));
        for k = 1 : psize(1)/Blocksize
            for l = 1:psize(2)/Blocksize
                P = PanLow( (k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize, :);
                F = MsiLow( (k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize, :);  
                for Level = 1:psize(3)
                    StdP(Level) = std2(P(:,:,Level));
                    StdF(Level) = std2(F(:,:,Level));
                    MeanP(Level) = mean2(P(:,:,Level));
                    MeanF(Level) = mean2(F(:,:,Level));
                end            
                temp = sum(StdF.*StdP)./sum(StdP.^2);
                Alpha((k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize) = ones(Blocksize).*temp;
                Beita((k-1)*Blocksize+1:k*Blocksize, (l-1)*Blocksize+1:l*Blocksize) = ((mean(MeanF) - ...
                    temp .* mean(MeanP))./psize(3)).*ones(Blocksize);     
            end
        end          
end