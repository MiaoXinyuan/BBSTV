function FUS=PCWT(MSI,PAN,wavelettype,fsrules)
%PCA-WTContourlet-based Fusion:
%           FUS=PCAWT(MSI,PAN,wavelettype,fsrules)
%MSI:       Multiband image;
%PAN:       High resolution image;
%wavelettype: {wavetype,wavename,wavenum,dirtype,dirfilter,dirnum};
    %wavetype: 'dwt'or 'swt'
    %wavename:  Wavelet name used by DWT or SWT;
    %wavenum:   Level of wavelet decomposition
    %dirtype:   'ct' or 'nsct'
    %dirfilter: Direction filter used by contourlet(see dfilters in contourlet_toolbox);
    %dirnum:    Direction numbers;
%fsrules:   {lowsel1,lowsel2,highsel1,highsel2};
    %lowsel1:   The major approximate coefficient selecting method;default is 'ssim';
    %lowsel2:   The minor approximate coefficient selecting method;default is 'select';
    %highsel1:  The major detail coefficient selecting method;default is 'abs';
    %highsel2:  The minor detail coefficient selecting method;default is 'select';
%Return :   Multiband high resolution image;
MSI = double(MSI);    PAN = double(PAN(:,:,1));
[msize,psize] = deal(size(MSI),size(PAN));
if (~exist('wavelettype','var'))
    wavelettype = struct('wavetype','swt','wavename','db4',...
        'wavenum',4,'dirtype','ct','dirfilter','pkva','dirnum',0);
end
if (~exist('fsrules','var'))
    fsrules = struct('lowsel1','low','lowsel2', 'select',...
        'highsel1','abs','highsel2','select');
end

if ~isfield(wavelettype,'wavetype')
    wavelettype.wavetype = 'swt';
end
if ~isfield(wavelettype,'wavename')
    wavelettype.wavename = 'db4';
end
if ~isfield(wavelettype,'wavenum')
    wavelettype.wavenum = 4;
end
if ~isfield(wavelettype,'dirtype')
    wavelettype.dirtype = 'ct';
end
if ~isfield(wavelettype,'dirfilter')
    wavelettype.dirfilter = 'pkva';
end
if ~isfield(wavelettype,'dirnum')
    wavelettype.dirnum = 0;
end

if ~isfield(fsrules,'lowsel1')
    wavelettype.lowsel1 = 'low';
end
if ~isfield(fsrules,'lowsel2')
    fsrules.lowsel2 = 'select';
end
if ~isfield(fsrules,'highsel1')
    fsrules.highsel1 = 'abs';
end
if ~isfield(fsrules,'highsel2')
    fsrules.highsel2 = 'select';
end

Fmsi = imresize(MSI,[psize(1),psize(2)],'bilinear');
%PCA transform
Fmsi = reshape(Fmsi,psize(1)*psize(2),msize(3));     %Fmsi--[psize(1)*psize(2),msize(3)];
CC = pca(Fmsi);                                               
Fpca = reshape(Fmsi*CC,psize(1),psize(2),msize(3));  %Fpca--[psize(1),psize(2),msize(3)]; 
disp('PCA Transform Complete...');             
%Histgram match
Fpan1 = Histogrammatch(PAN,Fpca(:,:,1),'sml');
%swt decomposition
if wavelettype.wavenum>0
    Fpca(:,:,1) = WCT(Fpca(:,:,1),Fpan1,wavelettype,fsrules);
else
    Fpca(:,:,1) = Fpan1;
end
%PCA transform
FUS = reshape(reshape(Fpca,psize(1)*psize(2),msize(3))*CC',psize(1),psize(2),msize(3));
disp('IPCA Transform Complete...');
%max and min value
FUS = SetMinMaxofImg(FUS, minmax((reshape(MSI,msize(1)*msize(2),msize(3)))'));

