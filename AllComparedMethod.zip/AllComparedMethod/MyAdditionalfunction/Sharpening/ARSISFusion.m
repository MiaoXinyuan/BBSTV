function FUS = ARSISFusion(MSI,PAN,ARSISModel,DecomLevel, Wavetype)
%%  FUS = ARSISFusion(MSI,PAN,ARSISModel,DecomLevel)
% MSI: multispectral image;
% PAN: panchromatic image;
% ARSISModel: available ARSIS models{'M1','M2','CBD','RWM','M3','M4'};
% DecomLevel: a two-element vector, represents the decomposition levels of MSI and PAN images;
if nargin < 5
    Wavetype = 'db1';
end

MSI = double(MSI);  PAN = double(PAN);
%% ARSIS-->MSM-->SWT decomposition
HRlevel = DecomLevel(2)-DecomLevel(1);
[Ap,Dp{1},Dp{2},Dp{3}] = swt2(PAN,HRlevel,Wavetype);
[Ap,Dp{1},Dp{2},Dp{3}] = WtRedunRmove(Ap,Dp{1},Dp{2},Dp{3}, Wavetype);
if strcmp(ARSISModel , 'M3')||strcmp(ARSISModel , 'M4')||strcmp(ARSISModel , 'M5')
    Af(:,:,HRlevel) = MSI.* Ap(:,:,HRlevel)./medfilt2(Ap(:,:,HRlevel),[5 5],'symmetric'); % NEW-MODEL
else
    Af(:,:,HRlevel) = MSI;
end

[Lo_D,Hi_D] = wfilters(Wavetype,'d');
for j = 1:HRlevel-1
    Lo_D(2,length(Lo_D)) = 0;   Lo_D = Lo_D(:)';
    Hi_D(2,length(Hi_D)) = 0;   Hi_D = Hi_D(:)';
end

for j = HRlevel+1:DecomLevel(2)
    Lo_D(2,length(Lo_D)) = 0;   Lo_D = Lo_D(:)';
    Hi_D(2,length(Hi_D)) = 0;   Hi_D = Hi_D(:)';
    [Af(:,:,j),Df{1}(:,:,j),Df{2}(:,:,j),Df{3}(:,:,j)] = swt2(Af(:,:,j-1),1,Lo_D,Hi_D);
    [Ap(:,:,j),Dp{1}(:,:,j),Dp{2}(:,:,j),Dp{3}(:,:,j)] = swt2(Ap(:,:,j-1),1,Lo_D,Hi_D);
end
[Af(:,:, HRlevel+1:DecomLevel(2)),Df{1}(:,:, HRlevel+1:DecomLevel(2)),Df{2}(:,:, HRlevel+1:DecomLevel(2)),...
    Df{3}(:,:, HRlevel+1:DecomLevel(2))] = WtRedunRmove(Af(:,:, HRlevel+1:DecomLevel(2)),...
    Df{1}(:,:,HRlevel+1:DecomLevel(2)),Df{2}(:,:, HRlevel+1:DecomLevel(2)),Df{3}(:,:, HRlevel+1:DecomLevel(2)),Wavetype);

[Ap(:,:, HRlevel+1:DecomLevel(2)),Dp{1}(:,:, HRlevel+1:DecomLevel(2)),Dp{2}(:,:, HRlevel+1:DecomLevel(2)),...
    Dp{3}(:,:, HRlevel+1:DecomLevel(2))] = WtRedunRmove(Ap(:,:, HRlevel+1:DecomLevel(2)),...
    Dp{1}(:,:,HRlevel+1:DecomLevel(2)),Dp{2}(:,:, HRlevel+1:DecomLevel(2)),Dp{3}(:,:, HRlevel+1:DecomLevel(2)),Wavetype);

%% ARSIS IBSM construction
switch ARSISModel
    case {'M1','M2','RWM'}
        for j = 1:3
            [ Alpha, Beita ] = ARSIS_MODEL( Df{j}(:,:,HRlevel+1), Dp{j}(:,:,HRlevel+1), ARSISModel);
            for k = 1:HRlevel
                Df{j}(:,:,k) = Alpha .* Dp{j}(:,:,k) + Beita;
            end
        end
    case 'CBD'
        [ Alpha, Beita ] = ARSIS_MODEL( Af(:,:,HRlevel), Ap(:,:,HRlevel), ARSISModel);
        for j= 1:3
            for k = 1:HRlevel
                Df{j}(:,:,k) = Alpha .* Dp{j}(:,:,k) + Beita;
            end
        end
    case {'M3','M4','M5'}
        psize = size(PAN);           
        Blocksize = 512;         
        for j = 1:3
            for k = HRlevel:-1:1           
                [Alpha, Beita] = ARSIS_MODEL( Df{j}(:,:,k+1:DecomLevel(2)), Dp{j}(:,:,k+1:DecomLevel(2)), ARSISModel);
                 Df{j}(:,:,k) = Alpha .* Dp{j}(:,:,k) + Beita;
                 
                 Ssim = ssim(Ap(:,:,k),Af(:,:,k));
                 for Rowsi = 1:psize(1)/Blocksize
                    for Colsi = 1:psize(2)/Blocksize
                        P = Ap( (Rowsi-1)*Blocksize+1:Rowsi*Blocksize, (Colsi-1)*Blocksize+1:Colsi*Blocksize, k);
                        F = Af( (Rowsi-1)*Blocksize+1:Rowsi*Blocksize, (Colsi-1)*Blocksize+1:Colsi*Blocksize, k);
                        if ssim(P,F) > Ssim
                            Df{j}((Rowsi-1)*Blocksize+1:Rowsi*Blocksize, (Colsi-1)*Blocksize+1:Colsi*Blocksize, k) ...
                                = Dp{j}((Rowsi-1)*Blocksize+1:Rowsi*Blocksize, (Colsi-1)*Blocksize+1:Colsi*Blocksize, k);
                        end
                    end
                 end
            end
        end
end

if strcmp(ARSISModel , 'M3')||strcmp(ARSISModel , 'M4')||strcmp(ARSISModel , 'M5')
    FUS =  Af(:,:,HRlevel) + sum(Df{1}(:,:,1:HRlevel),3) + sum(Df{2}(:,:,1:HRlevel),3) + sum(Df{3}(:,:,1:HRlevel),3);     
else
    FUS =  MSI + sum(Df{1}(:,:,1:HRlevel),3) + sum(Df{2}(:,:,1:HRlevel),3) + sum(Df{3}(:,:,1:HRlevel),3);   
end