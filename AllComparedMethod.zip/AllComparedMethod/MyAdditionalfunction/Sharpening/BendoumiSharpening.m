function Zest = BendoumiSharpening( X, Y, D, B, varargin)
% SubDivUnmixing: Subdivision Unmixing-based Fusion
% �ںϸ߹���ͼ��Z = W��H��p��n
% �߹���ͼ��X��p��m
% �����ͼ��Y��q��n
% �ռ���ɢ�任����W��n��m
% ������Ӧת������R��q��p
% ��Ԫ����W��p��D��    
% ��Ⱦ���A��D��n��  

% Zest = SubDivUnmixing( X, Y, D, SubImgSize, varargin)
% X: low-resolution hyperspectral image
% Y: high-resolution multispectral image
% D: number of end-members
% B: a scalar indicates how many blocks of sub-images
% varargin: parameters used in CNMF, which can be 'S','R'

% example:
% clear;clc;
% Z = double(ENVIImgRead('E:\Workspace\Datasets\Sandiego\Sandiego'));  
% [s,D] = deal(4,6);
% X = imresize(Z,1/s,'bilinear');
% for j = 1:6
%     Y(:,:,j) = mean(Z(:,:,20*j-10:20*j+5),3);
% end
% Zest = SubDivUnmixing( X, Y, D, 1, size();
% Result = FusAss(Zest,X,Y,Z,3.5,14);

if ~exist('B','var')
    B = 1;
end

[SioX , SioY]  = deal(size(X),  size(Y));
Zest = zeros(SioY(1),SioY(2),SioX(3));
BsY = [SioY(1),SioY(2)]./B;
BsX = [SioX(1),SioX(2)]./B;
for j = 1:B
    for k = 1:B
        x = X( (j-1)*BsX(1)+1:j*BsX(1), (k-1)*BsX(2)+1:k*BsX(2), : );
        y = Y( (j-1)*BsY(1)+1:j*BsY(1), (k-1)*BsY(2)+1:k*BsY(2), : );
        Zest( (j-1)*BsY(1)+1:j*BsY(1), (k-1)*BsY(2)+1:k*BsY(2), : ) = SubDivid(x,y,D,varargin);
    end
end


function Zest = SubDivid(X,Y,D,varargin)
varargin = varargin{1};
[SioX , SioY]  = deal(size(X),  size(Y));
s = SioY(1)/SioX(1);    % the resolution ratio
[ p, m, q, n ] = deal( SioX(3),prod(SioX(1:2)),SioY(3),prod(SioY(1:2)) );
PSF = fspecial('gaussian',s);       % spatial and spectral degradation matrix
SRF = fspecial('gaussian',[p/q,1],2);
W = zeros(n,m);   R = zeros(q,p);
for l = 1:m
    [tempR,tempC] = ind2sub(SioX,l);
    tempT = zeros(SioY(1),SioY(2));
    tempT((tempR-1)*s+1:tempR*s, (tempC-1)*s+1:tempC*s) = PSF;
    W(:,l) = tempT(:);
end
W = sparse(W);
for l = 1:q
    R(l, (l-1)*p/q+1:l*p/q) = SRF(:);
end
R = sparse(R);
if ~isempty(varargin)
    for i = 1:2:length(varargin)
        switch lower(varargin{i})
            case 's'
                W = varargin{i+1};
            case 'r'
                R = varargin{i+1};
            otherwise
            error(message('MATLAB:listdlg:UnknownParameter', varargin{ i }));
        end
    end
end
X = (reshape(X, m,p))';
Y = (reshape(Y, n,q))';
S = VCA(X,'Endmembers',D);  % compute endmember matrix
Sm = R*S;
if D == q
    A = inv(Sm)*Y;          % abundance matrix
else
    A = inv(Sm'*Sm)*Sm'*Y;
end

Ah = A*W;
S = X*Ah'*inv(Ah*Ah');

Zest = S*A;
Zest = reshape(Zest',SioY(1),SioY(2),p);


