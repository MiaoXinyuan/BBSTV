function FUS=FusRules(MSI,PAN,method0,method1,MSIL,PANL)
%fusion rules
%           FUS=FusRules(MSI,PAN,method0,method1)
%MSI:       multispectral image coefficients
%PAN:       panchromatic image coefficients
%method0:   major rules(abs,ave,ene,gra,std,ssim,pca,con)
%method1:   minor rules(weight,select,region)
%MSIL,PANL: when using contrast rule,the low-frequency coefficients is used
[MSI, PAN] = deal(double(MSI), double(PAN));
switch method0
    case 'low'
        FUS = MSI;
    case 'high'
        FUS = PAN;
    case 'ave'
        %method1 is the weight
        if nargin < 4
            method1 = 0.5;
        end
        FUS = MSI * method1 + PAN * (1-method1);
    case 'abs'
        %selecting the max abs value
        FUS = (abs(PAN)>abs(MSI)).*PAN+(abs(PAN)<=abs(MSI)).*MSI;
        FUS = Constest(FUS,MSI,PAN);
    case 'ene'
        if nargin<4
            method1 = ones(3);
        end
        PAN1 = filter2(method1,PAN.^2);   MSI1 = filter2(method1,MSI.^2);
        FUS = (PAN1>MSI1).*PAN+(PAN1<=MSI1).*MSI;
        FUS = Constest(FUS,MSI,PAN);
    case 'gra'
        %base on region average gradient
        [Fxm,Fym] = gradient(MSI);    Fxm = abs(Fxm)+abs(Fym);
        [Fxp,Fyp] = gradient(PAN);    Fxp = abs(Fxp)+abs(Fyp);
        if nargin<=4
            method1 = [1 2 1;2 4 2;1 2 1];
        end
        Fym(:,:) = filter2(method1,Fxm);      Fyp(:,:) = filter2(method1,Fxp);
        FUS = (Fym>=Fyp).*MSI + (Fym<Fyp).*PAN;
        FUS = Constest(FUS,MSI,PAN);
    case 'std'
        %base on region standard error
        FUS(:,:) = max(PAN(:,:),MSI(:,:));
        h0 = ones(3)/9;
        Fxm = MSI.^2;             Fxp = PAN.^2;
        Fym = filter2(h0,Fxm);    Fyp = filter2(h0,Fxp);
        Fxm = filter2(h0,MSI);    Fxp = filter2(h0,PAN);
        Fym = Fym-Fxm.^2;         Fyp = Fyp-Fxp.^2;
        if strcmp(method1,'select')
            FUS = (Fym>=Fyp).*MSI + (Fym<Fyp).*PAN;
            FUS = Constest(FUS,MSI,PAN);
        elseif strcmp(method1,'weight')
            FUS = Fyp./(Fym+Fyp).*PAN+Fym./(Fym+Fyp).*MSI;
        else
            disp('Unrecognized method1');
        end
    case 'ssim'
        %base on region struct similarity
        %method1 is the size of region
        if (~(isa(method1,'double')))||(nargin<4)
            disp('wrong parameter class:method1');
            method1 = 3;
        end
        ssi = Localssim(MSI,PAN,method1,0.01,0.01);
        [Fxm,Fym] = gradient(MSI);    Fxm = abs(Fxm)+abs(Fym);
        [Fxp,Fyp] = gradient(PAN);    Fxp = abs(Fxp)+abs(Fyp);
        Fym = filter2(ones(3),Fxm);   Fyp = filter2(ones(3),Fxp);
        FUS = (ssi<0.6).*MSI+(ssi>=0.6).*((Fym>=Fyp).*MSI+(Fym<Fyp).*PAN);
        FUS = Constest(FUS,MSI,PAN);
    case 'pca'
        %base on adaptive PCA
        [mm,nn] = size(PAN);
        FUS(:,:) = max(PAN(:,:),MSI(:,:));
        %method1 is the size of region
        if nargin==3
            method1=3;
        end
        for m = ((method1+1)/2):(mm-(method1-1)/2)
            for n = ((method1+1)/2):(nn-(method1-1)/2)
                temp(:,1) = reshape(PAN((m-(method1-1)/2):(m+(method1-1)/2),(n-(method1-1)/2):(n+(method1-1)/2)),method1.^2,1);
                temp(:,2) = reshape(MSI((m-(method1-1)/2):(m+(method1-1)/2),(n-(method1-1)/2):(n+(method1-1)/2)),method1.^2,1);
                [~,DD] = eig(cov(temp));
                FUS(m,n) = DD(1,1)/(DD(1,1)+DD(2,2))*PAN(m,n)...
                    +DD(2,2)/(DD(1,1)+DD(2,2))*MSI(m,n);
            end
        end
    case 'con'
        %base on contrast(high-frequency-coefficient/low-frequency-coefficient);
        if nargin<6
            disp('there is no MSI Low-frequency or PAN Low-frequency coefficients');
            return;
        else
            %compute contrast of the whole image;
            MSIL = (MSI.^2./abs(MSIL));       PANL = (PAN.^2./abs(PANL));
            MSIL = filter2(method1,MSIL);     PANL = filter2(method1,PANL);
            FUS = (MSIL>=PANL).*MSI+(MSIL<PANL).*PAN;
            FUS = Constest(FUS,MSI,PAN);
        end
    otherwise
        disp('Unrecognized method0');
end


function FUS = Constest(FUS,MSI,PAN)%consistency check
a = filter2(ones(3),double(FUS==MSI));
FUS = (a>=5).*MSI+(a<5).*PAN;
