function FUS=WCT(MSI,PAN,wavelettype,fsrules)
%wavelet and contourlet decomposition
%           Function FUS=WCT(MSI,PAN,wavelettype,fsrules)
%MSI:       Multiband image;
%PAN:       High resolution image;
%wavelettype: {wavetype,wavename,wavenum,dirtype,dirfilter,dirnum};
    %wavetype: 'dwt'or 'swt'
    %wavename:  Wavelet name used by DWT or SWT;
    %wavenum:   Level of wavelet decomposition
    %dirtype:   'ct' or 'nsct'
    %dirfilter: Direction filter used by contourlet(see dfilters in contourlet_toolbox);
    %dirnum:    Direction numbers;
%fsrules:   {lowsel1,lowsel2,highsel1,highsel2};
    %lowsel1:   The major approximate coefficient selecting method;default is 'ssim';
    %lowsel2:   The minor approximate coefficient selecting method;default is 'select';
    %highsel1:  The major detail coefficient selecting method;default is 'abs';
    %highsel2:  The minor detail coefficient selecting method;default is 'select';
%Return :   Multiband high resolution image;
if (~exist('wavelettype','var'))
    wavelettype.wavetype = 'swt';
    wavelettype.wavename = 'db4';
    wavelettype.wavenum = 4;
    wavelettype.dirtype = 'ct';
    wavelettype.dirfilter = 'pkva';
    wavelettype.dirnum = 0;
end
if (~exist('fsrules','var'))
    fsrules.lowsel1 = 'low';
    fsrules.lowsel2 = 'select';
    fsrules.highsel1 = 'high';
    fsrules.highsel2 = 'select';
end

if ~isfield(wavelettype,'wavetype')
    wavelettype.wavetype = 'swt';
end
if ~isfield(wavelettype,'wavename')
    wavelettype.wavename = 'db4';
end
if ~isfield(wavelettype,'wavenum')
    wavelettype.wavenum = 4;
end
if ~isfield(wavelettype,'dirtype')
    wavelettype.dirtype = 'ct';
end
if ~isfield(wavelettype,'dirfilter')
    wavelettype.dirfilter = 'pkva';
end
if ~isfield(wavelettype,'dirnum')
    wavelettype.dirnum = 0;
end

if ~isfield(fsrules,'lowsel1')
    fsrules.lowsel1 = 'low';
end
if ~isfield(fsrules,'lowsel2')
    fsrules.lowsel2 = 'select';
end
if ~isfield(fsrules,'highsel1')
    fsrules.highsel1 = 'high';
end
if ~isfield(fsrules,'highsel2')
    fsrules.highsel2 = 'select';
end
wavetype = wavelettype.wavetype;
wavename =  wavelettype.wavename;
wavenum = wavelettype.wavenum;
dirtype = wavelettype.dirtype;
dirfilter = wavelettype.dirfilter;
dirnum = wavelettype.dirnum;

MSI=double(imresize(MSI,size(PAN),'bilinear'));    PAN=double(PAN);
if strcmp(wavetype,'swt')
    %swt decomposition
    [Ap,Hp,Vp,Dp]=swt2(PAN,wavenum,wavename);
    [Am,Hm,Vm,Dm]=swt2(MSI,wavenum,wavename);
    disp('SWT Decomposition Complete...');
    %Approximate Coefficient Selection
    Am(:,:,wavenum)=FusRules(Am(:,:,wavenum),Ap(:,:,wavenum),fsrules.lowsel1,fsrules.lowsel2);
    disp('Approximate Coefficient Selecting Complete...');
    %directions decommposition
    if any(dirnum)
        %CT or NSCT decompositon
        if strcmp(dirtype,'ct')
            for kl=1:wavenum
                Hpd{kl}=dfbdec(Hp(:,:,kl),dirfilter,dirnum(kl));
                Vpd{kl}=dfbdec(Vp(:,:,kl),dirfilter,dirnum(kl));
                Dpd{kl}=dfbdec(Dp(:,:,kl),dirfilter,dirnum(kl));
                
                Hmd{kl}=dfbdec(Hm(:,:,kl),dirfilter,dirnum(kl));
                Vmd{kl}=dfbdec(Vm(:,:,kl),dirfilter,dirnum(kl));
                Dmd{kl}=dfbdec(Dm(:,:,kl),dirfilter,dirnum(kl));
            end
            disp('Contourlet Decomposition Complete...');
        elseif strcmp(dirtype,'nsct')
            for kl=1:wavenum
                Hpd{kl}=nsdfbdec(Hp(:,:,kl),dirfilter,dirnum(kl));
                Vpd{kl}=nsdfbdec(Vp(:,:,kl),dirfilter,dirnum(kl));
                Dpd{kl}=nsdfbdec(Dp(:,:,kl),dirfilter,dirnum(kl));
                
                Hmd{kl}=nsdfbdec(Hm(:,:,kl),dirfilter,dirnum(kl));
                Vmd{kl}=nsdfbdec(Vm(:,:,kl),dirfilter,dirnum(kl));
                Dmd{kl}=nsdfbdec(Dm(:,:,kl),dirfilter,dirnum(kl));
            end
            disp('Non-subsampled Contourlet Decomposition Complete...');
        else
            disp('No such directional decomposition method');
        end
        %Detail Coefficient Selection
        if strcmp(dirtype,'ct')||strcmp(dirtype,'nsct')
            for kl=1:wavenum
                for t=1:(2^dirnum(kl))
                    Hmd{kl}{t}=FusRules(Hmd{kl}{t},Hpd{kl}{t},fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
                    Vmd{kl}{t}=FusRules(Vmd{kl}{t},Vpd{kl}{t},fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
                    Dmd{kl}{t}=FusRules(Dmd{kl}{t},Dpd{kl}{t},fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
                end
                disp(['Detail Coefficient ',num2str(kl),' Lays Selected...']);
            end
        end
        %CT or NSCT reconstruction
        if strcmp(dirtype,'ct')
            for kl=1:wavenum
                Hm(:,:,kl)=dfbrec(Hmd{kl},dirfilter);
                Vm(:,:,kl)=dfbrec(Vmd{kl},dirfilter);
                Dm(:,:,kl)=dfbrec(Dmd{kl},dirfilter);
            end
            disp('Contourlet Reconstruction Complete...');
        elseif strcmp(dirtype,'nsct')
            for kl=1:wavenum
                Hm(:,:,kl)=nsdfbrec(Hmd{kl},dirfilter);
                Vm(:,:,kl)=nsdfbrec(Vmd{kl},dirfilter);
                Dm(:,:,kl)=nsdfbrec(Dmd{kl},dirfilter);
            end
            disp('Non-subsampled Contourlet Reconstruction Complete...');
        end
    else
        %Detail Coefficient Selection
        for kl=1:wavenum
            Hm(:,:,kl)=FusRules(Hm(:,:,kl),Hp(:,:,kl),fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
            Vm(:,:,kl)=FusRules(Vm(:,:,kl),Vp(:,:,kl),fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
            Dm(:,:,kl)=FusRules(Dm(:,:,kl),Dp(:,:,kl),fsrules.highsel1,fsrules.highsel2,Am(:,:,wavenum),Ap(:,:,wavenum));
            disp(['Detail Coefficient ',num2str(kl),' Lays Selected...']);
        end
    end
    %ISWT transform
    FUS=iswt2(Am,Hm,Vm,Dm,wavename);
    disp('ISWT Transform Complete...');
elseif strcmp(wavetype,'dwt')
    %dwt decomposition
    [Ap{1},Hp{1},Vp{1},Dp{1}]=dwt2(PAN,wavename,'mode','per');
    [Am{1},Hm{1},Vm{1},Dm{1}]=dwt2(MSI,wavename,'mode','per');
    for kl=1:(wavenum-1)
        [Ap{kl+1},Hp{kl+1},Vp{kl+1},Dp{kl+1}]=dwt2(Ap{kl},wavename,'mode','per');
        [Am{kl+1},Hm{kl+1},Vm{kl+1},Dm{kl+1}]=dwt2(Am{kl},wavename,'mode','per');
    end
    disp('DWT Decomposition Complete...');
    %Approximate Coefficient Selection
    Am{wavenum}=FusRules(Am{wavenum},Ap{wavenum},fsrules.lowsel1,fsrules.lowsel2);
    disp('Approximate Coefficient Selecting Complete...');
    %directions decommposition
    if any(dirnum)
        %CT or NSCT decompositon
        if strcmp(dirtype,'ct')
            for kl=1:wavenum
                Hpd{kl}=dfbdec(Hp{kl},dirfilter,dirnum(kl));
                Vpd{kl}=dfbdec(Vp{kl},dirfilter,dirnum(kl));
                Dpd{kl}=dfbdec(Dp{kl},dirfilter,dirnum(kl));
                
                Hmd{kl}=dfbdec(Hm{kl},dirfilter,dirnum(kl));
                Vmd{kl}=dfbdec(Vm{kl},dirfilter,dirnum(kl));
                Dmd{kl}=dfbdec(Dm{kl},dirfilter,dirnum(kl));
            end
            disp('Contourlet Decomposition Complete...');
        elseif strcmp(dirtype,'nsct')
            for kl=1:wavenum
                Hpd{kl}=nsdfbdec(Hp{kl},dirfilter,dirnum(kl));
                Vpd{kl}=nsdfbdec(Vp{kl},dirfilter,dirnum(kl));
                Dpd{kl}=nsdfbdec(Dp{kl},dirfilter,dirnum(kl));
                
                Hmd{kl}=nsdfbdec(Hm{kl},dirfilter,dirnum(kl));
                Vmd{kl}=nsdfbdec(Vm{kl},dirfilter,dirnum(kl));
                Dmd{kl}=nsdfbdec(Dm{kl},dirfilter,dirnum(kl));
            end
            disp('Non-subsampled Contourlet Decomposition Complete...');
        else
            disp('unrecognized directional decomposition method');
            return;
        end
        %Detail Coefficient Selection
        if strcmp(dirtype,'ct')||strcmp(dirtype,'nsct')
            for kl=1:wavenum
                for t=1:(2^dirnum(kl))
                    Hmd{kl}{t}=FusRules(Hmd{kl}{t},Hpd{kl}{t},fsrules.highsel1,fsrules.highsel2);
                    Vmd{kl}{t}=FusRules(Vmd{kl}{t},Vpd{kl}{t},fsrules.highsel1,fsrules.highsel2);
                    Dmd{kl}{t}=FusRules(Dmd{kl}{t},Dpd{kl}{t},fsrules.highsel1,fsrules.highsel2);
                end
                disp(['Detail Coefficient ',num2str(kl),' Lays Selected...']);
            end
        end
        %CT or NSCT reconstruction
        if strcmp(dirtype,'ct')
            for kl=1:wavenum
                Hm{kl}=dfbrec(Hmd{kl},dirfilter);
                Vm{kl}=dfbrec(Vmd{kl},dirfilter);
                Dm{kl}=dfbrec(Dmd{kl},dirfilter);
            end
            disp('Contourlet Reconstruction Complete...');
        elseif strcmp(dirtype,'nsct')
            for kl=1:wavenum
                Hm{kl}=nsdfbrec(Hmd{kl},dirfilter);
                Vm{kl}=nsdfbrec(Vmd{kl},dirfilter);
                Dm{kl}=nsdfbrec(Dmd{kl},dirfilter);
            end
            disp('Non-subsampled Contourlet Reconstruction Complete...');
        end
    else
        %Detail Coefficient Selection
        for kl=1:wavenum
            Hm{kl}=FusRules(Hm{kl},Hp{kl},fsrules.highsel1,fsrules.highsel2);
            Vm{kl}=FusRules(Vm{kl},Vp{kl},fsrules.highsel1,fsrules.highsel2);
            Dm{kl}=FusRules(Dm{kl},Dp{kl},fsrules.highsel1,fsrules.highsel2);
            disp(['Detail Coefficient ',num2str(kl),' Lays Selected...']);
        end
    end
    %IDWT transform
    for kl=wavenum:-1:2
        Am{kl-1}=idwt2(Am{kl},Hm{kl},Vm{kl},Dm{kl},wavename,'mode','per');
    end
    FUS=idwt2(Am{1},Hm{1},Vm{1},Dm{1},wavename,'mode','per');
    disp('IDWT Transform Complete...');
else
    disp('Unrecognized wavelet decomposition method');
    return;
end
