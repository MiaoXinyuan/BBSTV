function [postlab,postprobability] = Regionpostprocess(img_label,img_seg) 
%[postprobability] = Regionpostprocess(img_label,img_seg) 
%input:
%   img_label:    input class labeled image
%   img_seg:      segmented image of the labeled image;
%output:
%   postlab:            post processed labeled image
%   postprobability:    post processed region probability matrix;
img_label = img_label(:);
nClass = max(unique(img_label));
[mr,nr,dr] = size(img_seg);
img_seg = reshape(img_seg,mr*nr,dr);
[rgb_reg,~,xy] = unique(img_seg,'rows');
regionnum = length(rgb_reg);
postprobability = zeros(mr*nr,nClass);

hwati = waitbar(0,'Calculating regions: ');
for j = 1:regionnum
    temp = find(xy==j);
    rgbreglab = img_label(temp(:));
    if max(rgbreglab)>0
        lab = Imhistogram(rgbreglab,'nor',1,nClass);
    else
        lab = ones(nClass)/nClass;
    end
    postprobability(temp,:) = repmat(lab(1,:),length(temp),1);
    waitbar(j/regionnum,hwati,['Calculating regions: ',num2str(uint8(j/regionnum*100)),'%']);
end

close(hwati);
postprobability = reshape(postprobability,mr,nr,nClass);
[~,postlab] = max(postprobability,[],3);
