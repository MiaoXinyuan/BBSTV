function EXTE = Extens(IMG,WH,mode)
% function EXTE=Extens(IMG,WH,mode)
% Extense Image by different mode

% IMG:   original image
% WH:    a vecor assign the extented upper, left, lower, right border
%   if length(WH) == 1, WH = [WH,WH,WH,WH];
%   if length(WH) == 2, WH = [WH(1), WH(2), WH(1), WH(2)]
%   if length(WH) == 4, WH = [WH(1), WH(2), WH(3), WH(4)]
% mode:  the method of extension,including 'per','sym',zeros'
[m,n,b] = size(IMG);
win = length(WH);
if win == 1
    [h1,w1,h2,w2] = deal(WH);
elseif win == 2
    [h1,w1,h2,w2] = deal(WH(1),WH(2),WH(1),WH(2));
elseif win == 4
    [h1,w1,h2,w2] = deal(WH(1),WH(2),WH(3),WH(4));
else 
    disp('elements of WH must be 1/2/4');
    return;
end

EXTE = zeros(m+h1+h2,n+w1+w2,b);
EXTE((h1+1):(m+h1),(w1+1):(n+w1),:) = IMG;
if (h1>m)||(w1>n)||(h2>m)||(w2>n)
    disp('The image is smaller than needed;Suggest "repmat" function');
    return;
end

switch mode
    case 'per'
        %period extension
        EXTE(1:h1,:,:) = EXTE(m+1:m+h1,:,:);        
        EXTE(m+h1+1:m+h1+h2,:,:) = EXTE(h1+1:h1+h2,:,:);
        
        EXTE(:,1:w1,:) = EXTE(:,n+1:n+w1,:);
        EXTE(:,n+w1+1:n+w1+w2,:) = EXTE(:,w1+1:w1+w2,:);       
    case 'sym'
        %symmetrical extension
        EXTE(1:h1,:,:) = EXTE(h1+h1+1:-1:h1+2,:,:);
        EXTE(m+h1+1:m+h1+h2,:,:) = EXTE(m+h1-1:-1:m+h1-h2,:,:); 
        
        EXTE(:,1:w1,:) = EXTE(:,w1+w1+1:-1:w1+2,:);
        EXTE(:,n+w1+1:n+w1+w2,:) = EXTE(:,n+w1-1:-1:n+w1-w2,:);        
    case 'zero'
        %EXTE is already a zero extensed image;
        return;
    otherwise
        disp('unrecognized mode');
end
        
            
        
        
        
