function Showmap(Groundtruth,Colormap)
% Showmap(Groundtruth,dataset)
% Groundtruth:      the classification map or ground truth map
% datasetsname:     the dataset source,maybe 'UoP','CoP','DFC2013, or 'DFC2014'

nClass = max(Groundtruth(:));
Location = cell( nClass , 1 );
%% color table
if ischar(Colormap)
    col = ClassColTab(Colormap);
else
    col = Colormap;
end
%imshow(Groundtruth,col,'border','tight');


for i=1:nClass
    Location{i} = find(Groundtruth==i);
end
R=zeros(size(Groundtruth));
G=zeros(size(Groundtruth));
B=zeros(size(Groundtruth));
for i=1:nClass
    R(Location{i})=col(i,1);
    G(Location{i})=col(i,2);
    B(Location{i})=col(i,3);
end
imshow(cat(3,R,G,B),[],'border','tight');
