function Diff_Img = ImageDiff(A1,A2,Type)
% Diff_Img = ImageDiff(A1,A2,Type)
% computer the fused image of that of difference and ratio 
% Type: 1--all difference;2:increased difference ;3: decreased difference 
A1 = double(A1);    A2 = double(A2);
A1 = A1 + min(A1(:))/10;
A2 = A2 + min(A1(:))/10;
if Type == 1
    DifferImage = abs(A2-A1);
    LogDifImage = abs(log(A2./A1));
elseif Type == 2
    DifferImage = A2-A1;
    DifferImage(DifferImage<0) = 0;
    LogDifImage = log(A2./A1);
    LogDifImage(LogDifImage<0) = 0;
elseif Type == 3
    DifferImage = A1-A2;
    DifferImage(DifferImage<0) = 0;
    LogDifImage = log(A1./A2);
    LogDifImage(LogDifImage<0) = 0;    
end
for j = 1:size(A1,3)
    chazhi_f = DifferImage(:,:,j);
    duishubizhi_f = LogDifImage(:,:,j);
    chazhi_f = (chazhi_f-min(chazhi_f(:)))/(max(chazhi_f(:))-min(chazhi_f(:)))*2047;
    duishubizhi_f = (duishubizhi_f-min(duishubizhi_f(:)))/(max(duishubizhi_f(:))-min(duishubizhi_f(:)))*2047;
    DifferImage(:,:,j) = chazhi_f;
    LogDifImage(:,:,j) = duishubizhi_f;
end

[wc_1{1},wc_1{2},wc_1{3},wc_1{4}] = Swt2_Ext(DifferImage,3,'db4');
[wc_2{1},wc_2{2},wc_2{3},wc_2{4}] = Swt2_Ext(LogDifImage,3,'db4');
wc = cell(1,4);
for k = 1:4
    wc{k} = (wc_1{k} + wc_2{k})/2;
end
Diff_Img = ISwt2_Ext(wc{1},wc{2},wc{3},wc{4},'db4');
