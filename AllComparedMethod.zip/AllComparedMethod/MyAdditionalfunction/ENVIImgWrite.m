function ENVIImgWrite(Img,ImgName,ImgInfo)
%% ENVI standard image writting function
% Img: Image variable
% ImgName: Name of target image file
% ImgInfo: a struct including the infomation writing into the header file 
%    default: { Offset = 0; ByteOrder = 0; InterLeave = 'bsq'; }

%% default fields
if ~exist('ImgInfo','var')
    ImgInfo.Offset = 0;
    ImgInfo.Byteorder = '0';
    ImgInfo.Interleave = 'bsq';
    ImgInfo.Description = ' File Imported into ENVI.';
    ImgInfo.Filetype = 'ENVI Standard';
    ImgInfo.Sensortype = 'Unknown';
end   
    
ImgInfo.Imgheight = size(Img,1);
ImgInfo.Imgwidth = size(Img,2);
ImgInfo.Imgband = size(Img,3);
ImgInfo.Datatype = ClassToENVIType(class(Img));

%% write information into the head file
ENVIHeaderFileWrite(ImgInfo, [ImgName,'.hdr'])
multibandwrite(Img,ImgName,ImgInfo.Interleave);


