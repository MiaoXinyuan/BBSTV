function [newmarkindex,newmarklabel] = ALSelectfromCandidate(CandidateIndex,CandidateLabel,select_per,Candidateprobs,AL_method)
%[newmarkindex,newmarklabel] = ALSelectfromCandidate(CandidateIndex,CandidateLabel,select_per,Candidateprobs,AL_method)
%Input:
%CandidateIndex��   the indices of candidates in the image��
%CandidateLabel��   the labels of candidates,
%select_per:        the amount of selected samples at each iteration
%Candidateprobs:    the probabilities of candidates,
%AL_method:         can be 'RS','MS','BT','MBT','ME'
%
%Output:
%newmarkindex,newmarklabel:   selected samples indices and labels among DATA.CandidateIndex;
nClass = max(CandidateLabel);
indexofprob = [];

if ~exist('AL_method','var')
    fprintf( 'No active selection sampling will be addressed \n' );
elseif strcmp(AL_method,'RS')
    % Randomly select samples
    indexsortminppRS = randperm(length(CandidateLabel));
    indexofprob = indexsortminppRS(1:select_per);
    
elseif strcmp(AL_method,'MS')
    % Margin sampling
    pactive = max(Candidateprobs,[],2);
    [~, indexsortminppMS] = sort(pactive(:,1));
    if select_per <= length(CandidateIndex)
        indexofprob = indexsortminppMS(1:select_per);
    else
        indexofprob = indexsortminppMS(1:length(CandidateIndex));
    end
elseif strcmp(AL_method,'MMS')
    % Modified margin sampling
    select_per = uint8(select_per/nClass);
    for i = 1:nClass
        index = find(CandidateLabel == i);
        pactive = sort(Candidateprobs(index,:),2,'descend');
        [~, indexsortminppMMS] = sort(pactive(:,1));
        if length(index) > select_per
            tempIndex = indexsortminppMMS(1:select_per);
            indexofprob = [indexofprob;index(tempIndex)];
        else
            tempIndex = indexsortminppMMS(1:length(index));
            indexofprob = [indexofprob;index(tempIndex)];
        end
    end
    
elseif strcmp(AL_method,'BT')
    % Breaking Ties
    pactive = sort(Candidateprobs,2,'descend');
    [~, indexsortminppBT] = sort(pactive(:,1)-pactive(:,2));
    if select_per <= length(CandidateIndex)
        indexofprob = indexsortminppBT(1:select_per);
    else
        indexofprob = indexsortminppBT(1:length(CandidateIndex));
    end
    
elseif strcmp(AL_method,'MBT')
    % Modified Breaking Ties
    select_per = round(select_per/nClass);
    for i = 1:nClass
        index = find(CandidateLabel == i);
        pactive = sort(Candidateprobs(index,:),2,'descend');
        [~, indexsortminppMBT] = sort(pactive(:,1)-pactive(:,2));
        if length(index) > select_per
            tempIndex = indexsortminppMBT(1:select_per);
            indexofprob = [indexofprob;index(tempIndex)];
        else
            tempIndex = indexsortminppMBT(1:length(index));
            indexofprob = [indexofprob;index(tempIndex)];
        end
    end   
elseif strcmp(AL_method,'MME')
    % Modified maximum entropy
    select_per = uint8(select_per/nClass);
    for j=1:nClass
        index = find(CandidateLabel == j);
        pactive = Candidateprobs(index,:).*log2(Candidateprobs(index,:));
        pactive = sum(pactive,2)*(-1);
        [~, indexsortminppMME] = sort(pactive,1,'descend');
        if length(index) > select_per
            tempIndex = indexsortminppMME(1:select_per);
            indexofprob = [indexofprob;index(tempIndex)];
        else
            tempIndex = indexsortminppMME(1:length(index));
            indexofprob = [indexofprob;index(tempIndex)];
        end
    end
else
    disp('Unrecognized "AL_method" ');
end %if

if isempty(indexofprob)
    newmarkindex = [];
    newmarklabel = [];
    disp('None of candidate samples has been selected.');
else
    newmarkindex = CandidateIndex(indexofprob);
    newmarklabel = CandidateLabel(indexofprob);
end