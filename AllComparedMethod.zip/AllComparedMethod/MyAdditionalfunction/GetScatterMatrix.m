function [Sw,Sb] = GetScatterMatrix(Samples,labels)
% [Sw,Sb] = GetScatterMatrix(Samples,labels)
% compute the with-class scatter matrix and between-class scatter matrix


[N,~] = size(Samples);
Label = unique(labels);
nClass = length(Label);
Samples = bsxfun(@minus,Samples,mean(Samples,1));
P = [];
num = zeros(1,nClass);
for i = 1:nClass
   num(i) = length(find(labels == Label(i)));
    P1 = 1 / num(i) * ones(num(i));
    P = mdiag(P,P1);
end

Sb = (Samples)' * P * (Samples);
Sw = (Samples)' * (eye(N) - P) * (Samples);

Sb(isnan(Sb)) = 0; Sw(isnan(Sw)) = 0;
Sb(isinf(Sb)) = 0; Sw(isinf(Sw)) = 0;
